-- phpMyAdmin SQL Dump
-- version 4.9.1
-- https://www.phpmyadmin.net/
--
-- 主機： localhost
-- 產生時間： 
-- 伺服器版本： 8.0.17
-- PHP 版本： 7.3.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- 資料庫： `android`
--

-- --------------------------------------------------------

--
-- 資料表結構 `colors`
--

CREATE TABLE `colors` (
  `name` varchar(60) NOT NULL,
  `color` varchar(60) NOT NULL,
  `red` int(11) NOT NULL,
  `green` int(11) NOT NULL,
  `blue` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8;

--
-- 傾印資料表的資料 `colors`
--

INSERT INTO `colors` (`name`, `color`, `red`, `green`, `blue`) VALUES
('purple_200', '#BB86FC', 187, 134, 252),
('purple_500', '#6200EE', 98, 0, 238),
('purple_700', '#3700B3', 55, 0, 179),
('teal_200', '#03DAC5', 3, 218, 197),
('teal_700', '#018786', 1, 135, 134),
('white', '#ffffff', 255, 255, 255),
('ivory', '#fffff0', 255, 255, 240),
('lightyellow', '#ffffe0', 255, 255, 224),
('yellow', '#ffff00', 255, 255, 0),
('snow', '#fffafa', 255, 250, 250),
('floralwhite', '#fffaf0', 255, 250, 240),
('lemonchiffon', '#fffacd', 255, 250, 205),
('cornsilk', '#fff8dc', 255, 248, 220),
('seaShell', '#fff5ee', 255, 245, 238),
('lavenderblush', '#fff0f5', 255, 240, 245),
('papayawhip', '#ffefd5', 255, 239, 213),
('blanchedalmond', '#ffebcd', 255, 235, 205),
('mistyrose', '#ffe4e1', 255, 228, 225),
('bisque', '#ffe4c4', 255, 228, 196),
('moccasin', '#ffe4b5', 255, 228, 181),
('navajowhite', '#ffdead', 255, 222, 173),
('peachpuff', '#ffdab9', 255, 218, 185),
('gold', '#ffd700', 255, 215, 0),
('pink', '#ffc0cb', 255, 192, 203),
('lightpink', '#ffb6c1', 255, 182, 193),
('orange', '#ffa500', 255, 165, 0),
('lightsalmon', '#ffa07a', 255, 160, 122),
('darkorange', '#ff8c00', 255, 140, 0),
('coral', '#ff7f50', 255, 127, 80),
('hotpink', '#ff69b4', 255, 105, 180),
('tomato', '#ff6347', 255, 99, 71),
('orangered', '#ff4500', 255, 69, 0),
('deeppink', '#ff1493', 255, 20, 147),
('fuchsia', '#ff00ff', 255, 0, 255),
('magenta', '#ff00ff', 255, 0, 255),
('red', '#ff0000', 255, 0, 0),
('oldlace', '#fdf5e6', 253, 245, 230),
('lightgoldenrodyellow', '#fafad2', 250, 250, 210),
('linen', '#faf0e6', 250, 240, 230),
('antiquewhite', '#faebd7', 250, 235, 215),
('salmon', '#fa8072', 250, 128, 114),
('ghostwhite', '#f8f8ff', 248, 248, 255),
('mintcream', '#f5fffa', 245, 255, 250),
('whitesmoke', '#f5f5f5', 245, 245, 245),
('beige', '#f5f5dc', 245, 245, 220),
('wheat', '#f5deb3', 245, 222, 179),
('sandybrown', '#f4a460', 244, 164, 96),
('azure', '#f0ffff', 240, 255, 255),
('honeydew', '#f0fff0', 240, 255, 240),
('aliceblue', '#f0f8ff', 240, 248, 255),
('khaki', '#f0e68c', 240, 230, 140),
('lightcoral', '#f08080', 240, 128, 128),
('palegoldenrod', '#eee8aa', 238, 232, 170),
('violet', '#ee82ee', 238, 130, 238),
('darksalmon', '#e9967a', 233, 150, 122),
('lavender', '#e6e6fa', 230, 230, 250),
('lightcyan', '#e0ffff', 224, 255, 255),
('burlywood', '#deb887', 222, 184, 135),
('plum', '#dda0dd', 221, 160, 221),
('gainsboro', '#dcdcdc', 220, 220, 220),
('crimson', '#dc143c', 220, 20, 60),
('palevioletred', '#db7093', 219, 112, 147),
('goldenrod', '#daa520', 218, 165, 32),
('orchid', '#da70d6', 218, 112, 214),
('thistle', '#d8bfd8', 216, 191, 216),
('lightgray', '#d3d3d3', 211, 211, 211),
('lightgrey', '#d3d3d3', 211, 211, 211),
('tan', '#d2b48c', 210, 180, 140),
('chocolate', '#d2691e', 210, 105, 30),
('peru', '#cd853f', 205, 133, 63),
('indianred', '#cd5c5c', 205, 92, 92),
('mediumvioletred', '#c71585', 199, 21, 133),
('silver', '#c0c0c0', 192, 192, 192),
('darkkhaki', '#bdb76b', 189, 183, 107),
('rosybrown', '#bc8f8f', 188, 143, 143),
('mediumorchid', '#ba55d3', 186, 85, 211),
('darkgoldenrod', '#b8860b', 184, 134, 11),
('firebrick', '#b22222', 178, 34, 34),
('powderblue', '#b0e0e6', 176, 224, 230),
('lightsteelblue', '#b0c4de', 176, 196, 222),
('paleturquoise', '#afeeee', 175, 238, 238),
('greenyellow', '#adff2f', 173, 255, 47),
('lightblue', '#add8e6', 173, 216, 230),
('darkgray', '#a9a9a9', 169, 169, 169),
('darkgrey', '#a9a9a9', 169, 169, 169),
('brown', '#a52a2a', 165, 42, 42),
('sienna', '#a0522d', 160, 82, 45),
('darkorchid', '#9932cc', 153, 50, 204),
('palegreen', '#98fb98', 152, 251, 152),
('darkviolet', '#9400d3', 148, 0, 211),
('mediumpurple', '#9370db', 147, 112, 219),
('lightgreen', '#90ee90', 144, 238, 144),
('darkseagreen', '#8fbc8f', 143, 188, 143),
('saddlebrown', '#8b4513', 139, 69, 19),
('darkmagenta', '#8b008b', 139, 0, 139),
('darkred', '#8b0000', 139, 0, 0),
('blueviolet', '#8a2be2', 138, 43, 226),
('lightskyblue', '#87cefa', 135, 206, 250),
('skyblue', '#87ceeb', 135, 206, 235),
('gray', '#808080', 128, 128, 128),
('grey', '#808080', 128, 128, 128),
('olive', '#808000', 128, 128, 0),
('purple', '#800080', 128, 0, 128),
('maroon', '#800000', 128, 0, 0),
('aquamarine', '#7fffd4', 127, 255, 212),
('chartreuse', '#7fff00', 127, 255, 0),
('lawngreen', '#7cfc00', 124, 252, 0),
('mediumslateblue', '#7b68ee', 123, 104, 238),
('lightslategray', '#778899', 119, 136, 153),
('lightslategrey', '#778899', 119, 136, 153),
('slategray', '#708090', 112, 128, 144),
('slategrey', '#708090', 112, 128, 144),
('olivedrab', '#6b8e23', 107, 142, 35),
('slateblue', '#6a5acd', 106, 90, 205),
('dimgray', '#696969', 105, 105, 105),
('dimgrey', '#696969', 105, 105, 105),
('mediumaquamarine', '#66cdaa', 102, 205, 170),
('cornflowerblue', '#6495ed', 100, 149, 237),
('cadetblue', '#5f9ea0', 95, 158, 160),
('darkolivegreen', '#556b2f', 85, 107, 47),
('indigo', '#4b0082', 75, 0, 130),
('mediumturquoise', '#48d1cc', 72, 209, 204),
('darkslateblue', '#483d8b', 72, 61, 139),
('steelblue', '#4682b4', 70, 130, 180),
('royalblue', '#4169e1', 65, 105, 225),
('turquoise', '#40e0d0', 64, 224, 208),
('mediumseagreen', '#3cb371', 60, 179, 113),
('limegreen', '#32cd32', 50, 205, 50),
('darkslategray', '#2f4f4f', 47, 79, 79),
('darkslategrey', '#2f4f4f', 47, 79, 79),
('seagreen', '#2e8b57', 46, 139, 87),
('forestgreen', '#228b22', 34, 139, 34),
('lightseagreen', '#20b2aa', 32, 178, 170),
('dodgerblue', '#1e90ff', 30, 144, 255),
('midnightblue', '#191970', 25, 25, 112),
('aqua', '#00ffff', 0, 255, 255),
('cyan', '#00ffff', 0, 255, 255),
('springgreen', '#00ff7f', 0, 255, 127),
('lime', '#00ff00', 0, 255, 0),
('mediumspringgreen', '#00fa9a', 0, 250, 154),
('darkturquoise', '#00ced1', 0, 206, 209),
('deepskyblue', '#00bfff', 0, 191, 255),
('darkcyan', '#008b8b', 0, 139, 139),
('teal', '#008080', 0, 128, 128),
('green', '#008000', 0, 128, 0),
('darkgreen', '#006400', 0, 100, 0),
('blue', '#0000ff', 0, 0, 255),
('mediumblue', '#0000cd', 0, 0, 205),
('darkblue', '#00008b', 0, 0, 139),
('navy', '#000080', 0, 0, 128),
('black', '#000000', 0, 0, 0);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
