<?php

include_once ( "mysql_db.php" );
include_once( "./TemplatePower/class.TemplatePower.inc.php" );
$tpl = new TemplatePower( "./default_var.tpl" );
$tpl->prepare();


 $sql_string  = "SELECT * FROM `colors` order by red, green, blue ";
// $sql_string  = "SELECT * FROM `colors` order by red,  blue, green"; RBG
// $sql_string  = "SELECT * FROM `colors` order by green , red,  blue ";
// $sql_string  = "SELECT * FROM `colors` order by green ,  blue , red";

// $sql_string  = "SELECT * FROM `colors` order by blue , red,  green ";
// $sql_string  = "SELECT * FROM `colors` order by blue ,  green , red";

$result = mysqli_query($connection, $sql_string) or die("Could not query database : $sql_string");
while($row = $result->fetch_assoc()) {
	$tpl->newBlock( "oneColor" );
	$tpl->assign( "name", $row["name"] );
	$tpl->assign( "color", $row["color"] );
	$tpl->assign( "red", $row["red"] );
	$tpl->assign( "green", $row["green"] );
	$tpl->assign( "blue", $row["blue"] );

	$tpl->assign( "redV", 255-$row["red"] );
	$tpl->assign( "greenV", 255-$row["green"] );
	$tpl->assign( "blueV", 255-$row["blue"] );

	$redS = dechex(255-$row["red"]);
	if (strlen($redS) == 1){
		$redS = "0".$redS;
	}
	$greenS = dechex(255-$row["green"]);
	if (strlen($greenS) == 1){
		$greenS = "0".$greenS;
	}
	$blueS = dechex(255-$row["blue"]);
	if (strlen($blueS) == 1){
		$blueS = "0".$blueS;
	}

	$colorV = "#".$redS.$greenS.$blueS;
	$tpl->assign( "colorV", $colorV );

}

$tpl->printToScreen();