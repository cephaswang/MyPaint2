<html>
<body>

<table border="1">
<tr><td>名稱</td><td>顏色</td><td>代碼</td><td>紅</td><td>綠</td><td>藍</td></tr>
<tr><td>black</td><td bgcolor="#000000">&nbsp;&nbsp;&nbsp;</td><td>#000000</td><td>0</td><td>0</td><td>0</td></tr>

<tr><td>black_buse</td><td bgcolor="#ffffff">&nbsp;&nbsp;&nbsp;</td><td>#ffffff</td><td>255</td><td>255</td><td>255</td></tr>
<tr><td>navy</td><td bgcolor="#000080">&nbsp;&nbsp;&nbsp;</td><td>#000080</td><td>0</td><td>0</td><td>128</td></tr>

<tr><td>navy_buse</td><td bgcolor="#ffff7f">&nbsp;&nbsp;&nbsp;</td><td>#ffff7f</td><td>255</td><td>255</td><td>127</td></tr>
<tr><td>darkblue</td><td bgcolor="#00008b">&nbsp;&nbsp;&nbsp;</td><td>#00008b</td><td>0</td><td>0</td><td>139</td></tr>

<tr><td>darkblue_buse</td><td bgcolor="#ffff74">&nbsp;&nbsp;&nbsp;</td><td>#ffff74</td><td>255</td><td>255</td><td>116</td></tr>
<tr><td>mediumblue</td><td bgcolor="#0000cd">&nbsp;&nbsp;&nbsp;</td><td>#0000cd</td><td>0</td><td>0</td><td>205</td></tr>

<tr><td>mediumblue_buse</td><td bgcolor="#ffff32">&nbsp;&nbsp;&nbsp;</td><td>#ffff32</td><td>255</td><td>255</td><td>50</td></tr>
<tr><td>blue</td><td bgcolor="#0000ff">&nbsp;&nbsp;&nbsp;</td><td>#0000ff</td><td>0</td><td>0</td><td>255</td></tr>

<tr><td>blue_buse</td><td bgcolor="#ffff00">&nbsp;&nbsp;&nbsp;</td><td>#ffff00</td><td>255</td><td>255</td><td>0</td></tr>
<tr><td>darkgreen</td><td bgcolor="#006400">&nbsp;&nbsp;&nbsp;</td><td>#006400</td><td>0</td><td>100</td><td>0</td></tr>

<tr><td>darkgreen_buse</td><td bgcolor="#ff9bff">&nbsp;&nbsp;&nbsp;</td><td>#ff9bff</td><td>255</td><td>155</td><td>255</td></tr>
<tr><td>green</td><td bgcolor="#008000">&nbsp;&nbsp;&nbsp;</td><td>#008000</td><td>0</td><td>128</td><td>0</td></tr>

<tr><td>green_buse</td><td bgcolor="#ff7fff">&nbsp;&nbsp;&nbsp;</td><td>#ff7fff</td><td>255</td><td>127</td><td>255</td></tr>
<tr><td>teal</td><td bgcolor="#008080">&nbsp;&nbsp;&nbsp;</td><td>#008080</td><td>0</td><td>128</td><td>128</td></tr>

<tr><td>teal_buse</td><td bgcolor="#ff7f7f">&nbsp;&nbsp;&nbsp;</td><td>#ff7f7f</td><td>255</td><td>127</td><td>127</td></tr>
<tr><td>darkcyan</td><td bgcolor="#008b8b">&nbsp;&nbsp;&nbsp;</td><td>#008b8b</td><td>0</td><td>139</td><td>139</td></tr>

<tr><td>darkcyan_buse</td><td bgcolor="#ff7474">&nbsp;&nbsp;&nbsp;</td><td>#ff7474</td><td>255</td><td>116</td><td>116</td></tr>
<tr><td>deepskyblue</td><td bgcolor="#00bfff">&nbsp;&nbsp;&nbsp;</td><td>#00bfff</td><td>0</td><td>191</td><td>255</td></tr>

<tr><td>deepskyblue_buse</td><td bgcolor="#ff4000">&nbsp;&nbsp;&nbsp;</td><td>#ff4000</td><td>255</td><td>64</td><td>0</td></tr>
<tr><td>darkturquoise</td><td bgcolor="#00ced1">&nbsp;&nbsp;&nbsp;</td><td>#00ced1</td><td>0</td><td>206</td><td>209</td></tr>

<tr><td>darkturquoise_buse</td><td bgcolor="#ff312e">&nbsp;&nbsp;&nbsp;</td><td>#ff312e</td><td>255</td><td>49</td><td>46</td></tr>
<tr><td>mediumspringgreen</td><td bgcolor="#00fa9a">&nbsp;&nbsp;&nbsp;</td><td>#00fa9a</td><td>0</td><td>250</td><td>154</td></tr>

<tr><td>mediumspringgreen_buse</td><td bgcolor="#ff0565">&nbsp;&nbsp;&nbsp;</td><td>#ff0565</td><td>255</td><td>5</td><td>101</td></tr>
<tr><td>lime</td><td bgcolor="#00ff00">&nbsp;&nbsp;&nbsp;</td><td>#00ff00</td><td>0</td><td>255</td><td>0</td></tr>

<tr><td>lime_buse</td><td bgcolor="#ff00ff">&nbsp;&nbsp;&nbsp;</td><td>#ff00ff</td><td>255</td><td>0</td><td>255</td></tr>
<tr><td>springgreen</td><td bgcolor="#00ff7f">&nbsp;&nbsp;&nbsp;</td><td>#00ff7f</td><td>0</td><td>255</td><td>127</td></tr>

<tr><td>springgreen_buse</td><td bgcolor="#ff0080">&nbsp;&nbsp;&nbsp;</td><td>#ff0080</td><td>255</td><td>0</td><td>128</td></tr>
<tr><td>aqua</td><td bgcolor="#00ffff">&nbsp;&nbsp;&nbsp;</td><td>#00ffff</td><td>0</td><td>255</td><td>255</td></tr>

<tr><td>aqua_buse</td><td bgcolor="#ff0000">&nbsp;&nbsp;&nbsp;</td><td>#ff0000</td><td>255</td><td>0</td><td>0</td></tr>
<tr><td>cyan</td><td bgcolor="#00ffff">&nbsp;&nbsp;&nbsp;</td><td>#00ffff</td><td>0</td><td>255</td><td>255</td></tr>

<tr><td>cyan_buse</td><td bgcolor="#ff0000">&nbsp;&nbsp;&nbsp;</td><td>#ff0000</td><td>255</td><td>0</td><td>0</td></tr>
<tr><td>teal_700</td><td bgcolor="#018786">&nbsp;&nbsp;&nbsp;</td><td>#018786</td><td>1</td><td>135</td><td>134</td></tr>

<tr><td>teal_700_buse</td><td bgcolor="#fe7879">&nbsp;&nbsp;&nbsp;</td><td>#fe7879</td><td>254</td><td>120</td><td>121</td></tr>
<tr><td>teal_200</td><td bgcolor="#03DAC5">&nbsp;&nbsp;&nbsp;</td><td>#03DAC5</td><td>3</td><td>218</td><td>197</td></tr>

<tr><td>teal_200_buse</td><td bgcolor="#fc253a">&nbsp;&nbsp;&nbsp;</td><td>#fc253a</td><td>252</td><td>37</td><td>58</td></tr>
<tr><td>midnightblue</td><td bgcolor="#191970">&nbsp;&nbsp;&nbsp;</td><td>#191970</td><td>25</td><td>25</td><td>112</td></tr>

<tr><td>midnightblue_buse</td><td bgcolor="#e6e68f">&nbsp;&nbsp;&nbsp;</td><td>#e6e68f</td><td>230</td><td>230</td><td>143</td></tr>
<tr><td>dodgerblue</td><td bgcolor="#1e90ff">&nbsp;&nbsp;&nbsp;</td><td>#1e90ff</td><td>30</td><td>144</td><td>255</td></tr>

<tr><td>dodgerblue_buse</td><td bgcolor="#e16f00">&nbsp;&nbsp;&nbsp;</td><td>#e16f00</td><td>225</td><td>111</td><td>0</td></tr>
<tr><td>lightseagreen</td><td bgcolor="#20b2aa">&nbsp;&nbsp;&nbsp;</td><td>#20b2aa</td><td>32</td><td>178</td><td>170</td></tr>

<tr><td>lightseagreen_buse</td><td bgcolor="#df4d55">&nbsp;&nbsp;&nbsp;</td><td>#df4d55</td><td>223</td><td>77</td><td>85</td></tr>
<tr><td>forestgreen</td><td bgcolor="#228b22">&nbsp;&nbsp;&nbsp;</td><td>#228b22</td><td>34</td><td>139</td><td>34</td></tr>

<tr><td>forestgreen_buse</td><td bgcolor="#dd74dd">&nbsp;&nbsp;&nbsp;</td><td>#dd74dd</td><td>221</td><td>116</td><td>221</td></tr>
<tr><td>seagreen</td><td bgcolor="#2e8b57">&nbsp;&nbsp;&nbsp;</td><td>#2e8b57</td><td>46</td><td>139</td><td>87</td></tr>

<tr><td>seagreen_buse</td><td bgcolor="#d174a8">&nbsp;&nbsp;&nbsp;</td><td>#d174a8</td><td>209</td><td>116</td><td>168</td></tr>
<tr><td>darkslategray</td><td bgcolor="#2f4f4f">&nbsp;&nbsp;&nbsp;</td><td>#2f4f4f</td><td>47</td><td>79</td><td>79</td></tr>

<tr><td>darkslategray_buse</td><td bgcolor="#d0b0b0">&nbsp;&nbsp;&nbsp;</td><td>#d0b0b0</td><td>208</td><td>176</td><td>176</td></tr>
<tr><td>darkslategrey</td><td bgcolor="#2f4f4f">&nbsp;&nbsp;&nbsp;</td><td>#2f4f4f</td><td>47</td><td>79</td><td>79</td></tr>

<tr><td>darkslategrey_buse</td><td bgcolor="#d0b0b0">&nbsp;&nbsp;&nbsp;</td><td>#d0b0b0</td><td>208</td><td>176</td><td>176</td></tr>
<tr><td>limegreen</td><td bgcolor="#32cd32">&nbsp;&nbsp;&nbsp;</td><td>#32cd32</td><td>50</td><td>205</td><td>50</td></tr>

<tr><td>limegreen_buse</td><td bgcolor="#cd32cd">&nbsp;&nbsp;&nbsp;</td><td>#cd32cd</td><td>205</td><td>50</td><td>205</td></tr>
<tr><td>purple_700</td><td bgcolor="#3700B3">&nbsp;&nbsp;&nbsp;</td><td>#3700B3</td><td>55</td><td>0</td><td>179</td></tr>

<tr><td>purple_700_buse</td><td bgcolor="#c8ff4c">&nbsp;&nbsp;&nbsp;</td><td>#c8ff4c</td><td>200</td><td>255</td><td>76</td></tr>
<tr><td>mediumseagreen</td><td bgcolor="#3cb371">&nbsp;&nbsp;&nbsp;</td><td>#3cb371</td><td>60</td><td>179</td><td>113</td></tr>

<tr><td>mediumseagreen_buse</td><td bgcolor="#c34c8e">&nbsp;&nbsp;&nbsp;</td><td>#c34c8e</td><td>195</td><td>76</td><td>142</td></tr>
<tr><td>turquoise</td><td bgcolor="#40e0d0">&nbsp;&nbsp;&nbsp;</td><td>#40e0d0</td><td>64</td><td>224</td><td>208</td></tr>

<tr><td>turquoise_buse</td><td bgcolor="#bf1f2f">&nbsp;&nbsp;&nbsp;</td><td>#bf1f2f</td><td>191</td><td>31</td><td>47</td></tr>
<tr><td>royalblue</td><td bgcolor="#4169e1">&nbsp;&nbsp;&nbsp;</td><td>#4169e1</td><td>65</td><td>105</td><td>225</td></tr>

<tr><td>royalblue_buse</td><td bgcolor="#be961e">&nbsp;&nbsp;&nbsp;</td><td>#be961e</td><td>190</td><td>150</td><td>30</td></tr>
<tr><td>steelblue</td><td bgcolor="#4682b4">&nbsp;&nbsp;&nbsp;</td><td>#4682b4</td><td>70</td><td>130</td><td>180</td></tr>

<tr><td>steelblue_buse</td><td bgcolor="#b97d4b">&nbsp;&nbsp;&nbsp;</td><td>#b97d4b</td><td>185</td><td>125</td><td>75</td></tr>
<tr><td>darkslateblue</td><td bgcolor="#483d8b">&nbsp;&nbsp;&nbsp;</td><td>#483d8b</td><td>72</td><td>61</td><td>139</td></tr>

<tr><td>darkslateblue_buse</td><td bgcolor="#b7c274">&nbsp;&nbsp;&nbsp;</td><td>#b7c274</td><td>183</td><td>194</td><td>116</td></tr>
<tr><td>mediumturquoise</td><td bgcolor="#48d1cc">&nbsp;&nbsp;&nbsp;</td><td>#48d1cc</td><td>72</td><td>209</td><td>204</td></tr>

<tr><td>mediumturquoise_buse</td><td bgcolor="#b72e33">&nbsp;&nbsp;&nbsp;</td><td>#b72e33</td><td>183</td><td>46</td><td>51</td></tr>
<tr><td>indigo</td><td bgcolor="#4b0082">&nbsp;&nbsp;&nbsp;</td><td>#4b0082</td><td>75</td><td>0</td><td>130</td></tr>

<tr><td>indigo_buse</td><td bgcolor="#b4ff7d">&nbsp;&nbsp;&nbsp;</td><td>#b4ff7d</td><td>180</td><td>255</td><td>125</td></tr>
<tr><td>darkolivegreen</td><td bgcolor="#556b2f">&nbsp;&nbsp;&nbsp;</td><td>#556b2f</td><td>85</td><td>107</td><td>47</td></tr>

<tr><td>darkolivegreen_buse</td><td bgcolor="#aa94d0">&nbsp;&nbsp;&nbsp;</td><td>#aa94d0</td><td>170</td><td>148</td><td>208</td></tr>
<tr><td>cadetblue</td><td bgcolor="#5f9ea0">&nbsp;&nbsp;&nbsp;</td><td>#5f9ea0</td><td>95</td><td>158</td><td>160</td></tr>

<tr><td>cadetblue_buse</td><td bgcolor="#a0615f">&nbsp;&nbsp;&nbsp;</td><td>#a0615f</td><td>160</td><td>97</td><td>95</td></tr>
<tr><td>purple_500</td><td bgcolor="#6200EE">&nbsp;&nbsp;&nbsp;</td><td>#6200EE</td><td>98</td><td>0</td><td>238</td></tr>

<tr><td>purple_500_buse</td><td bgcolor="#9dff11">&nbsp;&nbsp;&nbsp;</td><td>#9dff11</td><td>157</td><td>255</td><td>17</td></tr>
<tr><td>cornflowerblue</td><td bgcolor="#6495ed">&nbsp;&nbsp;&nbsp;</td><td>#6495ed</td><td>100</td><td>149</td><td>237</td></tr>

<tr><td>cornflowerblue_buse</td><td bgcolor="#9b6a12">&nbsp;&nbsp;&nbsp;</td><td>#9b6a12</td><td>155</td><td>106</td><td>18</td></tr>
<tr><td>mediumaquamarine</td><td bgcolor="#66cdaa">&nbsp;&nbsp;&nbsp;</td><td>#66cdaa</td><td>102</td><td>205</td><td>170</td></tr>

<tr><td>mediumaquamarine_buse</td><td bgcolor="#993255">&nbsp;&nbsp;&nbsp;</td><td>#993255</td><td>153</td><td>50</td><td>85</td></tr>
<tr><td>dimgray</td><td bgcolor="#696969">&nbsp;&nbsp;&nbsp;</td><td>#696969</td><td>105</td><td>105</td><td>105</td></tr>

<tr><td>dimgray_buse</td><td bgcolor="#969696">&nbsp;&nbsp;&nbsp;</td><td>#969696</td><td>150</td><td>150</td><td>150</td></tr>
<tr><td>dimgrey</td><td bgcolor="#696969">&nbsp;&nbsp;&nbsp;</td><td>#696969</td><td>105</td><td>105</td><td>105</td></tr>

<tr><td>dimgrey_buse</td><td bgcolor="#969696">&nbsp;&nbsp;&nbsp;</td><td>#969696</td><td>150</td><td>150</td><td>150</td></tr>
<tr><td>slateblue</td><td bgcolor="#6a5acd">&nbsp;&nbsp;&nbsp;</td><td>#6a5acd</td><td>106</td><td>90</td><td>205</td></tr>

<tr><td>slateblue_buse</td><td bgcolor="#95a532">&nbsp;&nbsp;&nbsp;</td><td>#95a532</td><td>149</td><td>165</td><td>50</td></tr>
<tr><td>olivedrab</td><td bgcolor="#6b8e23">&nbsp;&nbsp;&nbsp;</td><td>#6b8e23</td><td>107</td><td>142</td><td>35</td></tr>

<tr><td>olivedrab_buse</td><td bgcolor="#9471dc">&nbsp;&nbsp;&nbsp;</td><td>#9471dc</td><td>148</td><td>113</td><td>220</td></tr>
<tr><td>slategray</td><td bgcolor="#708090">&nbsp;&nbsp;&nbsp;</td><td>#708090</td><td>112</td><td>128</td><td>144</td></tr>

<tr><td>slategray_buse</td><td bgcolor="#8f7f6f">&nbsp;&nbsp;&nbsp;</td><td>#8f7f6f</td><td>143</td><td>127</td><td>111</td></tr>
<tr><td>slategrey</td><td bgcolor="#708090">&nbsp;&nbsp;&nbsp;</td><td>#708090</td><td>112</td><td>128</td><td>144</td></tr>

<tr><td>slategrey_buse</td><td bgcolor="#8f7f6f">&nbsp;&nbsp;&nbsp;</td><td>#8f7f6f</td><td>143</td><td>127</td><td>111</td></tr>
<tr><td>lightslategray</td><td bgcolor="#778899">&nbsp;&nbsp;&nbsp;</td><td>#778899</td><td>119</td><td>136</td><td>153</td></tr>

<tr><td>lightslategray_buse</td><td bgcolor="#887766">&nbsp;&nbsp;&nbsp;</td><td>#887766</td><td>136</td><td>119</td><td>102</td></tr>
<tr><td>lightslategrey</td><td bgcolor="#778899">&nbsp;&nbsp;&nbsp;</td><td>#778899</td><td>119</td><td>136</td><td>153</td></tr>

<tr><td>lightslategrey_buse</td><td bgcolor="#887766">&nbsp;&nbsp;&nbsp;</td><td>#887766</td><td>136</td><td>119</td><td>102</td></tr>
<tr><td>mediumslateblue</td><td bgcolor="#7b68ee">&nbsp;&nbsp;&nbsp;</td><td>#7b68ee</td><td>123</td><td>104</td><td>238</td></tr>

<tr><td>mediumslateblue_buse</td><td bgcolor="#849711">&nbsp;&nbsp;&nbsp;</td><td>#849711</td><td>132</td><td>151</td><td>17</td></tr>
<tr><td>lawngreen</td><td bgcolor="#7cfc00">&nbsp;&nbsp;&nbsp;</td><td>#7cfc00</td><td>124</td><td>252</td><td>0</td></tr>

<tr><td>lawngreen_buse</td><td bgcolor="#8303ff">&nbsp;&nbsp;&nbsp;</td><td>#8303ff</td><td>131</td><td>3</td><td>255</td></tr>
<tr><td>chartreuse</td><td bgcolor="#7fff00">&nbsp;&nbsp;&nbsp;</td><td>#7fff00</td><td>127</td><td>255</td><td>0</td></tr>

<tr><td>chartreuse_buse</td><td bgcolor="#8000ff">&nbsp;&nbsp;&nbsp;</td><td>#8000ff</td><td>128</td><td>0</td><td>255</td></tr>
<tr><td>aquamarine</td><td bgcolor="#7fffd4">&nbsp;&nbsp;&nbsp;</td><td>#7fffd4</td><td>127</td><td>255</td><td>212</td></tr>

<tr><td>aquamarine_buse</td><td bgcolor="#80002b">&nbsp;&nbsp;&nbsp;</td><td>#80002b</td><td>128</td><td>0</td><td>43</td></tr>
<tr><td>maroon</td><td bgcolor="#800000">&nbsp;&nbsp;&nbsp;</td><td>#800000</td><td>128</td><td>0</td><td>0</td></tr>

<tr><td>maroon_buse</td><td bgcolor="#7fffff">&nbsp;&nbsp;&nbsp;</td><td>#7fffff</td><td>127</td><td>255</td><td>255</td></tr>
<tr><td>purple</td><td bgcolor="#800080">&nbsp;&nbsp;&nbsp;</td><td>#800080</td><td>128</td><td>0</td><td>128</td></tr>

<tr><td>purple_buse</td><td bgcolor="#7fff7f">&nbsp;&nbsp;&nbsp;</td><td>#7fff7f</td><td>127</td><td>255</td><td>127</td></tr>
<tr><td>olive</td><td bgcolor="#808000">&nbsp;&nbsp;&nbsp;</td><td>#808000</td><td>128</td><td>128</td><td>0</td></tr>

<tr><td>olive_buse</td><td bgcolor="#7f7fff">&nbsp;&nbsp;&nbsp;</td><td>#7f7fff</td><td>127</td><td>127</td><td>255</td></tr>
<tr><td>gray</td><td bgcolor="#808080">&nbsp;&nbsp;&nbsp;</td><td>#808080</td><td>128</td><td>128</td><td>128</td></tr>

<tr><td>gray_buse</td><td bgcolor="#7f7f7f">&nbsp;&nbsp;&nbsp;</td><td>#7f7f7f</td><td>127</td><td>127</td><td>127</td></tr>
<tr><td>grey</td><td bgcolor="#808080">&nbsp;&nbsp;&nbsp;</td><td>#808080</td><td>128</td><td>128</td><td>128</td></tr>

<tr><td>grey_buse</td><td bgcolor="#7f7f7f">&nbsp;&nbsp;&nbsp;</td><td>#7f7f7f</td><td>127</td><td>127</td><td>127</td></tr>
<tr><td>skyblue</td><td bgcolor="#87ceeb">&nbsp;&nbsp;&nbsp;</td><td>#87ceeb</td><td>135</td><td>206</td><td>235</td></tr>

<tr><td>skyblue_buse</td><td bgcolor="#783114">&nbsp;&nbsp;&nbsp;</td><td>#783114</td><td>120</td><td>49</td><td>20</td></tr>
<tr><td>lightskyblue</td><td bgcolor="#87cefa">&nbsp;&nbsp;&nbsp;</td><td>#87cefa</td><td>135</td><td>206</td><td>250</td></tr>

<tr><td>lightskyblue_buse</td><td bgcolor="#783105">&nbsp;&nbsp;&nbsp;</td><td>#783105</td><td>120</td><td>49</td><td>5</td></tr>
<tr><td>blueviolet</td><td bgcolor="#8a2be2">&nbsp;&nbsp;&nbsp;</td><td>#8a2be2</td><td>138</td><td>43</td><td>226</td></tr>

<tr><td>blueviolet_buse</td><td bgcolor="#75d41d">&nbsp;&nbsp;&nbsp;</td><td>#75d41d</td><td>117</td><td>212</td><td>29</td></tr>
<tr><td>darkred</td><td bgcolor="#8b0000">&nbsp;&nbsp;&nbsp;</td><td>#8b0000</td><td>139</td><td>0</td><td>0</td></tr>

<tr><td>darkred_buse</td><td bgcolor="#74ffff">&nbsp;&nbsp;&nbsp;</td><td>#74ffff</td><td>116</td><td>255</td><td>255</td></tr>
<tr><td>darkmagenta</td><td bgcolor="#8b008b">&nbsp;&nbsp;&nbsp;</td><td>#8b008b</td><td>139</td><td>0</td><td>139</td></tr>

<tr><td>darkmagenta_buse</td><td bgcolor="#74ff74">&nbsp;&nbsp;&nbsp;</td><td>#74ff74</td><td>116</td><td>255</td><td>116</td></tr>
<tr><td>saddlebrown</td><td bgcolor="#8b4513">&nbsp;&nbsp;&nbsp;</td><td>#8b4513</td><td>139</td><td>69</td><td>19</td></tr>

<tr><td>saddlebrown_buse</td><td bgcolor="#74baec">&nbsp;&nbsp;&nbsp;</td><td>#74baec</td><td>116</td><td>186</td><td>236</td></tr>
<tr><td>darkseagreen</td><td bgcolor="#8fbc8f">&nbsp;&nbsp;&nbsp;</td><td>#8fbc8f</td><td>143</td><td>188</td><td>143</td></tr>

<tr><td>darkseagreen_buse</td><td bgcolor="#704370">&nbsp;&nbsp;&nbsp;</td><td>#704370</td><td>112</td><td>67</td><td>112</td></tr>
<tr><td>lightgreen</td><td bgcolor="#90ee90">&nbsp;&nbsp;&nbsp;</td><td>#90ee90</td><td>144</td><td>238</td><td>144</td></tr>

<tr><td>lightgreen_buse</td><td bgcolor="#6f116f">&nbsp;&nbsp;&nbsp;</td><td>#6f116f</td><td>111</td><td>17</td><td>111</td></tr>
<tr><td>mediumpurple</td><td bgcolor="#9370db">&nbsp;&nbsp;&nbsp;</td><td>#9370db</td><td>147</td><td>112</td><td>219</td></tr>

<tr><td>mediumpurple_buse</td><td bgcolor="#6c8f24">&nbsp;&nbsp;&nbsp;</td><td>#6c8f24</td><td>108</td><td>143</td><td>36</td></tr>
<tr><td>darkviolet</td><td bgcolor="#9400d3">&nbsp;&nbsp;&nbsp;</td><td>#9400d3</td><td>148</td><td>0</td><td>211</td></tr>

<tr><td>darkviolet_buse</td><td bgcolor="#6bff2c">&nbsp;&nbsp;&nbsp;</td><td>#6bff2c</td><td>107</td><td>255</td><td>44</td></tr>
<tr><td>palegreen</td><td bgcolor="#98fb98">&nbsp;&nbsp;&nbsp;</td><td>#98fb98</td><td>152</td><td>251</td><td>152</td></tr>

<tr><td>palegreen_buse</td><td bgcolor="#670467">&nbsp;&nbsp;&nbsp;</td><td>#670467</td><td>103</td><td>4</td><td>103</td></tr>
<tr><td>darkorchid</td><td bgcolor="#9932cc">&nbsp;&nbsp;&nbsp;</td><td>#9932cc</td><td>153</td><td>50</td><td>204</td></tr>

<tr><td>darkorchid_buse</td><td bgcolor="#66cd33">&nbsp;&nbsp;&nbsp;</td><td>#66cd33</td><td>102</td><td>205</td><td>51</td></tr>
<tr><td>sienna</td><td bgcolor="#a0522d">&nbsp;&nbsp;&nbsp;</td><td>#a0522d</td><td>160</td><td>82</td><td>45</td></tr>

<tr><td>sienna_buse</td><td bgcolor="#5fadd2">&nbsp;&nbsp;&nbsp;</td><td>#5fadd2</td><td>95</td><td>173</td><td>210</td></tr>
<tr><td>brown</td><td bgcolor="#a52a2a">&nbsp;&nbsp;&nbsp;</td><td>#a52a2a</td><td>165</td><td>42</td><td>42</td></tr>

<tr><td>brown_buse</td><td bgcolor="#5ad5d5">&nbsp;&nbsp;&nbsp;</td><td>#5ad5d5</td><td>90</td><td>213</td><td>213</td></tr>
<tr><td>darkgray</td><td bgcolor="#a9a9a9">&nbsp;&nbsp;&nbsp;</td><td>#a9a9a9</td><td>169</td><td>169</td><td>169</td></tr>

<tr><td>darkgray_buse</td><td bgcolor="#565656">&nbsp;&nbsp;&nbsp;</td><td>#565656</td><td>86</td><td>86</td><td>86</td></tr>
<tr><td>darkgrey</td><td bgcolor="#a9a9a9">&nbsp;&nbsp;&nbsp;</td><td>#a9a9a9</td><td>169</td><td>169</td><td>169</td></tr>

<tr><td>darkgrey_buse</td><td bgcolor="#565656">&nbsp;&nbsp;&nbsp;</td><td>#565656</td><td>86</td><td>86</td><td>86</td></tr>
<tr><td>lightblue</td><td bgcolor="#add8e6">&nbsp;&nbsp;&nbsp;</td><td>#add8e6</td><td>173</td><td>216</td><td>230</td></tr>

<tr><td>lightblue_buse</td><td bgcolor="#522719">&nbsp;&nbsp;&nbsp;</td><td>#522719</td><td>82</td><td>39</td><td>25</td></tr>
<tr><td>greenyellow</td><td bgcolor="#adff2f">&nbsp;&nbsp;&nbsp;</td><td>#adff2f</td><td>173</td><td>255</td><td>47</td></tr>

<tr><td>greenyellow_buse</td><td bgcolor="#5200d0">&nbsp;&nbsp;&nbsp;</td><td>#5200d0</td><td>82</td><td>0</td><td>208</td></tr>
<tr><td>paleturquoise</td><td bgcolor="#afeeee">&nbsp;&nbsp;&nbsp;</td><td>#afeeee</td><td>175</td><td>238</td><td>238</td></tr>

<tr><td>paleturquoise_buse</td><td bgcolor="#501111">&nbsp;&nbsp;&nbsp;</td><td>#501111</td><td>80</td><td>17</td><td>17</td></tr>
<tr><td>lightsteelblue</td><td bgcolor="#b0c4de">&nbsp;&nbsp;&nbsp;</td><td>#b0c4de</td><td>176</td><td>196</td><td>222</td></tr>

<tr><td>lightsteelblue_buse</td><td bgcolor="#4f3b21">&nbsp;&nbsp;&nbsp;</td><td>#4f3b21</td><td>79</td><td>59</td><td>33</td></tr>
<tr><td>powderblue</td><td bgcolor="#b0e0e6">&nbsp;&nbsp;&nbsp;</td><td>#b0e0e6</td><td>176</td><td>224</td><td>230</td></tr>

<tr><td>powderblue_buse</td><td bgcolor="#4f1f19">&nbsp;&nbsp;&nbsp;</td><td>#4f1f19</td><td>79</td><td>31</td><td>25</td></tr>
<tr><td>firebrick</td><td bgcolor="#b22222">&nbsp;&nbsp;&nbsp;</td><td>#b22222</td><td>178</td><td>34</td><td>34</td></tr>

<tr><td>firebrick_buse</td><td bgcolor="#4ddddd">&nbsp;&nbsp;&nbsp;</td><td>#4ddddd</td><td>77</td><td>221</td><td>221</td></tr>
<tr><td>darkgoldenrod</td><td bgcolor="#b8860b">&nbsp;&nbsp;&nbsp;</td><td>#b8860b</td><td>184</td><td>134</td><td>11</td></tr>

<tr><td>darkgoldenrod_buse</td><td bgcolor="#4779f4">&nbsp;&nbsp;&nbsp;</td><td>#4779f4</td><td>71</td><td>121</td><td>244</td></tr>
<tr><td>mediumorchid</td><td bgcolor="#ba55d3">&nbsp;&nbsp;&nbsp;</td><td>#ba55d3</td><td>186</td><td>85</td><td>211</td></tr>

<tr><td>mediumorchid_buse</td><td bgcolor="#45aa2c">&nbsp;&nbsp;&nbsp;</td><td>#45aa2c</td><td>69</td><td>170</td><td>44</td></tr>
<tr><td>purple_200</td><td bgcolor="#BB86FC">&nbsp;&nbsp;&nbsp;</td><td>#BB86FC</td><td>187</td><td>134</td><td>252</td></tr>

<tr><td>purple_200_buse</td><td bgcolor="#447903">&nbsp;&nbsp;&nbsp;</td><td>#447903</td><td>68</td><td>121</td><td>3</td></tr>
<tr><td>rosybrown</td><td bgcolor="#bc8f8f">&nbsp;&nbsp;&nbsp;</td><td>#bc8f8f</td><td>188</td><td>143</td><td>143</td></tr>

<tr><td>rosybrown_buse</td><td bgcolor="#437070">&nbsp;&nbsp;&nbsp;</td><td>#437070</td><td>67</td><td>112</td><td>112</td></tr>
<tr><td>darkkhaki</td><td bgcolor="#bdb76b">&nbsp;&nbsp;&nbsp;</td><td>#bdb76b</td><td>189</td><td>183</td><td>107</td></tr>

<tr><td>darkkhaki_buse</td><td bgcolor="#424894">&nbsp;&nbsp;&nbsp;</td><td>#424894</td><td>66</td><td>72</td><td>148</td></tr>
<tr><td>silver</td><td bgcolor="#c0c0c0">&nbsp;&nbsp;&nbsp;</td><td>#c0c0c0</td><td>192</td><td>192</td><td>192</td></tr>

<tr><td>silver_buse</td><td bgcolor="#3f3f3f">&nbsp;&nbsp;&nbsp;</td><td>#3f3f3f</td><td>63</td><td>63</td><td>63</td></tr>
<tr><td>mediumvioletred</td><td bgcolor="#c71585">&nbsp;&nbsp;&nbsp;</td><td>#c71585</td><td>199</td><td>21</td><td>133</td></tr>

<tr><td>mediumvioletred_buse</td><td bgcolor="#38ea7a">&nbsp;&nbsp;&nbsp;</td><td>#38ea7a</td><td>56</td><td>234</td><td>122</td></tr>
<tr><td>indianred</td><td bgcolor="#cd5c5c">&nbsp;&nbsp;&nbsp;</td><td>#cd5c5c</td><td>205</td><td>92</td><td>92</td></tr>

<tr><td>indianred_buse</td><td bgcolor="#32a3a3">&nbsp;&nbsp;&nbsp;</td><td>#32a3a3</td><td>50</td><td>163</td><td>163</td></tr>
<tr><td>peru</td><td bgcolor="#cd853f">&nbsp;&nbsp;&nbsp;</td><td>#cd853f</td><td>205</td><td>133</td><td>63</td></tr>

<tr><td>peru_buse</td><td bgcolor="#327ac0">&nbsp;&nbsp;&nbsp;</td><td>#327ac0</td><td>50</td><td>122</td><td>192</td></tr>
<tr><td>chocolate</td><td bgcolor="#d2691e">&nbsp;&nbsp;&nbsp;</td><td>#d2691e</td><td>210</td><td>105</td><td>30</td></tr>

<tr><td>chocolate_buse</td><td bgcolor="#2d96e1">&nbsp;&nbsp;&nbsp;</td><td>#2d96e1</td><td>45</td><td>150</td><td>225</td></tr>
<tr><td>tan</td><td bgcolor="#d2b48c">&nbsp;&nbsp;&nbsp;</td><td>#d2b48c</td><td>210</td><td>180</td><td>140</td></tr>

<tr><td>tan_buse</td><td bgcolor="#2d4b73">&nbsp;&nbsp;&nbsp;</td><td>#2d4b73</td><td>45</td><td>75</td><td>115</td></tr>
<tr><td>lightgray</td><td bgcolor="#d3d3d3">&nbsp;&nbsp;&nbsp;</td><td>#d3d3d3</td><td>211</td><td>211</td><td>211</td></tr>

<tr><td>lightgray_buse</td><td bgcolor="#2c2c2c">&nbsp;&nbsp;&nbsp;</td><td>#2c2c2c</td><td>44</td><td>44</td><td>44</td></tr>
<tr><td>lightgrey</td><td bgcolor="#d3d3d3">&nbsp;&nbsp;&nbsp;</td><td>#d3d3d3</td><td>211</td><td>211</td><td>211</td></tr>

<tr><td>lightgrey_buse</td><td bgcolor="#2c2c2c">&nbsp;&nbsp;&nbsp;</td><td>#2c2c2c</td><td>44</td><td>44</td><td>44</td></tr>
<tr><td>thistle</td><td bgcolor="#d8bfd8">&nbsp;&nbsp;&nbsp;</td><td>#d8bfd8</td><td>216</td><td>191</td><td>216</td></tr>

<tr><td>thistle_buse</td><td bgcolor="#274027">&nbsp;&nbsp;&nbsp;</td><td>#274027</td><td>39</td><td>64</td><td>39</td></tr>
<tr><td>orchid</td><td bgcolor="#da70d6">&nbsp;&nbsp;&nbsp;</td><td>#da70d6</td><td>218</td><td>112</td><td>214</td></tr>

<tr><td>orchid_buse</td><td bgcolor="#258f29">&nbsp;&nbsp;&nbsp;</td><td>#258f29</td><td>37</td><td>143</td><td>41</td></tr>
<tr><td>goldenrod</td><td bgcolor="#daa520">&nbsp;&nbsp;&nbsp;</td><td>#daa520</td><td>218</td><td>165</td><td>32</td></tr>

<tr><td>goldenrod_buse</td><td bgcolor="#255adf">&nbsp;&nbsp;&nbsp;</td><td>#255adf</td><td>37</td><td>90</td><td>223</td></tr>
<tr><td>palevioletred</td><td bgcolor="#db7093">&nbsp;&nbsp;&nbsp;</td><td>#db7093</td><td>219</td><td>112</td><td>147</td></tr>

<tr><td>palevioletred_buse</td><td bgcolor="#248f6c">&nbsp;&nbsp;&nbsp;</td><td>#248f6c</td><td>36</td><td>143</td><td>108</td></tr>
<tr><td>crimson</td><td bgcolor="#dc143c">&nbsp;&nbsp;&nbsp;</td><td>#dc143c</td><td>220</td><td>20</td><td>60</td></tr>

<tr><td>crimson_buse</td><td bgcolor="#23ebc3">&nbsp;&nbsp;&nbsp;</td><td>#23ebc3</td><td>35</td><td>235</td><td>195</td></tr>
<tr><td>gainsboro</td><td bgcolor="#dcdcdc">&nbsp;&nbsp;&nbsp;</td><td>#dcdcdc</td><td>220</td><td>220</td><td>220</td></tr>

<tr><td>gainsboro_buse</td><td bgcolor="#232323">&nbsp;&nbsp;&nbsp;</td><td>#232323</td><td>35</td><td>35</td><td>35</td></tr>
<tr><td>plum</td><td bgcolor="#dda0dd">&nbsp;&nbsp;&nbsp;</td><td>#dda0dd</td><td>221</td><td>160</td><td>221</td></tr>

<tr><td>plum_buse</td><td bgcolor="#225f22">&nbsp;&nbsp;&nbsp;</td><td>#225f22</td><td>34</td><td>95</td><td>34</td></tr>
<tr><td>burlywood</td><td bgcolor="#deb887">&nbsp;&nbsp;&nbsp;</td><td>#deb887</td><td>222</td><td>184</td><td>135</td></tr>

<tr><td>burlywood_buse</td><td bgcolor="#214778">&nbsp;&nbsp;&nbsp;</td><td>#214778</td><td>33</td><td>71</td><td>120</td></tr>
<tr><td>lightcyan</td><td bgcolor="#e0ffff">&nbsp;&nbsp;&nbsp;</td><td>#e0ffff</td><td>224</td><td>255</td><td>255</td></tr>

<tr><td>lightcyan_buse</td><td bgcolor="#1f0000">&nbsp;&nbsp;&nbsp;</td><td>#1f0000</td><td>31</td><td>0</td><td>0</td></tr>
<tr><td>lavender</td><td bgcolor="#e6e6fa">&nbsp;&nbsp;&nbsp;</td><td>#e6e6fa</td><td>230</td><td>230</td><td>250</td></tr>

<tr><td>lavender_buse</td><td bgcolor="#191905">&nbsp;&nbsp;&nbsp;</td><td>#191905</td><td>25</td><td>25</td><td>5</td></tr>
<tr><td>darksalmon</td><td bgcolor="#e9967a">&nbsp;&nbsp;&nbsp;</td><td>#e9967a</td><td>233</td><td>150</td><td>122</td></tr>

<tr><td>darksalmon_buse</td><td bgcolor="#166985">&nbsp;&nbsp;&nbsp;</td><td>#166985</td><td>22</td><td>105</td><td>133</td></tr>
<tr><td>violet</td><td bgcolor="#ee82ee">&nbsp;&nbsp;&nbsp;</td><td>#ee82ee</td><td>238</td><td>130</td><td>238</td></tr>

<tr><td>violet_buse</td><td bgcolor="#117d11">&nbsp;&nbsp;&nbsp;</td><td>#117d11</td><td>17</td><td>125</td><td>17</td></tr>
<tr><td>palegoldenrod</td><td bgcolor="#eee8aa">&nbsp;&nbsp;&nbsp;</td><td>#eee8aa</td><td>238</td><td>232</td><td>170</td></tr>

<tr><td>palegoldenrod_buse</td><td bgcolor="#111755">&nbsp;&nbsp;&nbsp;</td><td>#111755</td><td>17</td><td>23</td><td>85</td></tr>
<tr><td>lightcoral</td><td bgcolor="#f08080">&nbsp;&nbsp;&nbsp;</td><td>#f08080</td><td>240</td><td>128</td><td>128</td></tr>

<tr><td>lightcoral_buse</td><td bgcolor="#0f7f7f">&nbsp;&nbsp;&nbsp;</td><td>#0f7f7f</td><td>15</td><td>127</td><td>127</td></tr>
<tr><td>khaki</td><td bgcolor="#f0e68c">&nbsp;&nbsp;&nbsp;</td><td>#f0e68c</td><td>240</td><td>230</td><td>140</td></tr>

<tr><td>khaki_buse</td><td bgcolor="#0f1973">&nbsp;&nbsp;&nbsp;</td><td>#0f1973</td><td>15</td><td>25</td><td>115</td></tr>
<tr><td>aliceblue</td><td bgcolor="#f0f8ff">&nbsp;&nbsp;&nbsp;</td><td>#f0f8ff</td><td>240</td><td>248</td><td>255</td></tr>

<tr><td>aliceblue_buse</td><td bgcolor="#0f0700">&nbsp;&nbsp;&nbsp;</td><td>#0f0700</td><td>15</td><td>7</td><td>0</td></tr>
<tr><td>honeydew</td><td bgcolor="#f0fff0">&nbsp;&nbsp;&nbsp;</td><td>#f0fff0</td><td>240</td><td>255</td><td>240</td></tr>

<tr><td>honeydew_buse</td><td bgcolor="#0f000f">&nbsp;&nbsp;&nbsp;</td><td>#0f000f</td><td>15</td><td>0</td><td>15</td></tr>
<tr><td>azure</td><td bgcolor="#f0ffff">&nbsp;&nbsp;&nbsp;</td><td>#f0ffff</td><td>240</td><td>255</td><td>255</td></tr>

<tr><td>azure_buse</td><td bgcolor="#0f0000">&nbsp;&nbsp;&nbsp;</td><td>#0f0000</td><td>15</td><td>0</td><td>0</td></tr>
<tr><td>sandybrown</td><td bgcolor="#f4a460">&nbsp;&nbsp;&nbsp;</td><td>#f4a460</td><td>244</td><td>164</td><td>96</td></tr>

<tr><td>sandybrown_buse</td><td bgcolor="#0b5b9f">&nbsp;&nbsp;&nbsp;</td><td>#0b5b9f</td><td>11</td><td>91</td><td>159</td></tr>
<tr><td>wheat</td><td bgcolor="#f5deb3">&nbsp;&nbsp;&nbsp;</td><td>#f5deb3</td><td>245</td><td>222</td><td>179</td></tr>

<tr><td>wheat_buse</td><td bgcolor="#0a214c">&nbsp;&nbsp;&nbsp;</td><td>#0a214c</td><td>10</td><td>33</td><td>76</td></tr>
<tr><td>beige</td><td bgcolor="#f5f5dc">&nbsp;&nbsp;&nbsp;</td><td>#f5f5dc</td><td>245</td><td>245</td><td>220</td></tr>

<tr><td>beige_buse</td><td bgcolor="#0a0a23">&nbsp;&nbsp;&nbsp;</td><td>#0a0a23</td><td>10</td><td>10</td><td>35</td></tr>
<tr><td>whitesmoke</td><td bgcolor="#f5f5f5">&nbsp;&nbsp;&nbsp;</td><td>#f5f5f5</td><td>245</td><td>245</td><td>245</td></tr>

<tr><td>whitesmoke_buse</td><td bgcolor="#0a0a0a">&nbsp;&nbsp;&nbsp;</td><td>#0a0a0a</td><td>10</td><td>10</td><td>10</td></tr>
<tr><td>mintcream</td><td bgcolor="#f5fffa">&nbsp;&nbsp;&nbsp;</td><td>#f5fffa</td><td>245</td><td>255</td><td>250</td></tr>

<tr><td>mintcream_buse</td><td bgcolor="#0a0005">&nbsp;&nbsp;&nbsp;</td><td>#0a0005</td><td>10</td><td>0</td><td>5</td></tr>
<tr><td>ghostwhite</td><td bgcolor="#f8f8ff">&nbsp;&nbsp;&nbsp;</td><td>#f8f8ff</td><td>248</td><td>248</td><td>255</td></tr>

<tr><td>ghostwhite_buse</td><td bgcolor="#070700">&nbsp;&nbsp;&nbsp;</td><td>#070700</td><td>7</td><td>7</td><td>0</td></tr>
<tr><td>salmon</td><td bgcolor="#fa8072">&nbsp;&nbsp;&nbsp;</td><td>#fa8072</td><td>250</td><td>128</td><td>114</td></tr>

<tr><td>salmon_buse</td><td bgcolor="#057f8d">&nbsp;&nbsp;&nbsp;</td><td>#057f8d</td><td>5</td><td>127</td><td>141</td></tr>
<tr><td>antiquewhite</td><td bgcolor="#faebd7">&nbsp;&nbsp;&nbsp;</td><td>#faebd7</td><td>250</td><td>235</td><td>215</td></tr>

<tr><td>antiquewhite_buse</td><td bgcolor="#051428">&nbsp;&nbsp;&nbsp;</td><td>#051428</td><td>5</td><td>20</td><td>40</td></tr>
<tr><td>linen</td><td bgcolor="#faf0e6">&nbsp;&nbsp;&nbsp;</td><td>#faf0e6</td><td>250</td><td>240</td><td>230</td></tr>

<tr><td>linen_buse</td><td bgcolor="#050f19">&nbsp;&nbsp;&nbsp;</td><td>#050f19</td><td>5</td><td>15</td><td>25</td></tr>
<tr><td>lightgoldenrodyellow</td><td bgcolor="#fafad2">&nbsp;&nbsp;&nbsp;</td><td>#fafad2</td><td>250</td><td>250</td><td>210</td></tr>

<tr><td>lightgoldenrodyellow_buse</td><td bgcolor="#05052d">&nbsp;&nbsp;&nbsp;</td><td>#05052d</td><td>5</td><td>5</td><td>45</td></tr>
<tr><td>oldlace</td><td bgcolor="#fdf5e6">&nbsp;&nbsp;&nbsp;</td><td>#fdf5e6</td><td>253</td><td>245</td><td>230</td></tr>

<tr><td>oldlace_buse</td><td bgcolor="#020a19">&nbsp;&nbsp;&nbsp;</td><td>#020a19</td><td>2</td><td>10</td><td>25</td></tr>
<tr><td>red</td><td bgcolor="#ff0000">&nbsp;&nbsp;&nbsp;</td><td>#ff0000</td><td>255</td><td>0</td><td>0</td></tr>

<tr><td>red_buse</td><td bgcolor="#00ffff">&nbsp;&nbsp;&nbsp;</td><td>#00ffff</td><td>0</td><td>255</td><td>255</td></tr>
<tr><td>fuchsia</td><td bgcolor="#ff00ff">&nbsp;&nbsp;&nbsp;</td><td>#ff00ff</td><td>255</td><td>0</td><td>255</td></tr>

<tr><td>fuchsia_buse</td><td bgcolor="#00ff00">&nbsp;&nbsp;&nbsp;</td><td>#00ff00</td><td>0</td><td>255</td><td>0</td></tr>
<tr><td>magenta</td><td bgcolor="#ff00ff">&nbsp;&nbsp;&nbsp;</td><td>#ff00ff</td><td>255</td><td>0</td><td>255</td></tr>

<tr><td>magenta_buse</td><td bgcolor="#00ff00">&nbsp;&nbsp;&nbsp;</td><td>#00ff00</td><td>0</td><td>255</td><td>0</td></tr>
<tr><td>deeppink</td><td bgcolor="#ff1493">&nbsp;&nbsp;&nbsp;</td><td>#ff1493</td><td>255</td><td>20</td><td>147</td></tr>

<tr><td>deeppink_buse</td><td bgcolor="#00eb6c">&nbsp;&nbsp;&nbsp;</td><td>#00eb6c</td><td>0</td><td>235</td><td>108</td></tr>
<tr><td>orangered</td><td bgcolor="#ff4500">&nbsp;&nbsp;&nbsp;</td><td>#ff4500</td><td>255</td><td>69</td><td>0</td></tr>

<tr><td>orangered_buse</td><td bgcolor="#00baff">&nbsp;&nbsp;&nbsp;</td><td>#00baff</td><td>0</td><td>186</td><td>255</td></tr>
<tr><td>tomato</td><td bgcolor="#ff6347">&nbsp;&nbsp;&nbsp;</td><td>#ff6347</td><td>255</td><td>99</td><td>71</td></tr>

<tr><td>tomato_buse</td><td bgcolor="#009cb8">&nbsp;&nbsp;&nbsp;</td><td>#009cb8</td><td>0</td><td>156</td><td>184</td></tr>
<tr><td>hotpink</td><td bgcolor="#ff69b4">&nbsp;&nbsp;&nbsp;</td><td>#ff69b4</td><td>255</td><td>105</td><td>180</td></tr>

<tr><td>hotpink_buse</td><td bgcolor="#00964b">&nbsp;&nbsp;&nbsp;</td><td>#00964b</td><td>0</td><td>150</td><td>75</td></tr>
<tr><td>coral</td><td bgcolor="#ff7f50">&nbsp;&nbsp;&nbsp;</td><td>#ff7f50</td><td>255</td><td>127</td><td>80</td></tr>

<tr><td>coral_buse</td><td bgcolor="#0080af">&nbsp;&nbsp;&nbsp;</td><td>#0080af</td><td>0</td><td>128</td><td>175</td></tr>
<tr><td>darkorange</td><td bgcolor="#ff8c00">&nbsp;&nbsp;&nbsp;</td><td>#ff8c00</td><td>255</td><td>140</td><td>0</td></tr>

<tr><td>darkorange_buse</td><td bgcolor="#0073ff">&nbsp;&nbsp;&nbsp;</td><td>#0073ff</td><td>0</td><td>115</td><td>255</td></tr>
<tr><td>lightsalmon</td><td bgcolor="#ffa07a">&nbsp;&nbsp;&nbsp;</td><td>#ffa07a</td><td>255</td><td>160</td><td>122</td></tr>

<tr><td>lightsalmon_buse</td><td bgcolor="#005f85">&nbsp;&nbsp;&nbsp;</td><td>#005f85</td><td>0</td><td>95</td><td>133</td></tr>
<tr><td>orange</td><td bgcolor="#ffa500">&nbsp;&nbsp;&nbsp;</td><td>#ffa500</td><td>255</td><td>165</td><td>0</td></tr>

<tr><td>orange_buse</td><td bgcolor="#005aff">&nbsp;&nbsp;&nbsp;</td><td>#005aff</td><td>0</td><td>90</td><td>255</td></tr>
<tr><td>lightpink</td><td bgcolor="#ffb6c1">&nbsp;&nbsp;&nbsp;</td><td>#ffb6c1</td><td>255</td><td>182</td><td>193</td></tr>

<tr><td>lightpink_buse</td><td bgcolor="#00493e">&nbsp;&nbsp;&nbsp;</td><td>#00493e</td><td>0</td><td>73</td><td>62</td></tr>
<tr><td>pink</td><td bgcolor="#ffc0cb">&nbsp;&nbsp;&nbsp;</td><td>#ffc0cb</td><td>255</td><td>192</td><td>203</td></tr>

<tr><td>pink_buse</td><td bgcolor="#003f34">&nbsp;&nbsp;&nbsp;</td><td>#003f34</td><td>0</td><td>63</td><td>52</td></tr>
<tr><td>gold</td><td bgcolor="#ffd700">&nbsp;&nbsp;&nbsp;</td><td>#ffd700</td><td>255</td><td>215</td><td>0</td></tr>

<tr><td>gold_buse</td><td bgcolor="#0028ff">&nbsp;&nbsp;&nbsp;</td><td>#0028ff</td><td>0</td><td>40</td><td>255</td></tr>
<tr><td>peachpuff</td><td bgcolor="#ffdab9">&nbsp;&nbsp;&nbsp;</td><td>#ffdab9</td><td>255</td><td>218</td><td>185</td></tr>

<tr><td>peachpuff_buse</td><td bgcolor="#002546">&nbsp;&nbsp;&nbsp;</td><td>#002546</td><td>0</td><td>37</td><td>70</td></tr>
<tr><td>navajowhite</td><td bgcolor="#ffdead">&nbsp;&nbsp;&nbsp;</td><td>#ffdead</td><td>255</td><td>222</td><td>173</td></tr>

<tr><td>navajowhite_buse</td><td bgcolor="#002152">&nbsp;&nbsp;&nbsp;</td><td>#002152</td><td>0</td><td>33</td><td>82</td></tr>
<tr><td>moccasin</td><td bgcolor="#ffe4b5">&nbsp;&nbsp;&nbsp;</td><td>#ffe4b5</td><td>255</td><td>228</td><td>181</td></tr>

<tr><td>moccasin_buse</td><td bgcolor="#001b4a">&nbsp;&nbsp;&nbsp;</td><td>#001b4a</td><td>0</td><td>27</td><td>74</td></tr>
<tr><td>bisque</td><td bgcolor="#ffe4c4">&nbsp;&nbsp;&nbsp;</td><td>#ffe4c4</td><td>255</td><td>228</td><td>196</td></tr>

<tr><td>bisque_buse</td><td bgcolor="#001b3b">&nbsp;&nbsp;&nbsp;</td><td>#001b3b</td><td>0</td><td>27</td><td>59</td></tr>
<tr><td>mistyrose</td><td bgcolor="#ffe4e1">&nbsp;&nbsp;&nbsp;</td><td>#ffe4e1</td><td>255</td><td>228</td><td>225</td></tr>

<tr><td>mistyrose_buse</td><td bgcolor="#001b1e">&nbsp;&nbsp;&nbsp;</td><td>#001b1e</td><td>0</td><td>27</td><td>30</td></tr>
<tr><td>blanchedalmond</td><td bgcolor="#ffebcd">&nbsp;&nbsp;&nbsp;</td><td>#ffebcd</td><td>255</td><td>235</td><td>205</td></tr>

<tr><td>blanchedalmond_buse</td><td bgcolor="#001432">&nbsp;&nbsp;&nbsp;</td><td>#001432</td><td>0</td><td>20</td><td>50</td></tr>
<tr><td>papayawhip</td><td bgcolor="#ffefd5">&nbsp;&nbsp;&nbsp;</td><td>#ffefd5</td><td>255</td><td>239</td><td>213</td></tr>

<tr><td>papayawhip_buse</td><td bgcolor="#00102a">&nbsp;&nbsp;&nbsp;</td><td>#00102a</td><td>0</td><td>16</td><td>42</td></tr>
<tr><td>lavenderblush</td><td bgcolor="#fff0f5">&nbsp;&nbsp;&nbsp;</td><td>#fff0f5</td><td>255</td><td>240</td><td>245</td></tr>

<tr><td>lavenderblush_buse</td><td bgcolor="#000f0a">&nbsp;&nbsp;&nbsp;</td><td>#000f0a</td><td>0</td><td>15</td><td>10</td></tr>
<tr><td>seaShell</td><td bgcolor="#fff5ee">&nbsp;&nbsp;&nbsp;</td><td>#fff5ee</td><td>255</td><td>245</td><td>238</td></tr>

<tr><td>seaShell_buse</td><td bgcolor="#000a11">&nbsp;&nbsp;&nbsp;</td><td>#000a11</td><td>0</td><td>10</td><td>17</td></tr>
<tr><td>cornsilk</td><td bgcolor="#fff8dc">&nbsp;&nbsp;&nbsp;</td><td>#fff8dc</td><td>255</td><td>248</td><td>220</td></tr>

<tr><td>cornsilk_buse</td><td bgcolor="#000723">&nbsp;&nbsp;&nbsp;</td><td>#000723</td><td>0</td><td>7</td><td>35</td></tr>
<tr><td>lemonchiffon</td><td bgcolor="#fffacd">&nbsp;&nbsp;&nbsp;</td><td>#fffacd</td><td>255</td><td>250</td><td>205</td></tr>

<tr><td>lemonchiffon_buse</td><td bgcolor="#000532">&nbsp;&nbsp;&nbsp;</td><td>#000532</td><td>0</td><td>5</td><td>50</td></tr>
<tr><td>floralwhite</td><td bgcolor="#fffaf0">&nbsp;&nbsp;&nbsp;</td><td>#fffaf0</td><td>255</td><td>250</td><td>240</td></tr>

<tr><td>floralwhite_buse</td><td bgcolor="#00050f">&nbsp;&nbsp;&nbsp;</td><td>#00050f</td><td>0</td><td>5</td><td>15</td></tr>
<tr><td>snow</td><td bgcolor="#fffafa">&nbsp;&nbsp;&nbsp;</td><td>#fffafa</td><td>255</td><td>250</td><td>250</td></tr>

<tr><td>snow_buse</td><td bgcolor="#000505">&nbsp;&nbsp;&nbsp;</td><td>#000505</td><td>0</td><td>5</td><td>5</td></tr>
<tr><td>yellow</td><td bgcolor="#ffff00">&nbsp;&nbsp;&nbsp;</td><td>#ffff00</td><td>255</td><td>255</td><td>0</td></tr>

<tr><td>yellow_buse</td><td bgcolor="#0000ff">&nbsp;&nbsp;&nbsp;</td><td>#0000ff</td><td>0</td><td>0</td><td>255</td></tr>
<tr><td>lightyellow</td><td bgcolor="#ffffe0">&nbsp;&nbsp;&nbsp;</td><td>#ffffe0</td><td>255</td><td>255</td><td>224</td></tr>

<tr><td>lightyellow_buse</td><td bgcolor="#00001f">&nbsp;&nbsp;&nbsp;</td><td>#00001f</td><td>0</td><td>0</td><td>31</td></tr>
<tr><td>ivory</td><td bgcolor="#fffff0">&nbsp;&nbsp;&nbsp;</td><td>#fffff0</td><td>255</td><td>255</td><td>240</td></tr>

<tr><td>ivory_buse</td><td bgcolor="#00000f">&nbsp;&nbsp;&nbsp;</td><td>#00000f</td><td>0</td><td>0</td><td>15</td></tr>
<tr><td>white</td><td bgcolor="#ffffff">&nbsp;&nbsp;&nbsp;</td><td>#ffffff</td><td>255</td><td>255</td><td>255</td></tr>

<tr><td>white_buse</td><td bgcolor="#000000">&nbsp;&nbsp;&nbsp;</td><td>#000000</td><td>0</td><td>0</td><td>0</td></tr>

</table>

</body>
</html>