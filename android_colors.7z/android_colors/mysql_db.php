<?php
$servername = "localhost";
$username   = "root";
$password   = "abcd1234";
$dbname     = "android";


global $connection;


// Create connection
$connection = mysqli_connect ( $servername, $username, $password, $dbname );
// Check connection
if (!$connection) {
	die("Connection failed: " . mysqli_connect_error());
}

$connection->set_charset("utf8");

// mysqli_query("SET NAMES utf8");

// PHP timezone �x�W�ɰϳ]�w
// https://injerry.pixnet.net/blog/post/55554030
date_default_timezone_set('Asia/Taipei');

function Insert_Data($DataTable,$my_array) {
	global $connection;
	if (is_array($my_array)) {
			foreach ($my_array as $key=>$value) {
				$fields_array[] = $key;
				$values_array[] = $value;
			}
			$fields = join(", ", $fields_array);
			$values = join(", ", $values_array);
		$sql = "INSERT INTO ".$DataTable." (".$fields.") values (".$values.")";
		$sql = str_replace ("\\\\", "\\",$sql);
		return mysqli_query($connection, $sql) or die ("Invalid query ".$sql);
	} else {
		return -1;
	}
}

function Update_Data($DataTable,$my_array,$where) {
	global $connection;
	global $SQLDATA;
	global $SQLPATH;
	global $OPERATOR_ID;
	global $KeyId;
	global $KeyIdVar;

	if (is_array($my_array)) {
			foreach ($my_array as $key=>$value) {
				$set_array[] = "$key=$value";
			}
			$sets = join(", ", $set_array);
		$sql  = "UPDATE ".$DataTable." Set ".$sets." WHERE ".$where;
		$sql  = str_replace ("\\\\", "\\",$sql);
		return mysqli_query( $connection, $sql) or die ("Invalid query ".$sql);
	} else {
		return -1;
	}
}
