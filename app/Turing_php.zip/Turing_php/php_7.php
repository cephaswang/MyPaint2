
<pre>

https://www.w3schools.com/php/php_compiler.asp

You are a PHP developer at Turing.You are developing the following code.
Which line should be changed so it outputs the number 2:

您是 Turing 的一名 PHP 开发人员。您正在开发以下代码。
应该更改哪一行以输出数字 2：



<?php

class Turing {
    protected $x = array();
    public function &getx()  /// *******
    {
        return $this->x;
    }
}

$tur = new Turing();
array_push($tur->getx(),"turing_one");
array_push($tur->getx(),"turing_two");
echo count($tur->getx());
