<?php


function turing($x) {
	return function ($y) use ($x) { 
		return str_repeat($y, $x);
	};
}

$a = turing(2); 
$b = turing(3) ; 
echo $a(3) . $b(2);

/*

C:\Turing_php>php php_43.php
33222

*/
