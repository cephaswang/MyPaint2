<?php

class Turing { 
	public $ello = 'ello'; 
	public $c; 
	public $m; 

	function _construct($y) { 
		$this->c = static function($f) {
			return $this->m()."ello";
		};

		$this->m = function() { 
			return "h"; 
		};
	}

}

$x = new Turing("h");
$f = $x->c; 
echo $f($x->m); 
