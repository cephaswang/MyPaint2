<?php

$string = "7string";

switch($string) 
{
	case 1: 
		echo "this is 1"; 
		break; 
	case 7: 
		echo "this is 7"; 
		break; 
	case '2string': 
		echo "this is a string"; 
		break; 
	default: 
		echo "Default message"; 
		break; 
}

/*

C:\Turing_php>php php_39.php
Default message

*/