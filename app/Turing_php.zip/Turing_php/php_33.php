<?php

class Turing { 
	public function call($name, $args){
		call_user_fun_array(array('static',"test$name"),$args);
	}
	public function testS($L) {
		echo "$L, ";
	}
}

class Turing2 extends Turing { 
	public function testS($L) { 
		echo "$L, $L, ";
	}
}

$test = new Turing2(); 
$test->testS( 'A' ) ; 


/*

C:\Turing_php>php php_33.php
A, A,

*/
