<?php

$truing = function() { return "turing"; };
echo gettype($truing);

/*

C:\Turing_php>php php_35.php
object

*/