<?php


namespace TuringCom\DB; 

class TuringClass
{
	static function myTuring()
	{
		return __METHOD__;
	}
}

print TuringClass::myTuring(); 


/*

C:\Turing_php>php php_30.php
TuringCom\DB\TuringClass::myTuring

*/