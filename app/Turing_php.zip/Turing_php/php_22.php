<?php

class Turing{
	private $m = 'n';
	public $o  = 'p';
}

$turingl = ( array) new  Turing(); 

echo array_key_exists( 'm' , $turingl) ? "true":"false";
echo "-";
echo array_key_exists( 'o' , $turingl) ? "true":"false";

/*

C:\Turing_php>php php_22.php
false-true

*/