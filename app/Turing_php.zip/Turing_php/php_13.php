<?php

function updateTuringArray (&$turing_array)
{
foreach ($turing_array as &$value)
	{
		$value = $value + 1;
	}
	$value = $value + 2;
}


$turing_array = array (1, 2, 3);
updateTuringArray( $turing_array);
print_r($turing_array);

/*

C:\Turing_php>php php_13.php
Array
(
    [0] => 2
    [1] => 3
    [2] => 6
)

*/

?>
