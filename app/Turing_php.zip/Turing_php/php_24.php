<?php

/*

id	name	email
1	Alibaba	alibaba@turing.com
2	Boeing	boeing@turing.com
3	Cleopatra	cleopatra@turing.com
5	Cesar	cesar@turing.com

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

INSERT INTO `users` (`id`, `name`, `email`) VALUES ('1', 'Alibaba', 'alibaba@turing.com');
INSERT INTO `users` (`id`, `name`, `email`) VALUES ('2', 'Boeing', 'boeing@turing.com');
INSERT INTO `users` (`id`, `name`, `email`) VALUES ('3', 'Cleopatra', 'cleopatra@turing.com');
INSERT INTO `users` (`id`, `name`, `email`) VALUES ('4', 'Cesar', 'cesar@turing.com');

PDO = new PDO('mysql:host=資料庫位址;port=連接連接埠;dbname=資料庫名稱', '帳號', '密碼', $options);

*/



$dsn_turing = "mysql:host=127.0.0.1;dbname=turing_exam";
$turing_user = 'turing'; 
$turing_pass = 'turing';
$turing_pdo = new PDO($dsn_turing, $turing_user, $turing_pass);
$cmd = "SELECT * FROM users as u WHERE u.id = :id";
$turing_stmt = $turing_pdo->prepare($cmd);
$id = 3;
$turing_stmt->bindParam( 'id' , $id);
$turing_stmt->execute();
$turing_stmt—>bindColumn(3, $turing_result);
$turing_row =  $turing_stmt—>fetch(PDO::FETCH_BOUND);
