abstract class Turing{
protected function construct(){
}
public static function create(){

return new self();
}

abstract function action();

class Item extends Turing{
public function action(){ echo CLASS; }
}


$item = Item::create();
$item->action();

