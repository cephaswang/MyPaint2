import SwiftUI
import WebKit
import Network

struct WebView: UIViewRepresentable {
    
    class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler, UIScrollViewDelegate, URLSessionDelegate , URLSessionDownloadDelegate{
        
        func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
            print(location)
        }
        
        var webView: WKWebView?
        var session:URLSession? = nil
        var DownloadTaskSession : URLSessionDownloadTask!
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            self.webView = webView
            self.webView!.scrollView.delegate = self
        }
        
        // receive message from wkwebview
        func userContentController(
            _ userContentController: WKUserContentController,
            didReceive message: WKScriptMessage
        ) {
            print(message.body)
        }
    }
    

    
    //MARK: - UIScrollViewDelegate
    func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
             scrollView.pinchGestureRecognizer?.isEnabled = false
    }

    
    func makeCoordinator() -> Coordinator {
        return Coordinator()
    }
    
    // Disable zoom in WKWebView?
    // https://stackoverflow.com/questions/40452034/disable-zoom-in-wkwebview
    
    func makeUIView(context: Context) -> WKWebView {

        let source: String =
            "var meta = document.createElement('meta');" +
            "meta.name = 'viewport';" +
            "meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';" +
            "var head = document.getElementsByTagName('head')[0];" +
            "head.appendChild(meta);"// +

       // print(source)

        let script: WKUserScript = WKUserScript(source: source, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        
        let coordinator = makeCoordinator()
        let userContentController = WKUserContentController()
      //  userContentController.add(coordinator, name: "bridge")
        userContentController.addUserScript(script)
        
        let configuration = WKWebViewConfiguration()
        configuration.userContentController = userContentController
        
        let _wkwebview = WKWebView(frame: .zero, configuration: configuration)
        _wkwebview.navigationDelegate = coordinator
        
        return _wkwebview
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
        
        // 檢查是否有連網
        let monitor = NWPathMonitor()
        monitor.pathUpdateHandler = { path in
            if path.status == .satisfied {
                print("connected")
            }
            else {
                print("no connection")
                DispatchQueue.main.asyncAfter(deadline: .now() + 0) {
                    let base64 = UIImage(named: "noconnect")?.pngData()?.base64EncodedString()
                    let imgData : String = "<body style='background-color:rgb(9, 175, 217);'><img style='height: 100%; width: 100%; object-fit: contain' src=\"data:image/png;base64,\(base64 ?? "")\"></body>"
                    webView.loadHTMLString(imgData, baseURL: nil)
                }
                return
            }
        }
        
        monitor.start(queue: DispatchQueue.global())
       

        let home_addr:NSURL = NSURL(string: "http://www.member.5.ibiz.tw")!
        
        //   let home_addr:NSURL = NSURL(string: "http://192.168.0.11/")!

        let filePath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("fcmToken.txt")
        let token_string = try! String(contentsOfFile: filePath.path)
        // E6E6FA
        // start.php
        let url_info:String = "app/api.php?mode=token&type=ios&token=" + token_string
        let body:String     = "<html><body style=\"background-color:#E6E6FA\"><img width=\"1\" height=\"1\" src=\"" + url_info + "\"/><script>" +
                            "var delay = 1000;" +
                            "setTimeout(function(){ window.location = \"/\"; }, delay);" +
                            "</script></body></html>"
        print(url_info)
        webView.loadHTMLString(body, baseURL: home_addr as URL)
        
    }
}


struct ContentView: View {
    
    var body: some View {
        VStack {
            WebView()
        }.navigationBarHidden(true)
    }
}

