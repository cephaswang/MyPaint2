import java.util.List;
import java.util.Arrays;
import java.util.function.Function;

class j01
{
	public static void main(String[] args) {
            List<String> songTitles = Arrays.asList("humble","element","dna");
            Function<String,String> capitalize = str->str.toUpperCase();
            songTitles.stream().map(capitalize).forEach(System.out::println);
	}
}

/*
�m��W Java 8�n08 �z�� Stream
https://www.youtube.com/watch?v=NB9mGlNMl-w


*/