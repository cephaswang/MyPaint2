import java.util.*;
import java.util.function.Function;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


class j08
{

	public static  List< Integer> members =Arrays.asList(1, 2, 3 , 4);

	public static void main(String[] args) {
		int total = 0;

		for( Integer x : members){
			if ( x % 2 == 0 ){
				total += x * x ;
			}
		}

		System.out.println( total );
		a2();

	}


    public static void a1(){
     //   int total = members.stream()
        //        .mapToInt( x -> {if ((x % 2 == 0) return x * x; } ) . sum();
    }

/*

Summing Numbers with Java Streams
https://www.baeldung.com/java-stream-sum


使用 Stream 進行管線操作
https://openhome.cc/Gossip/Java/Stream.html

Java Stream mapToInt()用法及代碼示例
https://vimsky.com/zh-tw/examples/usage/stream-maptoint-java-examples.html


*/

    public static void a2(){
        int total = members.stream()
                .filter( x -> x % 2 == 0 )
                .mapToInt ( x -> x * x )
                .sum ();
		System.out.println( total );
    }


  //  @RequiresApi(api = Build.VERSION_CODES.N)
    public static void a3(){
		/*
        int total = members.stream()
                .transform ( x -> x * x )
                .filter ( x -> x % 2 == 0 )
                .sum();
		*/
    }


 //   @RequiresApi(api = Build.VERSION_CODES.N)
    public static void a4(){
		/*
        int total = members.stream()
                .filter( x -> x % 2 == 0 )
                .collect( Collectors.toInt() );
		*/
    }



}

