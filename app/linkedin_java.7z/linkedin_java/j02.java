import java.util.*;

class j02
{
	public static void main(String[] args) {
		String[] array = new String[]{"A","B","C"};
		List <String> list1 = Arrays.asList(array);
		List <String> list2 = new ArrayList<>( Arrays.asList(array) );
		List <String> list3 = new ArrayList<>( Arrays.asList("A", new String("B") , "C") );
		System.out.print(list1.equals(list2));
		System.out.print(list1.equals(list3));
	}
}
/*

truetrue

https://www.delftstack.com/zh-tw/howto/java/how-to-create-a-new-list-in-java/

本教程將討論了在 Java 中建立不同型別列表的方法。

Java 中的列表 List 是一個介面，由 ArrayList、LinkedList、Vector 和 Stack 實現。
它提供了一個有序的物件集合。使用者可以精確控制每個元素在列表中的位置。
使用者可以通過元素的整數索引（在列表中的位置）訪問元素，並在列表中搜尋元素。此外，列表還允許儲存重複的元素。


有序的物件集合

*/