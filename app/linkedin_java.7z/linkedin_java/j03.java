import java.util.*;
import java.util.function.Function;


class j03
{
	public static void main(String[] args) {
		
		String  f2 = processFunction2(1);
	}

	public static String processFunction2 (Integer number, Function<Integer, String>lambda){
		return lambda.apply(number);
	}

}
/*

《跟上 Java 8》03 理解 lambda
https://www.youtube.com/watch?v=VkdMeFEGDH8


*/