import java.util.*;
import java.util.function.Function;


class j04
{
    List<String> theList = Arrays.asList("humble","element","dna");
2022/6/14
    public void a1 () {

        for ( int i = 0; i < theList.size(); i++ ){
            System.out.println(theList.get(i));
        }
    };

    public String a2 () {
        theList.forEach(System.out::println);
    }


    public String a3 () {
        for ( Object object: theList){
            System.out.println(object);
        }
    }

    public String a4 () {
        Iterator it =  theList.iterator();
		//###########################
		// 只有一個參數，是錯誤的。
        for ( it.hasNext()){
            System.out.println(it.next());
        }
    }

}
/*

。

*/