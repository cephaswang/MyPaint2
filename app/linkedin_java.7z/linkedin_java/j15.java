import java.util.*;
import java.util.function.Function;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


class j15
{
	public static void main(String[] args) {
		
/*


�A�Ω�Android��Java 8�G�ϥ�Lambda���F����²���N�X


https://code.tutsplus.com/zh-hant/tutorials/java-8-for-android-cleaner-code-with-lambda-expressions--cms-29661


		grouchyButton.addActionListener ( new addActionListener()
		{
			@Override
			public void actionPerformed ( ActionEvent e ){
				System.out.println("P");
			}
		}
*/

	}
}

