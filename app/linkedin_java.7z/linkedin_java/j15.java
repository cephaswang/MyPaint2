import java.util.*;
import java.util.function.Function;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


class j15
{
	public static void main(String[] args) {
		
/*

Java 8

@@@@@@@
https://youtu.be/VkdMeFEGDH8?t=670
grouchyButton.addActionListener ( e -> System.out.println("P"));



https://youtu.be/VkdMeFEGDH8?t=630

�A�Ω�Android��Java 8�G�ϥ�Lambda���F����²���N�X


https://code.tutsplus.com/zh-hant/tutorials/java-8-for-android-cleaner-code-with-lambda-expressions--cms-29661


		grouchyButton.addActionListener ( new addActionListener()
		{
			@Override
			public void actionPerformed ( ActionEvent e ){
				System.out.println("P");
			}
		}
*/

	}
}

