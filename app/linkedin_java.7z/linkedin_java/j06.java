import java.util.*;

import java.util.function.Function;

class j06
{
	public static void main(String[] args) {
		int y = square(2);
		System.out.println ( y  );

		y = new j06().squareLambda.apply(2);
        System.out.println ( y  );
    }


    public static int square(int x){
        return x * x;
    }

    public static Function <Integer, Integer> squareLambda = x -> x * x + 1;
}

/*

《跟上 Java 8》03 理解 lambda
https://www.youtube.com/watch?v=VkdMeFEGDH8

Java 8 Lambda新語法，簡化程式，增強效能
https://magiclen.org/java-8-lambda/

Function Interface in Java with Examples
https://www.geeksforgeeks.org/function-interface-in-java-with-examples/

*/