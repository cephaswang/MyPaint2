//
//  C04bookMark.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/17.
//

import SwiftUI

struct C06config: View {
    
    @StateObject var downloadModel = DownloadTaskModel()
    
    @State var int_date:Int = 0
    @State var OneDate_Array:[CellItem] = []
    @State var Download_Array:[CellItem] = []
    @State var CA:C01Menu_info = C01Menu_info()
    @State var strToday:String = ""
    @State var playSpeed:Float = 1
    @State var bookTitle:String = ""
    @State var PlistName:String = ""
    @State var MenuArray:[CellItem] = []

    @State var isTapped = false
    @State var int_Selected:Int = 0
    var initData  = CommClass()
    

    var body: some View {
        VStack{
            Text(String(format: "Speed: %.1f", Double(playSpeed)))
            HStack {
                Button(
                    action: {
                        if (playSpeed > 0.1){
                            playSpeed -= 0.1
                            initData.setSpeed(speed: String(format: "%.1f", Double(playSpeed)))
                        }
                        
                },
                    label: {
                        Image(systemName: "minus.circle.fill")
                            .resizable()
                            .frame(width: 30.0, height: 30.0,alignment: .center)
                }) .frame(width: 50.0, height: 50.0,alignment: .center)
                
                Button(
                    action: {
                        playSpeed = 1
                        initData.setSpeed(speed: String(format: "%.1f", Double(playSpeed)))
                },
                    label: {
                        Image(systemName: "repeat.circle.fill")
                            .resizable()
                            .frame(width: 30.0, height: 30.0,alignment: .center)
                        
                }).frame(width: 50.0, height: 50.0,alignment: .center)
                
                Button(
                    action: {
                        if (playSpeed < 2){
                            playSpeed += 0.1
                            initData.setSpeed(speed: String(format: "%.1f", Double(playSpeed)))
                        }
                        
                },
                    label: {
                        Image(systemName: "plus.circle.fill")
                            .resizable()
                            .frame(width: 30.0, height: 30.0,alignment: .center)
                        
                }).frame(width: 50.0, height: 50.0,alignment: .center)
                // Text(strToday)
                
            }.padding(.top,0)
            .overlay(
                ZStack{
                    if downloadModel.showDownloadProgress{
                        DownloadProgressView(progress: $downloadModel.downloadProgress)
                            .environmentObject(downloadModel)
                    }
                }
            )
            
            Button("下載60天檔案") {
                Download_Array = []
                var Cx:Int = 0
                for Px in 1...60 {
                    strToday = CA.get_Today(offset: Px)
                    OneDate_Array = CA.getOneDay(strOneDay: strToday)
                    for Ux in 0...OneDate_Array.count - 1{
                        var C1:CellItem = OneDate_Array[Ux]
                        Cx += 1
                        C1.id = Cx
                        Download_Array.append(C1)
                    }
                }
                print(Download_Array)
            }
            Button("下載全部檔案") {
                Download_Array = []
                var Cx:Int = 0
                for Px in 1...367 {
                    strToday = CA.get_Today(offset: Px)
                    OneDate_Array = CA.getOneDay(strOneDay: strToday)
                    for Ux in 0...OneDate_Array.count - 1{
                        var C1:CellItem = OneDate_Array[Ux]
                        Cx += 1
                        C1.id = Cx
                        Download_Array.append(C1)
                    }
                }
                print(Download_Array)
            }.onAppear(){
                playSpeed = initData.getSpeed()
            }
        }
        
    }
    
    @ViewBuilder
    func chooseDestination() -> some View {
        switch int_Selected {
            case 1: C05audioPlayer(playIndex:0)
            case 2: C02bibleMenu(isOldTest:1)
            default: EmptyView()
        }
    }
}

struct C06config_Previews: PreviewProvider {
    static var previews: some View {
        C06config()
    }
}
