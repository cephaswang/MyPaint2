//
//  Home.swift
//  AudioPlayer WatchKit Extension
//
//  Created by admin on 2022/4/11.
// https://www.youtube.com/watch?v=OPLlRd54mnk

import SwiftUI

struct C00Home: View {
    @StateObject var downloadModel = DownloadTaskModel()
    @State var urlText = "http://bible.cephas.tw/bible_cantonese/002/2_027.mp3"
    
    
    var body: some View{
        NavigationView{
            VStack(spacing:15){
                TextField("URL",text: $urlText)
                
                Button (action: {
                    print("1")
                    downloadModel.startDownload(urlString: urlText,downOnly: true)
                }, label: {
                    Text("Download URL")
                })

                
            }
        }.navigationTitle("Download Task")
            .preferredColorScheme(.light)
            .alert(isPresented: $downloadModel.showAlert) {
                Alert(title: Text("Message"), message: Text(downloadModel.alertMsg), dismissButton:
                        .destructive(Text("OK"),action: {
                            print(1)
                        })
                )
            }
            .overlay(
                
                ZStack{
                    if downloadModel.showDownloadProgress{
                        DownloadProgressView(progress: $downloadModel.downloadProgress)
                            .environmentObject(downloadModel)
                    }
                }
            
            )
                   
    }

    
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        C00Home()
    }
}
