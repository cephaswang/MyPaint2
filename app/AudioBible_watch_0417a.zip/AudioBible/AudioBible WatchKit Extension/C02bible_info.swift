//
//  Menu_Manager.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import Foundation



class C02bible_info {

    var initData  = CommClass()
    
    // getDailyBook ( fileName: "tra_daily_01" , dailyIndex: 0)
    func getMenuBook (isOldSets : Int) -> NSArray {
        if ( isOldSets == 1 ){
            return initData.getMenuBook(isOldSets: isOldSets)
        } else {
            return initData.getMenuBook(isOldSets: 0)
        }
        
    }
    
    
}
