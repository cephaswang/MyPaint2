//
//  AudioBibleApp.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import SwiftUI

@main
struct AudioBibleApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
               // ContentView()
                // C01mainMenu()
                C06config()
            }
        }
    }
}
