//
//  C05audioPlayer.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/10.
//

import SwiftUI
import WatchKit
import AVFoundation
// var audioPlayer: AVAudioPlayer!

struct C05audioPlayer: View {

    @Environment(\.presentationMode) var mode: Binding<PresentationMode>

    @State var audioPlayer: AVAudioPlayer!
    // var del:AVAudioPlayerDelegate?
    @StateObject var downloadModel = DownloadTaskModel()
    @State var initData  = CommClass()
    @State var MenuArray:[CellItem] =  []
    @State var playIndex:Int
    @State var isHidden:Double = 1
    @State var OneCell: CellItem = CellItem(id: 0, name: "", push: "")
    @State var playTitle:String = ""
    @State var playButton:[String] = ["play.fill","pause.fill"]
    @State var playButtonStat:String = ""
    @State var downloadProgress:CGFloat = 0

    @State var is_repeat:Bool = false
    @State var is_repeat_Image:[String] = ["repeat.circle" , "repeat.circle.fill"]
    @State var is_repeat_Stat:String = ""
    
    @State var is_bookMark:Bool = false
    @State var is_bookMark_Image:[String] = ["bookmark.circle" , "bookmark.circle.fill"]
    @State var is_bookMark_Stat:String = ""
    
    @State var durLabel_text:String = ""
    @State var curLabel_text:String = ""
    @State var checkTimer:Timer?

    
    var scaleVar:CGFloat = 120
    
    var body: some View {
        
        ScrollView {

            VStack {
                HStack {
                    // [SwiftUI] Make Buttons (1) - using Image system Name, No coding. No Image file. using SF Symbols
                    // https://www.youtube.com/watch?v=X4LBLlxX2VU
                    Button(
                        action: {
                            print("1")
                            if (self.audioPlayer != nil)  {
                                self.audioPlayer.stop()
                            }
                            self.audioPlayer = nil
                            
                            if (playIndex > 0){
                                playIndex = playIndex - 1
                            } else {
                                playIndex = MenuArray.count - 1
                            }
                            playIndex = playIndex %  MenuArray.count
                            OneCell = MenuArray[playIndex]
                            playTitle = OneCell.name
                            
                            downloadModel.startDownload(urlString:OneCell.push ,downOnly: false)
                            playButtonStat = playButton[1]
                    },
                        label: {
                            Image(systemName: "backward.fill")
                                .resizable()
                                .frame(width: 36.0, height: 36.0,alignment: .center)
                        }).opacity(isHidden)


                    Button(
                        action: {
                            guard (self.audioPlayer != nil) else {
                                return
                            }

                            if ( self.audioPlayer.isPlaying ) {
                                self.audioPlayer.pause()
                                playButtonStat = playButton[0]
                                print("9")
                                return
                            } else {
                                print("8")
                                playButtonStat = playButton[1]
                                self.audioPlayer.play()
                            }
                    },
                        label: {
                            Image(systemName: playButtonStat)
                                .resizable()
                                .frame(width: 36.0, height: 36.0,alignment: .center)
                            
                    })

                    
                    Button(
                        action: {
                            if (self.audioPlayer != nil)  {
                                self.audioPlayer.stop()
                            }
                            self.audioPlayer = nil
                            
                            print("1")
                            playIndex = (playIndex + 1 ) % MenuArray.count
                            OneCell = MenuArray[playIndex]
                            playTitle = OneCell.name
                            downloadModel.startDownload(urlString:OneCell.push ,downOnly: false)
                            playButtonStat = playButton[1]
                    },
                        label: {
                            Image(systemName: "forward.fill")
                                .resizable()
                                .frame(width: 36.0, height: 36.0,alignment: .center)
                    }).opacity(isHidden)
                }

                ZStack{
                    Circle()
                        .fill(Color.gray.opacity(0.3))
                        ProgressShape(progress: downloadProgress)
                        .fill(Color.gray.opacity(0.4))
                        .rotationEffect(.init(degrees: -90))
                    HStack {
                        Text(curLabel_text)
                            .frame(width: scaleVar * 0.45, height: scaleVar * 0.45, alignment: .leading)
                        
                        Text(durLabel_text)
                            .frame(width: scaleVar * 0.45, height: scaleVar * 0.45, alignment: .leading)
                        
                    }.frame(width: scaleVar, height: scaleVar, alignment: .center)
                }
                .overlay(
                    ZStack{
                        if downloadModel.showDownloadProgress{
                            DownloadProgressView(progress: $downloadModel.downloadProgress)
                                .environmentObject(downloadModel)
                        }
                    }
                )
            
                HStack {
                    Button(
                        action: {
                        
                        is_bookMark = !is_bookMark
                        if ( is_bookMark == true ){
                            initData.addBookMark(name: OneCell.name, push: OneCell.push)
                            is_bookMark_Stat = is_bookMark_Image[1]
                        } else {
                            initData.delBookMark(name: OneCell.name, push: OneCell.push)
                            is_bookMark_Stat = is_bookMark_Image[0]
                        }
                            
                    },
                        label: {
                            Image(systemName: is_bookMark_Stat)
                                .resizable()
                                .frame(width: 50.0, height: 50.0,alignment: .center)
                    })
                    Button(
                        action: {
                        
                        is_repeat = !is_repeat
                        if ( is_repeat == true ){
                            is_repeat_Stat = is_repeat_Image[1]
                        } else {
                            is_repeat_Stat = is_repeat_Image[0]
                        }
                            
                    },
                        label: {
                            Image(systemName: is_repeat_Stat)
                                .resizable()
                                .frame(width: 50.0, height: 50.0,alignment: .center)
                    })
                }
            }
        }.onAppear(){

            print("C05audioPlayer(playIndex:\(playIndex))")
            
            let playArray:NSArray = initData.readDocuArray(fileName: "playArray.plist")
            var OneDay:NSArray = []
            MenuArray = []
            for index in (0 ... playArray.count - 1){
                OneDay = playArray.object(at:index) as! NSArray
                MenuArray.append(
                    CellItem(id: index,
                             name: OneDay.object(at:0) as! String,
                             push: OneDay.object(at:1) as! String)
                   )
            }

            if (MenuArray.count < 2){
                isHidden = 0
            }
            
            playButtonStat   = playButton[1]
            is_repeat_Stat   = is_repeat_Image[0]
            is_bookMark_Stat = is_bookMark_Image[0]
            
            playIndex = playIndex %  MenuArray.count
            OneCell   = MenuArray[playIndex]
            playTitle = OneCell.name
            
            downloadModel.startDownload(urlString:OneCell.push ,downOnly: true)
            
            checkTimer = Timer.scheduledTimer(withTimeInterval: 1, repeats: true) { (_) in

                guard (self.audioPlayer != nil) else {
                    // print("self.audioPlayer")
                    
                    let urlString:String =  checkIsDownloaded(urlString: OneCell.push)
                    if (urlString.count < 1){
                        return
                    }

                    self.audioPlayer = try! AVAudioPlayer(contentsOf: URL(fileURLWithPath: urlString))
                  //  self.audioPlayer.delegate = self.del
                    self.audioPlayer.enableRate = true
                    self.audioPlayer.prepareToPlay()
                    
                    DispatchQueue.main.asyncAfter(deadline: .now() + 1) {
                        guard (self.audioPlayer != nil) else{
                            return
                        }

                        // self.audioPlayer.currentTime = self.audioPlayer.duration - 8
                        self.audioPlayer.rate = initData.getSpeed()
                        self.audioPlayer.play()
                        
                        is_bookMark = initData.isBookMark(name: OneCell.name, push: OneCell.push)
                        if ( is_bookMark == true ){
                            is_bookMark_Stat = is_bookMark_Image[1]
                        } else {
                            is_bookMark_Stat = is_bookMark_Image[0]
                        }
                        
                    }
                    
                    return
                }

                if ( self.audioPlayer.isPlaying ) {
                    downloadProgress = self.audioPlayer.currentTime / self.audioPlayer.duration
                    
                    // this is to compute and show remaining time
                    let duration = Int((audioPlayer.duration - (audioPlayer.currentTime)))
                    let minutes2 = duration/60
                    let seconds2 = duration - minutes2 * 60
                    durLabel_text = NSString(format: "%02d:%02d", minutes2,seconds2) as String

                    //This is to show and compute current time
                    let currentTime1 = Int((audioPlayer.currentTime))
                    let minutes = currentTime1/60
                    let seconds = currentTime1 - minutes * 60
                    curLabel_text = NSString(format: "%02d:%02d", minutes,seconds) as String
                    
                    // print("duration:\(duration)")
                    if ( duration < 1 ){
                        
                        if ( MenuArray.count - playIndex  == 1 && is_repeat == false ){
                            self.mode.wrappedValue.dismiss()
                            print("播放結束:\(playIndex)")
                            return
                        }
                       //
                        // 播放下一首
                        Timer.scheduledTimer(withTimeInterval: 1, repeats: false) { (_) in
                            self.audioPlayer = nil
                            if (is_repeat == false){
                                playIndex += 1
                            }
                            print("播放下一首:\(playIndex)")
                            playIndex = playIndex %  MenuArray.count
                            OneCell   = MenuArray[playIndex]
                            downloadModel.startDownload(urlString:OneCell.push ,downOnly: true)
                            playTitle = OneCell.name
                        }
                    }
                }
            }
            
           // callFunc()
        }
        .navigationTitle(playTitle).font(.caption)
        .onDisappear(){
            self.audioPlayer.stop()
            self.audioPlayer = nil
            self.checkTimer?.invalidate()
        }
        .padding(.top,20)
    }
}

func checkIsDownloaded(urlString: String) -> String{
    let nameArray:[String] = urlString.components(separatedBy: "/")
    let strStoreName = "\(nameArray[nameArray.count-2])/\(nameArray[nameArray.count-1])"

    let DocumentDirURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
    let fileURL = DocumentDirURL.appendingPathComponent(strStoreName)
    if FileManager.default.fileExists(atPath: fileURL.path){
        return fileURL.path;
    }

    return ""
}

// Repeating function in SwiftUI
// https://developer.apple.com/forums/thread/683177
func  callFunc(){
    DispatchQueue.main.asyncAfter(deadline: .now() + 4) {
       callFunc()
    }
}

struct C05audioPlayer_Previews: PreviewProvider {
    static var previews: some View {
        C05audioPlayer(playIndex:0)
    }
}
