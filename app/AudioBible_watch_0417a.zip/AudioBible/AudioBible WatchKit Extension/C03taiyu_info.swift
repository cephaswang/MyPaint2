//
//  Menu_Manager.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import Foundation



class C03taiyu_info {

    var initData  = CommClass()

    func getTaiSong () -> NSArray {
        return initData.getTaiSong()
    }
   
}
