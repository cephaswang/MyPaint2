//
//  C02bibleMenu.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import SwiftUI

struct C03oneBookSet: View {
    
    @State var bookTitle:String = ""
    @State var PlistName:String = ""
    @State var MenuArray:[CellItem] = []
    @State var CA:C03oneBook_info = C03oneBook_info()
    @State var isTapped = false
    @State var int_Selected:Int = 0
    var initData  = CommClass()
    

    var body: some View {
        NavigationView {
            List(MenuArray, id: \.id) { (OneItem) in
                
                NavigationLink (destination: C05audioPlayer(playIndex:int_Selected), isActive: self.$isTapped) {
                    TableViewCell(textLabel: OneItem.name)
                    .onTapGesture {
                        print("touched item \(OneItem.name)")
                        print("touched push \(OneItem.push)")
                        isTapped.toggle()
                        int_Selected = OneItem.id
                    }
                }
            }.padding(.all, 0)
        }
        .navigationTitle(bookTitle)
        .onAppear(){
           print(" C03oneBookSet(bookTitle:\(bookTitle),PlistName:\(PlistName))")
            let ArraySRC:NSArray = CA.getOneBook(fileName: PlistName)
            var OneBook:NSArray
            var BookName:NSString
            var linkName:NSString
          //  var fileName:NSString

            var OneArray:NSArray = NSArray()
            let playArray : NSMutableArray = NSMutableArray()
            
            for Px:Int in 0 ... ArraySRC.count - 1 {
                OneBook  = ArraySRC.object(at: Px) as! NSArray
                BookName = OneBook.object(at: 0) as! NSString
                linkName = OneBook.object(at: 1) as! NSString
               // fileName = OneBook.object(at: 2) as! NSString
                MenuArray.append(
                    CellItem(id: Px,
                              name: String(BookName),
                              push: String(linkName)
                              )
                )
                
                OneArray = [BookName, linkName]
                playArray.add(OneArray)
            }
            initData.writeDocuArray(destFileName: "playArray.plist", dictSource: playArray)
           // print(playArray)
        }
        
    }
}

struct C03oneBookSet_Previews: PreviewProvider {
    static var previews: some View {
        C03oneBookSet(bookTitle:"bookTitle",PlistName:"tra_book_01.plist")
    }
}
