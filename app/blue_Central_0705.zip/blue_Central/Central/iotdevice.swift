//
//  ViewController.swift
//  Perpheral
//  iOS 程式設計 - 藍牙 (I) - Peripheral
//  https://www.youtube.com/watch?v=_24njKb6JiU
//  Created by admin on 2022/7/3.
//

/*
 
 iOS swift 5: 關於 "CoreBluetooth XPC connection invalid"
 http://snoopymemory.blogspot.com/2019/05/ios-swift-5-about-corebluetooth-xpc.html

 
 https://medium.com/@nalydadad/%E6%A6%82%E8%BF%B0-gatt-%E8%97%8D%E8%8A%BD%E5%82%B3%E8%BC%B8-9fa218ce6022
 
 9-1 BLE運作原理
 https://www.youtube.com/watch?v=yKJtnkEjPFI
 
 BLE Profile
 https://www.youtube.com/watch?v=PgZjAWBEbd4
 
 BLE/ZigBee開始篇
 https://www.youtube.com/watch?v=2sXXpwxi6oE
 
*/

//  Created by admin on 2022/7/5.
//

import UIKit
import CoreBluetooth

class iotdevice: UIViewController , CBPeripheralManagerDelegate{
    
    enum SendDataError:Error{
        case CharacteristicNotFound
    }
    
    let UUID_SERVICE = "A001"
    let UUID_CHARACTERISTIC = "C001"
    let DeviceName = "BLE_DEVICE"
    
    var peripheralManager:CBPeripheralManager!
    var charDictionary = [String:CBMutableCharacteristic]()
    
    // https://www.youtube.com/watch?v=_24njKb6JiU
    // # 1
    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        print("# 1 peripheralManagerDidUpdateState")
        guard peripheral.state == .poweredOn else {
            return
        }
        
        var service:CBMutableService
        var characteristic:CBMutableCharacteristic
        var charArray = [CBCharacteristic]()
        
        service = CBMutableService(type: CBUUID(string: UUID_SERVICE), primary: true)

        characteristic = CBMutableCharacteristic(
            type:  CBUUID(string: UUID_CHARACTERISTIC),
            properties: [.notifyEncryptionRequired, .writeWithoutResponse],
            value: nil,
            permissions: [.writeEncryptionRequired])
        
        charArray.append( characteristic)
        
        charDictionary[UUID_CHARACTERISTIC] = characteristic
        
/*
 https://books.google.com.tw/books?id=42R0DwAAQBAJ&pg=PA578&lpg=PA578&dq=%5BString:CBMutableCharacteristic%5D()+swift&source=bl&ots=jAHEY-8V3e&sig=ACfU3U0LV5uHC2eI20dhVQmhUzIuKS_mAQ&hl=zh-TW&sa=X&ved=2ahUKEwie75e_69z4AhUQBd4KHUGFDIEQ6AF6BAgDEAM#v=onepage&q=%5BString%3ACBMutableCharacteristic%5D()%20swift&f=false
 */

        service.characteristics = charArray
        peripheralManager.add(service)

    }
    
    /*
     https://gist.github.com/bricklife/45e4a2f53ce4e9ce1c87969070b8f24b
     */
    
    // 2
    func peripheralManager(_ peripheral: CBPeripheralManager, didAdd service: CBService, error: Error?) {
        
        print("# 2 peripheralManager")
        guard error == nil else {
           // print("ERROR:{\(#file,#function)}\n")
            print("ERROR:{\(#file)}\n")
            print(error!.localizedDescription)
            return
        }

        // 為藍牙裝置取名字
        let deviceName = DeviceName

        // 開始廣播
        peripheral.startAdvertising(
            [ CBAdvertisementDataServiceUUIDsKey:[service.uuid],
             CBAdvertisementDataLocalNameKey:deviceName]
        )
    }

    /* # 3 */
    func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
        print("StartAdvertising")
    }

    /*  訂閱 */
    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didSubscribeTo characteristic: CBCharacteristic) {
        
        print("# 3 didSubscribeTo")
        
        if peripheral.isAdvertising {
            peripheral.stopAdvertising()
            print("stopAdvertising")
        }
        
        if characteristic.uuid.uuidString == UUID_CHARACTERISTIC {
            print("didSubscribeTo:", central, characteristic)
        }
    }
    
    /*  取消訂閱 */
    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didUnsubscribeFrom characteristic: CBCharacteristic) {
        
        print("# 3 didUnsubscribeFrom")
        
        if characteristic.uuid.uuidString == UUID_CHARACTERISTIC {
            print("didUnsubscribeFrom:", central, characteristic)
        }
    }
    
    func sendData (_ data:Data, uuidString : String) throws{
        print("sendData to uuidString: " + uuidString)
        
        guard let characteristic = charDictionary[uuidString] else {
            throw SendDataError.CharacteristicNotFound
        }
        
        peripheralManager.updateValue(
            data,
            for: characteristic,
            onSubscribedCentrals: nil
        )
    }
    
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
        
        guard let at = requests.first else {
            return
        }
        
        guard let data = at.value else {
            return
        }

       // peripheral.respond(to: at , withResult: .success)
        DispatchQueue.main.async {
            let string = "> " + String(data: data, encoding: .utf8)!
            print(string)
            
            if self.TextView.text == "" {
                self.TextView.text = string
            } else {
                self.TextView.text = self.TextView.text + "\n" + string
            }
        }
    }

    
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveRead request: CBATTRequest) {
        if request.characteristic.uuid.uuidString == UUID_CHARACTERISTIC {
            let data = "how are you".data(using: .utf8)
            request.value = data
        }
        peripheral.respond(to: request, withResult: .success)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let queue = DispatchQueue.global()
        
        peripheralManager = CBPeripheralManager(delegate: self, queue: queue)

        // Do any additional setup after loading the view.
    }


    @IBOutlet weak var TextField: UITextField!
    
    @IBOutlet weak var TextView: UITextView!

    @IBAction func sendClick(_ sender: Any) {

        let string = TextField.text
        
        if string == "" {
            return
        }
        
        if self.TextView.text == "" {
            self.TextView.text = string
        } else {
            self.TextView.text = self.TextView.text + "\n" + string!
        }
        
        do {
            try sendData(string!.data(using: .utf8)!, uuidString: "C001")
        } catch {
            print(error)
        }
        
        // https://www.youtube.com/watch?v=_24njKb6JiU
        
    }
    
    
}


/*
 
 
 https://medium.com/@nalydadad/%E6%A6%82%E8%BF%B0-gatt-%E8%97%8D%E8%8A%BD%E5%82%B3%E8%BC%B8-9fa218ce6022
 
 概述 GATT 藍芽傳輸
 GATT 是 BLE 很基本的傳輸資料方式，透過 Service 跟 Characteristic 的概念，定義傳輸的類型跟內容。市面上幾乎所有 mobile 裝置都支援 BLE，如果需要實作與藍牙周邊裝置溝通的功能，必須對 GATT 有基本了解。此篇就讓我們來釐清這些名詞分別代表什麼意義。

 在開始前
 先釐清在 GATT 連線中，Client / Server 的關係：

 藍芽週邊 (Peripheral) 是 GATT Server：掌握 ATT 表，其中包含 services 跟 characteristics 資訊 (稍後會提到)
 Mobile 裝置 (Central) 是 GATT Client：發送 request 到 GATT Server，等待 Peripheral 回傳 Response
 
 看下圖比較清楚。另外 Peripheral 在沒有配對的情況，會一直廣播(Advertising) 自己的裝置資訊，一旦連線建立後，就會停止 Advertising，因此 Peripheral 只能與一個 Central 建立連線，但 Central 可以與多個 Peripheral 建立連線。
 
 GATT (Generic Attribute Profile) 的資料型態
 由三層資料結構組成：Profile, Service & Characteristic。

 Profile
 為一個抽象的概念，代表某個 BLE 週邊裝置提供的所有 Service。我的理解可以視為一個 ATT 表 (後面會說明)

 Service & Characteristic
 Service 代表某種功能的資料集合，其中可以包含多個 Characteristic，而 Characteristic 還可以拆解為 property/value 及多個 descriptor，這邊先不多提。
 
 資料實際上長什麼樣子？
 GATT 利用 ATT 協定儲存上述的 Service 跟 Characteristic。

 ATT 協定
 struct {
     u16 uuid;
     u8 *data;
 } att[65536];
 參考 Source Code，可以知道這個協定就是就是一個 att array 透過 index 查表就可以取出某筆 att 資料 (題外話，在藍牙的世界 index 有個專有名詞叫 handle)。而每筆資料的 UUID 代表 metadata (識別資料類型)，data 代表資料的內容。
 
 所以存在 ATT 表的 Service 跟 Characteristic 會長的像下圖這樣。每筆資料有可能是一個 Service 或是一個 Characteristic
 
 雖說概念上是巢狀的，但是資料卻是連續的。我們要怎麼知道哪些 service 包含哪些 characteristic 呢？

 以上圖為例，其中 service 為 UUID = 0x2800 的資料，我們用此 ID 做切割，就會發現 handle: 0x1、0x8、0x9、0x11、0x15，為 service，而在這之間的資料皆為 characteristic。舉例：handle 0x9 即可以得到在 handle 0x9~0x10 的 characteristics。所以在開發的情境上，如果要透過 GATT 與藍芽裝置溝通，就是在接收 Service 並解析其包含的所有 Characteristic 資料。

 有機會的話，再用 Core Bluetooth 寫個小範例 (一定是幹話… )。
 
 
*/




