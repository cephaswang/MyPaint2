//
//  server.swift
//  Central
//
//  Created by admin on 2022/7/5.
//

import UIKit
import CoreBluetooth

class server: UIViewController , CBCentralManagerDelegate, CBPeripheralDelegate{

    let UUID_CHARACTERISTIC = "C001"
    let KEY_PERIPHERAL_UUID = "KEY_PERIPHERAL_UUID"
    let DeviceName = "admin’s iPhone"

    enum SendDataError:Error{
        case CharacteristicNotFound
    }

    var centralManager: CBCentralManager!
    var connectPeripheral:CBPeripheral!
    var charDictionary = [String:CBCharacteristic]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let queue = DispatchQueue.global()
        
        centralManager = CBCentralManager(delegate: self, queue: queue)

    }
    
    /* 當 central  端重新執行後，嘗試取回 peripheral */
    func isPaired() -> Bool {
        let user = UserDefaults.standard
        if let uuidString = user.string(forKey: KEY_PERIPHERAL_UUID ){
            let uuid = UUID(uuidString: uuidString)
            let list = centralManager.retrievePeripherals(withIdentifiers: [uuid!])
            if list.count > 0 {
                connectPeripheral = list.first!
                connectPeripheral.delegate = self
                return true
            }
        }
        return false
    }

    // #1
    func centralManagerDidUpdateState(_ central: CBCentralManager) {
        guard central.state == .poweredOn else{
            return
        }
        
        print("Bluetooth status is POWERED ON")
        
        if isPaired(){
            centralManager.connect(connectPeripheral,options: nil)
        } else {
            centralManager.scanForPeripherals(withServices: nil,options: nil)
        }
    }
    
    // #2
    func centralManager(_ central: CBCentralManager, didDiscover peripheral: CBPeripheral, advertisementData: [String : Any], rssi RSSI: NSNumber) {
        
        print("found: \(String(describing: peripheral.name))")

        /*
        guard peripheral.name == DeviceName else {
            return
        }*/
        
        central.stopScan()
        
        /* 儲存週邊端的 UUID ，重新連線時需要這個值 */
        let user = UserDefaults.standard
        user.set(peripheral.identifier.uuidString, forKey: KEY_PERIPHERAL_UUID)
        user.synchronize()
        
        connectPeripheral = peripheral
        connectPeripheral.delegate = self
        
        // 將觸發 ３ 號
        centralManager.connect(connectPeripheral,options: nil)
    }
    
    // #3
    func centralManager(_ central: CBCentralManager, didConnect peripheral: CBPeripheral) {
        charDictionary = [:]
        peripheral.discoverServices(nil)
    }
    
    // # 4
    func peripheral(_ peripheral: CBPeripheral, didDiscoverServices error: Error?) {
        guard error == nil else {
            print("\(#file)")
            return
        }
        
        for service in peripheral.services! {
            connectPeripheral.discoverCharacteristics(nil, for: service)
        }
    }
    
    // # 5
    func peripheral(_ peripheral: CBPeripheral, didDiscoverCharacteristicsFor service: CBService, error: Error?) {
        guard error == nil else {
            print("\(#file)")
            return
        }
        
        for characteristic in service.characteristics! {
            let uuidString = characteristic.uuid.uuidString
            charDictionary[uuidString] = characteristic
            print ("found device: \(uuidString)")
        }
        
    }
    
    
    
    func peripheral(_ peripheral: CBPeripheral, didUpdateValueFor characteristic: CBCharacteristic, error: Error?) {
        guard error == nil else {
            print("\(#file)")
            return
        }
        
        if characteristic.uuid.uuidString == UUID_CHARACTERISTIC {
            let data = characteristic.value! as NSData
            DispatchQueue.main.async {
                var string = String(data: data as Data, encoding: .utf8)
                string = "<" + string!
                print("\(String(describing: string))")
                
                if self.textView.text == "" {
                    self.textView.text = string
                } else {
                    self.textView.text = self.textView.text + "\n" + string!
                }
                
            }
        }
    }
    
    func sendData (_ data:Data, uuidString : String, writeType:CBCharacteristicWriteType) throws{
        guard let characteristic = charDictionary[uuidString] else {
            throw SendDataError.CharacteristicNotFound
        }
        connectPeripheral.writeValue(
            data,
            for: characteristic,
            type: writeType
        )
    }

    func peripheral(_ peripheral: CBPeripheral, didWriteValueFor characteristic: CBCharacteristic, error: Error?) {
        if error != nil {
            print("write error \(String(describing: error))")
        }
    }
    
    @IBOutlet weak var textView: UITextView!
    
    @IBOutlet weak var textField: UITextField!
    
    /*
    @IBAction func switchValueChanged(_ sender: UISwitch) {
        print("switchValueChanged")
        let char = charDictionary[UUID_CHARACTERISTIC]!
        connectPeripheral.setNotifyValue(sender.isOn, for: char)
    }*/
    
    
    @IBAction func switchValueChanged(_ sender: UISwitch) {
        
        print("switchValueChanged")
        print(sender.isOn)
        
        let char = charDictionary[UUID_CHARACTERISTIC]!
        connectPeripheral.setNotifyValue(sender.isOn, for: char)
        
    }
    
    
    
    @IBAction func sendClick(_ sender: Any) {
        let string = textField.text ?? ""
        
        if string == "" {
            return
        }
        
        if self.textView.text == "" {
            self.textView.text = string
        } else {
            self.textView.text = self.textView.text + "\n" + string
        }

        do {
            try sendData(string.data(using: .utf8)!,
                         uuidString: UUID_CHARACTERISTIC,
                         writeType: .withoutResponse)
        } catch {
            print(error)
        }
    }
    
    /* 斷線處理 */
    func centralManager(_ central: CBCentralManager, didDisconnectPeripheral peripheral: CBPeripheral, error: Error?) {
        print("連線中斷")
        if isPaired() {
            /* 重新連線 */
            centralManager.connect(connectPeripheral, options: nil)
        }
    }
    
    /*  解配對  */
    func unpair(){
        let user = UserDefaults.standard
        user.removeObject(forKey: KEY_PERIPHERAL_UUID)
        user.synchronize()
        centralManager.cancelPeripheralConnection(connectPeripheral)
    }
    
    @IBAction func unpairClick(_ sender: Any) {
        unpair()
    }
    
}

