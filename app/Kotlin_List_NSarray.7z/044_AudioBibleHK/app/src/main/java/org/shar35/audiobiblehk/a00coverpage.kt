package org.shar35.audiobiblehk

/*

2022-06-21

*/

import android.content.Intent
import android.os.Bundle
import android.os.Handler
import androidx.appcompat.app.AppCompatActivity


class a00coverpage : AppCompatActivity() {

    private val handler = Handler()

    val GotoMenu =  Runnable() {
        val intent: Intent = Intent()
        intent.setClass(this, d00menu::class.java)
        startActivity(intent)
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_a00coverpage)
        handler.postDelayed(GotoMenu, 4000)
    }

    override fun onDestroy() {
        super.onDestroy()
        handler.removeCallbacks(GotoMenu)
    }

    override fun onBackPressed() {
        super.onBackPressed()
        handler.removeCallbacks(GotoMenu)
        finish()
    }

}