package org.shar35.audiobiblehk


import android.content.Context
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import com.dd.plist.NSArray


class d00menu : AppCompatActivity() {

    lateinit var btn_date_pre: ImageButton
    lateinit var btn_date_rst: ImageButton
    lateinit var btn_date_nex: ImageButton
    lateinit var menu_list: ListView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_d00menu)

        btn_date_pre = findViewById(R.id.btn_date_pre)
        btn_date_rst = findViewById(R.id.btn_date_rst)
        btn_date_nex = findViewById(R.id.btn_date_nex)
        menu_list    = findViewById(R.id.userlist)

        btn_date_pre.setOnClickListener{
        }
        btn_date_rst.setOnClickListener{
        }
        btn_date_nex.setOnClickListener{
        }

        var k0:NSArray = NSArray( 2 )
        k0.setValue(0,"01 粵語聖經")
        k0.setValue(1,"Cantonese Bible")

        var users:NSArray = NSArray(2 )
        users.setValue(0,k0)

        var k1:NSArray = NSArray( 2 )
        k1.setValue(0,"02 華語聖經")
        k1.setValue(1,"Chinese Bible")
        users.setValue(1,k1)

        val arrayAdapter: NSArrayAdapter = NSArrayAdapter(this, users)
        menu_list.adapter = arrayAdapter
    }


    class NSArrayAdapter(context: Context, dataArray: NSArray): BaseAdapter() {
        val dataArray:  NSArray = dataArray
        val context: Context = context

        override fun getCount(): Int {
            return dataArray.count()
        }

        override fun getItem(position: Int): Any {
            return dataArray.objectAtIndex(position)
        }

        override fun getItemId(position: Int): Long {
            return 0
        }

        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val listheroView = LayoutInflater.from( context ).inflate(R.layout.row_c01b, parent, false)
            val textMain: TextView = listheroView.findViewById(R.id.textMain)
            val textEngl: TextView = listheroView.findViewById(R.id.textEnglish)
            val OneRec: NSArray = dataArray.objectAtIndex(position) as NSArray
            textMain.setText( OneRec.objectAtIndex(0).toString() )
            textEngl.setText( OneRec.objectAtIndex(1).toString() )
            return listheroView
        }
    }

}