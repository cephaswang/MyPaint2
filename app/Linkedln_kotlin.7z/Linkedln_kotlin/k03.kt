/*

Your function is passed a parameter obj of type Any. 
Which code snippet shows a way to retrieve the original type of obj,
including package information?

你的函数被传递了一个 Any 类型的参数 obj。
哪个代码片段显示了一种检索原始 obj 类型（包括包信息）的方法？

obj.classInfo()
obj::class
obj::typeInfoO
obj::class.simpleName

*/