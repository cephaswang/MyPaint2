You have two arrays, a and b , Which line combines a and b as a list containing the contents of both ?

您有两个数组 a 和 b ，哪一行将 a 和 b 组合为一个包含两者内容的列表？

    fun k05(){
        val a = arrayOf(1,2,3)
        val b = arrayOf(100,200,300)

        val c1 = listOf(a,b)
        val c2 = a + b
        val c3 = listOf(*a,*b)
        val c4 = listOf(a+b)

        println(c1.toString())
        println(c2.toString())
        println(c3.toString())
        println(c4.toString())
    }

/*

System.out: [[Ljava.lang.Integer;@86a2fd0, [Ljava.lang.Integer;@aa7ebc9]
System.out: [Ljava.lang.Integer;@9ccd2ce
System.out: [1, 2, 3, 100, 200, 300]
System.out: [[Ljava.lang.Integer;@dc4b5ef]

*/