fun k02(){
	val john = staff("daf")
	john.displayJob("code")
}


// k02
abstract class Person(val name: String){
    abstract fun displayJob(description:String)
}

class staff(name: String) :Person(name){
    override fun displayJob(description: String) {
        println(name + " his job is " + description)
    }
}
