
https://www.youtube.com/watch?v=iH6DAtsbZ_A

在 Android 使用 Kotlin Coroutines - 從 Callback 到 Coroutines



https://kotlinlang.org/docs/cancellation-and-timeouts.html#making-computation-code-cancellable


Making computation code cancellable﻿
There are two approaches to making computation code cancellable. 
The first one is to periodically invoke a suspending function that checks for cancellation. 
There is a yield function that is a good choice for that purpose. 
The other one is to explicitly check the cancellation status. Let us try the latter approach.

使计算代码可取消
有两种方法可以使计算代码可取消。 
第一个是定期调用检查取消的挂起函数。
有一个 yield 函数是一个很好的选择。 
另一种是显式检查取消状态。 让我们尝试后一种方法。