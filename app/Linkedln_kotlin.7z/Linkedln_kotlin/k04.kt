How do you fill in the blank below to display all of the even numbers from 1 to 10 with the least amount of code?
如何填写下面的空白，以最少的代码显示从 1 到 10 的所有偶数？

for ______{
	println("There are $count butterflies. ")
}
count in 1..10 % 2
count in 2..10 step 2 // @@@@
var count=2; count <= 10; count+-2
count in 1..10