//
//  appHome.swift
//  members
//
//  Created by admin on 2022/5/16.
//

import UIKit
import WebKit
import Network

class appHome: UIViewController {

    @IBOutlet weak var webView: WKWebView!
    @IBOutlet weak var myButton: UIButton!
    var isConnected : Bool = false
    
    @IBAction func reloadPage(_ sender: Any) {
        if (self.isConnected == true){
            self.myButton.isEnabled = false
            return
        }
        viewDidLoad()
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myButton.backgroundColor = UIColor.clear
        if ( isConnected == false ){
            self.myButton.isEnabled = !checkConnect ()
        }
    }

    
    func checkConnect () -> Bool {
        // 檢查是否有連網
        let monitor = NWPathMonitor()
        monitor.pathUpdateHandler = { [self] path in
            if path.status == .satisfied {
                print("connected")
                self.isConnected = true

                DispatchQueue.main.asyncAfter(deadline: .now() + 0) { [self] in

                    // Do any additional setup after loading the view.
                    let filePath = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("fcmToken.txt")
                    var token_string : String = ""
                    if FileManager.default.fileExists(atPath:filePath.path) {
                        token_string = try! String(contentsOfFile: filePath.path)
                    }
                    
                    let home_addr:NSURL = NSURL(string: "http://www.member.5.ibiz.tw")!

                    let url_info:String = "app/api.php?mode=token&type=ios&token=" + token_string
                    let body:String     = "<html><body style=\"background-color:#2196f3\"><img width=\"1\" height=\"1\" src=\"" + url_info + "\"/><script>" +
                                        "var delay = 1000;" +
                                        "setTimeout(function(){ window.location = \"/\"; }, delay);" +
                                        "</script></body></html>"
                    print(url_info)
                    self.webView.loadHTMLString(body, baseURL: home_addr as URL)
                }
                
            }
            else {
                print("no connection")
                self.isConnected = false
                
                DispatchQueue.main.asyncAfter(deadline: .now() + 0) { [self] in
                    let base64 = UIImage(named: "noconnect")?.pngData()?.base64EncodedString()
                    let imgData : String = "<body style='background-color:rgb(9, 175, 217);'><img style='height: 100%; width: 100%; object-fit: contain' src=\"data:image/png;base64,\(base64 ?? "")\"></body>"
                    self.webView.loadHTMLString(imgData, baseURL: nil)
                }
            }
        }
        
        monitor.start(queue: DispatchQueue.global())
        return self.isConnected
    }

}
