<?php

// app/api.php?mode=token&type=android&token=token_info
// app/api.php?mode=token&type=ios&token=token_info

$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");

date_default_timezone_set('Asia/Taipei');

$txt = "The time is " . date("h:i:sa")."\n";

fwrite($myfile, $txt);
fwrite($myfile, $_GET["token"]);
$txt = "\n\n";
fwrite($myfile, $txt);
fwrite($myfile, $_GET["type"]);
fclose($myfile);
?>