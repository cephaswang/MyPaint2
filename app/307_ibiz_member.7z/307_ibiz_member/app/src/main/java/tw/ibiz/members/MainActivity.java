package tw.ibiz.members;


// Send Android Push Notifications Using Firebase Cloud Messaging | Android Studio (With Source Code)
// https://www.youtube.com/watch?v=M7z2MFoI6MQ

/*

第六篇：進階元件使用(webview)
https://ithelp.ithome.com.tw/articles/10239717

Build app server send requests
https://firebase.google.com/docs/cloud-messaging/send-message#java


*/


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import org.xml.sax.SAXException;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.text.ParseException;
import javax.xml.parsers.ParserConfigurationException;
import plist.NSDictionary;
import plist.PropertyListFormatException;
import plist.PropertyListParser;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Button;



public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private commomLib CB = new commomLib();
    private WebView webView = null;
    private WebView webView_token = null;
    private NSDictionary userInfo = null;
    private EditText EditText_Token;
    private Button Button_Token;
    private Button Button_send;
    private PushNotifictionHelper PU = new PushNotifictionHelper();

    public String token_info = "";


    private static final String SerVerPath = "https://www.member.5.ibiz.tw/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        webView  = (WebView)findViewById( R.id.webView);
        webView_token = findViewById(R.id.webView_token);
        EditText_Token = findViewById(R.id.EditText_Token);
        Button_Token = findViewById(R.id.Button_Token);
        Button_send = findViewById(R.id.Button_send);

        // Register the onClick listener with the implementation above
        Button_Token.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                EditText_Token.setText( "" );
            }
        });

        // Register the onClick listener with the implementation above
        Button_send.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                EditText_Token.setText( "" );

            }
        });


    }



    @Override
    protected void onStart() {
        super.onStart();

        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);

// https://www.member.5.ibiz.tw/page/app_home.php

        webView.setWebViewClient(
                new WebViewClient(){
                    @Override
                    public void onLoadResource(WebView view, String url) {
                        super.onLoadResource(view, url);

                        // System.out.println(url.toString());

                        if ( url.toString().contains("page/app_home.php") ){
                            // System.out.println( url.toString());

                            userInfo = getUserInfo();
                            if ( userInfo != null ) {
                                System.out.println(userInfo.toXMLPropertyList());
                                FirebaseMessaging.getInstance().setAutoInitEnabled(true);
                                regFireBase( );
                                // CB.playBeep(this);
                            }
                        }

//  https://www.member.5.ibiz.tw/user/api.php?mode=log_in&va=1652306305&vb=MzA1&is_uu=daniel&is_pp=qaWS12&verify_code=

                        // System.out.println( url.toString() );
                        String[] separated = url.toString().split("mode=log_in");
                        if(separated.length > 1){
                            System.out.println(url.toString());
                            System.out.println(separated.length);
                            String[] parts = separated[1].toString().split("is_uu=");
                            String[] partb = parts[1].toString().split("&is_pp=");
                            // System.out.println(partb[0]);
                            String usrid = partb[0].toString();

                            NSDictionary infoUser = new NSDictionary();
                            infoUser.put("usrid",usrid);

                            File path = MainActivity.this.getFilesDir();
                            File file = new File(path, "usrid.plist");
                            FileOutputStream stream = null;
                            try {
                                stream = new FileOutputStream(file);
                                stream.write( infoUser.toXMLPropertyList().getBytes() );
                                stream.close();
                            } catch (FileNotFoundException e) {
                                e.printStackTrace();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                            // System.out.println( infoUser.toXMLPropertyList() );
                        }
                    }
                }
        );

        webView.loadUrl( SerVerPath );

        // webView.loadUrl("http://192.168.0.11/start.php");
    }

    public void regFireBase(){

        FirebaseMessaging.getInstance().getToken()
                .addOnCompleteListener(new OnCompleteListener<String>() {
                    @Override
                    public void onComplete(@NonNull Task<String> task) {
                        if (!task.isSuccessful()) {
                            Log.w(TAG, "Fetching FCM registration token failed", task.getException());
                            return;
                        }
                        token_info =  task.getResult();
                        String token = task.getResult();
                        String usrid = (String) userInfo.get("usrid").toString();
                        String urlGet = SerVerPath + "user/api.php?mode=token&type=android&is_uu=" + usrid + "&token=" + token;
                        // String urlGet = "http://192.168.0.11/user/api.php?mode=token&type=android&is_uu=" + usrid + "&token=" + token;
                        System.out.println(urlGet);
                        webView_token.loadUrl(urlGet);

                        EditText_Token.setText( urlGet );

                        // Log and toast
                        // String msg = getString(R.string.msg_token_fmt);
                        // Log.d(TAG, msg);
                        //  Toast.makeText(MainActivity.this, msg, Toast.LENGTH_SHORT).show();
                    }
                });

    }

    public NSDictionary getUserInfo(){
        NSDictionary userInfo = null;
        File path = MainActivity.this.getFilesDir();
        File file = new File(path, "usrid.plist");
        if (file.exists()) {
            try {
                FileInputStream fileInputStream;
                fileInputStream = new FileInputStream(file);
                userInfo = (NSDictionary) PropertyListParser.parse(fileInputStream);
            } catch (IOException ignored) {
            } catch (PropertyListFormatException | ParseException | ParserConfigurationException | SAXException e) {
                e.printStackTrace();
            }
        }
        return userInfo;
    }


}