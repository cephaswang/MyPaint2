package tw.ibiz.members;

import android.content.Context;
import android.content.res.AssetFileDescriptor;
import android.media.MediaPlayer;
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.HttpResponse;
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.client.ClientProtocolException;
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.client.HttpClient;
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.client.methods.HttpGet;
import com.google.firebase.crashlytics.buildtools.reloc.org.apache.http.impl.client.DefaultHttpClient;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;


/*

daniel
qaWS12

我目前做了二個funcion，一個是讓app可以抓到目前user ID的api：
https://www.member.5.ibiz.tw/app/api.php?mode=xid

另一個是讓app把token傳送到server的API：
https://www.member.5.ibiz.tw/app/api.php?mode=token&type=android&xid=17e84a32e7662016c3fe8ce84e6c5073&token=xxxxxxxxxxxxxxxxxxxxxx

https://www.member.5.ibiz.tw/app/panel/user.php
帳號：app
密碼：Ap924@jdKe
如果你正常傳入token，可以在後台看到

在 macOS 上安裝 PHP 7.4
https://blog.epoch.tw/2020/04/21/%E5%9C%A8-macOS-%E4%B8%8A%E5%AE%89%E8%A3%9D-PHP-7-4/

PHP - FCM Push
https://dotblogs.com.tw/newmonkey48/2018/01/25/110207
https://gist.github.com/MohammadaliMirhamed/7384b741a5c979eb13633dc6ea1269ce


*/



public class commomLib {

    private MediaPlayer  m = new MediaPlayer();

    public void playBeep(Context CS) {
        try {
            if (m.isPlaying()) {
                m.stop();
                m.release();
                m = new MediaPlayer();
            }

            AssetFileDescriptor descriptor = CS.getAssets().openFd("beep.mp3");
            m.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
            descriptor.close();

            m.prepare();
            m.setVolume(1f, 1f);
            m.setLooping(false);
            m.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public HttpResponse http_get(String urlAddress){

        HttpResponse response = null;
        try {
            HttpClient client = new DefaultHttpClient();
            HttpGet request = new HttpGet();
            request.setURI(new URI(urlAddress));
            response = client.execute(request);
        } catch (URISyntaxException e) {
            e.printStackTrace();
        } catch (ClientProtocolException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
        return response;
    }



}
