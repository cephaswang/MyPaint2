<?php


?>

<a href="user/api.php?mode=log_in&is_uu=nice"><h1>user/api.php?mode=log_in&is_uu=nice</h1></a>

<br>

<a href="user/api.php?mode=log_in&is_uu=xxxxx"><h1>user/api.php?mode=log_in&is_uu=xxxxx</h1></a>
