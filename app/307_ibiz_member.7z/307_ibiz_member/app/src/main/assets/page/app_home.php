<html>
<script>

webkit.messageHandlers.bridge.postMessage(
'{"is_uu": "<?php echo $_GET["is_uu"] ?>","id": ' + Date.now() + '}')

</script>
<body>
<h1>page/app_home.php</h1>

<h1>
<?php

echo $_GET["is_uu"];


?>
</h1>

<button onclick="goBack()"><h1>Go Back</h1></button>
<script>
function goBack() {
   window.history.back();
}
</script>