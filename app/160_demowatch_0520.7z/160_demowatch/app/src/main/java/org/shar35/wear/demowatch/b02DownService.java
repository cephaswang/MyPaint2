package org.shar35.wear.demowatch;



import android.app.Service;
import android.content.Context;
import android.content.Intent;
import android.net.ConnectivityManager;
import android.os.AsyncTask;
import android.os.Environment;
import android.os.IBinder;
import android.util.Log;
import com.dd.plist.NSArray;
import com.dd.plist.PropertyListParser;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.RandomAccessFile;
import java.net.HttpURLConnection;
import java.net.MalformedURLException;
import java.net.URL;



public class b02DownService extends Service {

    private static final String TAG="b02DownService";
    public static Integer is_run = 1, DownIndex;
    public static NSArray rootArray = null;
    private String download_AsyncTask_str = "0";
    private String download_AsyncTask_run = "Download";
    private int download_status_int = 0; // 單一文檔，巳下載容量
    private download_AsyncTask download_Asy  = null;
    Intent  bufferIntent;

    public void onCreate() {

        bufferIntent = new Intent(DCSTools.BROADCAST_BUFFER2);

        // 讀取播放菜單
        try {
            File path = this.getFilesDir();
            File file = new File(path, "down.plist");
            final InputStream inStream = new FileInputStream(file);
            rootArray = (NSArray) PropertyListParser.parse(inStream);

            System.out.println(rootArray.toXMLPropertyList().toString());
        } catch (final IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (final Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }

    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {

        Download_Batch_Next(0);

        return super.onStartCommand(intent, flags, startId);
    }

    ////////////////////////////////////////////////////////////////////////////////////////
    private void Download_Batch_Next (int Bx )
    {
        if (is_run == 0 ){
            return;
        }

        if (Bx > rootArray.count() - 1 ){
            this.sendBufferCompleteBroadcast();
            return;
        }
        System.out.println("BX:" + Bx );
        DownIndex = Bx;

        NSArray OneFile = (NSArray) rootArray.objectAtIndex(Bx);
        download_Asy = new download_AsyncTask();
        download_Asy.execute( OneFile.objectAtIndex(1).toString() , String.valueOf(Bx));
    }

    private void sendBufferingBroadcast() {
        // Log.v(TAG, "BufferStartedSent");
        bufferIntent.putExtra( "buffering", String.format("%d/%d",DownIndex,rootArray.count()));
        bufferIntent.putExtra( "StatusValue",  String.format("%d", this.download_status_int ) );
        // 保存檔名
        bufferIntent.putExtra( "Mp3SaveName",  this.download_AsyncTask_run  );
        sendBroadcast(bufferIntent);
    }

    // Send a message to Activity that audio is prepared and ready to start
    // playing.
    private void sendBufferCompleteBroadcast() {
        // Log.v(TAG, "BufferCompleteSent");
        bufferIntent.putExtra("buffering", "0");
        sendBroadcast(bufferIntent);
    }


// https://stackoverflow.com/questions/64724824/how-to-implement-a-background-thread-using-java-util-concurrent-package
// AsyncTask was deprecated 已廢棄(Java 篇)替代解決取代方式
// https://tw-hkt.blogspot.com/2021/10/asynctask-was-deprecated-java.html
// 下載文檔

    class download_AsyncTask extends AsyncTask<String, Boolean, Integer> {

        Integer NextIndex = 0;
        String CACHE_NAME = "";
        RandomAccessFile outStream = null;

        @Override
        protected Integer doInBackground(String... params) {
            String urlFILE   = params[0]; // 下載的文檔網址
          //  urlFILE   = "http://bible.cephas.tw/bible_cantonese/043/43_006.mp3";
            NextIndex  = Integer.valueOf(params[1]); // 下載的文檔網址
            Log.i(TAG,urlFILE);
            String path_info [] = urlFILE.split("/");
            String sotrePATH = String.valueOf(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS))+ "/" + path_info [path_info.length - 2].toString();
            String fileSTORE = path_info [path_info.length - 1].toString();

            b02DownService.this.download_AsyncTask_run =  fileSTORE;

            Log.i(TAG,sotrePATH);
            Log.i(TAG,fileSTORE);

            File PREpath =  new File( sotrePATH );
            PREpath.mkdirs();

            // 完成下載
            File exfile = new File ( sotrePATH , fileSTORE );
            CACHE_NAME  = exfile.toString();
            if (exfile.exists()){
                // 檔案巳經存在
                System.out.println("exfile.exists():" + CACHE_NAME);
                b02DownService.this.download_AsyncTask_str = exfile.toString();
                return NextIndex;
            }

            // 未下載，斷點續傳

            long  sotreSTAT = 0;
            exfile = new File ( sotrePATH , fileSTORE+".down" );
            if (exfile.exists()){
                sotreSTAT = exfile.length();
            }


            URL url = null;
            try {
                url = new URL(urlFILE);
            } catch (MalformedURLException e1) {
                // TODO Auto-generated catch block
                e1.printStackTrace();
            }

            // 彭丽媛出访服装盘点
            // 下載文檔
            try {
                // 用 Java 实现断点续传 (HTTP)
                // http://www.ibm.com/developerworks/cn/java/joy-down/
                HttpURLConnection urlConnection = (HttpURLConnection) url.openConnection();

                Log.i(TAG,"urlConnection.getResponseCode(): " + urlConnection.getResponseCode() );

                if (HttpURLConnection.HTTP_OK != urlConnection.getResponseCode()) {
                    urlConnection.disconnect();
                    return 0;
                }

                // 檔案容量長度
                long lenghtOfFile = urlConnection.getContentLength();
                System.out.println("lenghtOfFile:" + lenghtOfFile);
                urlConnection.disconnect();

                urlConnection = (HttpURLConnection) url.openConnection();
                // urlConnection.setReadTimeout(5000);// 設定timeout時間
                urlConnection.setRequestProperty("User-Agent","NetFox");


                urlConnection.setRequestProperty("RANGE", String.format("bytes=%d-", sotreSTAT));

                System.out.println("sotreSTAT:" + sotreSTAT);

                // FIXFIXFIXFIX 2022 05 15
                if (sotreSTAT == lenghtOfFile && sotreSTAT > 0){
                    return 1;
                }
                // 檔案容量長度
                // int lenghtOfFile = urlConnection.getContentLength();

                Log.i(TAG,"urlConnection.getResponseCode(): " + urlConnection.getResponseCode() );

                // 巳經完成下載
                if ( lenghtOfFile < 1 ){
                    HttpURLConnection CurlConnection = (HttpURLConnection) url.openConnection();
                    // CurlConnection.setReadTimeout(5000);// 設定timeout時間
                    CurlConnection.setRequestProperty("User-Agent","NetFox");
                    CurlConnection.setRequestProperty("RANGE","bytes=0-");
                    lenghtOfFile = CurlConnection.getContentLength();

                    b02DownService.this.download_AsyncTask_str = exfile.toString();

                    CurlConnection.disconnect();
                    CurlConnection = null;

                    urlConnection.disconnect();
                    urlConnection = null;
                    return 1;
                }

                InputStream  inputStream = new BufferedInputStream(urlConnection.getInputStream());
                int  read = 0;
                long size = sotreSTAT;

                // 沒有保存路徑，則保存到手機內部記憶體
                outStream = new RandomAccessFile(exfile,"rw");
                outStream.seek(sotreSTAT);

                byte[] bytes = new byte[1024];
                while ((read = inputStream.read(bytes)) != -1) {
                    outStream.write(bytes, 0, read);
                    size += read;

                    // http://www.androidhive.info/2012/04/android-downloading-file-by-showing-progress-bar/
                    // 傳出，下載進度數值
                    int CN = (int)(((size)*100)/(sotreSTAT + lenghtOfFile));
                    if ( lenghtOfFile ==  size){
                        CN = 100;
                    } else {
                        if (CN > 98 ){
                            CN -= 1;
                        }
                    }
                    b02DownService.this.download_status_int = CN;
                    b02DownService.this.sendBufferingBroadcast();

                    // Log.i(TAG,"download_status_int: " +  (int)(((size)*100)/(sotreSTAT + lenghtOfFile)) );
                }
                inputStream.close();
                outStream.close();
                b02DownService.this.download_AsyncTask_str = CACHE_NAME;

                return 1;
            } catch (IOException e) {
                // 當中斷時，關閉檔案
                try {
                    if (outStream != null){
                        outStream.close();
                    }
                } catch (IOException e1) {
                    // TODO Auto-generated catch block
                    e1.printStackTrace();
                }

                // TODO Auto-generated catch block
                e.printStackTrace();
                // 下載失敗
                return 0;
            }


            // 檔案完成下載
           // return NextIndex;
        }


        @Override
        protected void onPostExecute(Integer result) {
            if(result == 1){
                System.out.println ("DownLoad: OK....");
                File Srcfile = new File ( download_AsyncTask_str+".down" );
                File Savefile = new File ( download_AsyncTask_str );
                if ( Srcfile.exists() ){
                    Srcfile.renameTo(Savefile);
                    System.out.println ("TempFile.renameTo(HXdefile)");
                }
                if ( Savefile.exists() ){
                    System.out.println("PassFile.exists():" + download_AsyncTask_str);
                }
               // DownInfo_ARY = null;
            }


            if(result == 0){
                System.out.println ("DownLoad: FAIL..");

                // 巳經下載，但未完成
                // 若下載中斷，則重新下載
                ConnectivityManager connManager = (ConnectivityManager)
                        b02DownService.this.getSystemService(Context.CONNECTIVITY_SERVICE);
                /*
                if (! DCSTools.haveInternet(connManager)){
                    handler.postDelayed(DownContinue, 500);
                    return;
                }*/
            }

            // 批量下載
            b02DownService.this.Download_Batch_Next( NextIndex + 1);

        }
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}