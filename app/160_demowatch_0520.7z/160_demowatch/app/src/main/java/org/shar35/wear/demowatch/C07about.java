package org.shar35.wear.demowatch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.dd.plist.NSArray;
import com.dd.plist.NSDictionary;
import com.dd.plist.PropertyListParser;

import java.io.InputStream;
import java.util.Locale;

public class C07about extends AppCompatActivity {

    private TextView btn_menu1;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c07about);

        Intent intent = getIntent();
        // idBook = intent.getStringExtra("id");
        String title = intent.getStringExtra("title");
        setTitle(title);

        btn_menu1 = (TextView) findViewById(R.id.btn_menu1);


        NSDictionary rootDict = null;
        // 讀取菜單文檔
        try {
            AssetManager am = getAssets();
            String audioPLIST = null;
            if (Locale.getDefault().equals (Locale.SIMPLIFIED_CHINESE)){
                audioPLIST = "c01_data.plist";
            } else {
                audioPLIST = "c01_data.plist";
            }
            InputStream is = am.open(audioPLIST);
            // 全部內容
            rootDict = (NSDictionary) PropertyListParser.parse(is);
        } catch(Exception ex) {
            ex.printStackTrace();
            Toast.makeText(getApplicationContext(), "讀取菜單文檔 失敗" , Toast.LENGTH_LONG).show();
        }

        NSArray menuArray = (NSArray) rootDict.get("version");

        btn_menu1.setText(menuArray.objectAtIndex(0).toString());


    }
}