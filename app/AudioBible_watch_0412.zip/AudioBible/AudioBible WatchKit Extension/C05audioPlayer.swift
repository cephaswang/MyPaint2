//
//  C05audioPlayer.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/10.
//

import SwiftUI

struct C05audioPlayer: View {
    @StateObject var downloadModel = DownloadTaskModel()
    
    @State var CA:C05audio_info = C05audio_info()
    @State var MenuArray:[CellItem] =  []
    @State var playIndex:Int
    @State var isHidden:Double = 1
    @State var OneCell: CellItem = CellItem(id: 0, name: "", push: "")
    @State var playTitle:String = ""
    
    var body: some View {
        ScrollView {

            VStack {
            
                HStack {
                    // [SwiftUI] Make Buttons (1) - using Image system Name, No coding. No Image file. using SF Symbols
                    // https://www.youtube.com/watch?v=X4LBLlxX2VU
                    Button(
                        action: {
                        print("1")
                            if (playIndex > 0){
                                playIndex = playIndex - 1
                            } else {
                                playIndex = MenuArray.count - 1
                            }
                            playIndex = playIndex %  MenuArray.count
                            OneCell = MenuArray[playIndex]
                            playTitle = OneCell.name
                            downloadModel.startDownload(urlString:OneCell.push ,downOnly: false)
                    },
                        label: {
                            Image(systemName: "backward.fill")
                                .resizable()
                                .frame(width: 36.0, height: 36.0,alignment: .center)
                            
                        }).opacity(isHidden)


                    Button(
                        action: {
                        print("1")
                            OneCell = MenuArray[playIndex]
                            playTitle = OneCell.name
                            downloadModel.startDownload(urlString:OneCell.push ,downOnly: false)
                    },
                        label: {
                            Image(systemName: "play.fill")
                                .resizable()
                                .frame(width: 36.0, height: 36.0,alignment: .center)
                    })

                    
                    Button(
                        action: {
                        print("1")
                        playIndex = (playIndex + 1 ) % MenuArray.count
                        OneCell = MenuArray[playIndex]
                        playTitle = OneCell.name
                        downloadModel.startDownload(urlString:OneCell.push ,downOnly: false)
                    },
                        label: {
                            Image(systemName: "forward.fill")
                                .resizable()
                                .frame(width: 36.0, height: 36.0,alignment: .center)
                    }).opacity(isHidden)
                }

                Button(
                    action: {
                    print("1")
                },
                    label: {
                        Image(systemName: "forward.fill")
                            .resizable()
                            .frame(width: 140.0, height: 140.0,alignment: .center)
                }).frame(width: 140.0, height: 140.0,alignment: .center)
                .overlay(
                    ZStack{
                        if downloadModel.showDownloadProgress{
                            DownloadProgressView(progress: $downloadModel.downloadProgress)
                                .environmentObject(downloadModel)
                        }
                    }
                )
            
                HStack {
                    Button(
                        action: {
                        print("1")
                    },
                        label: {
                            Image(systemName: "bookmark.circle.fill")
                                .resizable()
                                .frame(width: 50.0, height: 50.0,alignment: .center)
                    })

                    
                    Button(
                        action: {
                        print("1")
                    },
                        label: {
                            Image(systemName: "repeat.circle.fill")
                                .resizable()
                                .frame(width: 50.0, height: 50.0,alignment: .center)
                    })

                }
            }
        }.onAppear(){
            MenuArray =
                [CellItem(id: 0, name: "1Sa 撒母耳記上.第17章", push: "http://bible.cephas.tw/bible_taiwanese/009/9_017.mp3"),
                 CellItem(id: 1, name: "1Sa 撒母耳記上.第18章", push: "http://bible.cephas.tw/bible_taiwanese/009/9_018.mp3"),
                 CellItem(id: 2, name: "Luk 路加福音.第11章", push: "http://bible.cephas.tw/bible_taiwanese/042/42_011.mp3")]
            
            if (MenuArray.count < 2){
                isHidden = 0
            }
            
            playIndex = playIndex %  MenuArray.count
            OneCell = MenuArray[playIndex]
            downloadModel.startDownload(urlString:OneCell.push ,downOnly: false)
            playTitle = OneCell.name
            
        }
        .navigationTitle(playTitle).font(.body)
    }
}

struct C05audioPlayer_Previews: PreviewProvider {

    static var previews: some View {
        C05audioPlayer(playIndex:0)
    }
}
