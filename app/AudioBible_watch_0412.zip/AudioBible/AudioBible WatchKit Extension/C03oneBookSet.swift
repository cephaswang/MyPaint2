//
//  C02bibleMenu.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import SwiftUI

struct C03oneBookSet: View {
    
    @State var bookTitle:String = ""
    @State var PlistName:String = ""
    @State var MenuArray:[CellAudio] = []
    @State var CA:C03oneBook_info = C03oneBook_info()

    var body: some View {
        NavigationView {
            List(MenuArray, id: \.id) { (OneItem) in
                TableViewCell(textLabel: OneItem.name)
                .onTapGesture {
                    print("touched item \(OneItem.name)")
                    print("touched push \(OneItem.link)")
                    print("touched file \(OneItem.file)")
                }
            }.padding(.all, 0)
        }
        .navigationTitle(bookTitle)
        .onAppear(){
           
            let ArraySRC:NSArray = CA.getOneBook(fileName: PlistName)
            var OneBook:NSArray
            var BookName:NSString
            var linkName:NSString
            var fileName:NSString

            for Px:Int in 0 ... ArraySRC.count - 1 {
                OneBook  = ArraySRC.object(at: Px) as! NSArray
                BookName = OneBook.object(at: 0) as! NSString
                linkName = OneBook.object(at: 1) as! NSString
                fileName = OneBook.object(at: 2) as! NSString
                MenuArray.append(
                    CellAudio(id: Px+1,
                              name: String(BookName),
                              link: String(linkName),
                              file: String(fileName))
                )
            }
            
        }
        
    }
}

struct C03oneBookSet_Previews: PreviewProvider {
    static var previews: some View {
        C03oneBookSet(bookTitle:"bookTitle",PlistName:"tra_book_01.plist")
    }
}
