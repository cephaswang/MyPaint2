//
//  ContentView.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//


// https://swiftontap.com/view/onappear(perform:)

import SwiftUI

struct C01mainMenu: View {
    @State var isTapped = false
    @State var int_date:Int = 0
    @State var OneDate_Array:[CellItem] = []
    @State var MenuArray:[CellItem] = [
        CellItem(id:1,name:"今日讀經",push:""),
        CellItem(id:2,name:"舊約聖經",push:""),
        CellItem(id:3,name:"新約聖經",push:""),
        CellItem(id:4,name:"台語詩歌",push:""),
        CellItem(id:5,name:"我的最愛",push:""),
        CellItem(id:6,name:"讀經進度",push:"")
    ]
    
    @State var CA:C01Menu_info = C01Menu_info()
    @State var int_Selected:Int = 0
    @State var strToday:String = ""

    // MARK: - button Act

    var body: some View {

        NavigationView {
            
            VStack {
                HStack {
                    Button(
                        action: {
                            int_date = int_date - 1
                            strToday = CA.get_Today(offset: int_date)
                            OneDate_Array = CA.getOneDay(strOneDay: strToday)
                            print(OneDate_Array)
                            print(strToday)
                    },
                        label: {
                            Image(systemName: "backward.fill")
                                .resizable()
                                .frame(width: 30.0, height: 30.0,alignment: .center)
                    }) .frame(width: 50.0, height: 50.0,alignment: .center)
                    
                    Button(
                        action: {
                            int_date = 0
                            strToday = CA.get_Today(offset: int_date)
                            OneDate_Array = CA.getOneDay(strOneDay: strToday)
                            print(strToday)
                    },
                        label: {
                            Image(systemName: "repeat.circle.fill")
                                .resizable()
                                .frame(width: 30.0, height: 30.0,alignment: .center)
                            
                    }).frame(width: 50.0, height: 50.0,alignment: .center)
                    
                    Button(
                        action: {
                            int_date = int_date + 1
                            strToday = CA.get_Today(offset: int_date)
                            OneDate_Array = CA.getOneDay(strOneDay: strToday)
                            print(strToday)
                    },
                        label: {
                            Image(systemName: "forward.fill")
                                .resizable()
                                .frame(width: 30.0, height: 30.0,alignment: .center)
                            
                    }).frame(width: 50.0, height: 50.0,alignment: .center)
                    // Text(strToday)
                    
                }.padding(.top,30)
                
                List(MenuArray, id: \.id) { (OneItem) in
                    // SwiftUI Tutorial - Lists and Navigation
                    // https://www.youtube.com/watch?v=Cl2gAs7hySk
                    NavigationLink (destination: chooseDestination(), isActive: self.$isTapped) {
                        TableViewCell(textLabel: OneItem.name)
                        .onTapGesture {
                            print("touched item \(OneItem.name)")
                            print("touched push \(OneItem.push)")
                            isTapped.toggle()
                            int_Selected = OneItem.id
                        }
                    
                        // https://stackoverflow.com/questions/66017531/swiftui-navigationlink-bug-swiftui-encountered-an-issue-when-pushing-anavigatio
                    }.background(EmptyView())
                }.padding(.all, 0)
                
            }
            
        }
        .navigationBarTitle(strToday)
        .onAppear(){
            int_date = 0
            strToday = CA.get_Today(offset: int_date)
        }
    }
    
    @ViewBuilder
    func chooseDestination() -> some View {
        switch int_Selected {
            case 1: C05audioPlayer(playIndex:0) //C00Home() 
            case 2: C02bibleMenu(indexBook:1)   // 舊約聖經
            case 3: C02bibleMenu(indexBook:0)   // 新約聖經
            case 4: C03taiyuMenu()              // 台語詩歌
            case 5: C02bibleMenu(indexBook:5)
            case 6: C02bibleMenu(indexBook:6)
            default: EmptyView()
        }
    }
    
}

struct C01mainMenu_Previews: PreviewProvider {
    static var previews: some View {
        C01mainMenu()
    }
}
