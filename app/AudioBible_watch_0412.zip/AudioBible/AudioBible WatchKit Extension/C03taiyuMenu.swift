//
//  C02bibleMenu.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import SwiftUI

struct C03taiyuMenu: View {
    
    @State var indexBook:Int = 0
    @State var MenuArray:[CellItem] = []
    @State var CA:C03taiyu_info = C03taiyu_info()
    @State var bookTitle:String = "台語詩歌"

    var body: some View {
        NavigationView {
            List(MenuArray, id: \.id) { (OneItem) in
                TableViewCell(textLabel: OneItem.name)
                .onTapGesture {
                    print("touched id \(OneItem.id)")
                    print("touched item \(OneItem.name)")
                    print("touched push \(OneItem.push)")
                }
            }.padding(.all, 0)
        }
        .navigationTitle(bookTitle)
        .onAppear(){
            print("C03taiyuMenu:\(indexBook)")
            let ArraySRC:NSArray = CA.getTaiSong()
            var OneBook:NSArray
            var BookName:NSString
            var linkName:NSString
          //  var fileName:NSString

            for Px:Int in 0 ... ArraySRC.count - 1 {
                OneBook  = ArraySRC.object(at: Px) as! NSArray
                BookName = OneBook.object(at: 0) as! NSString
                linkName = OneBook.object(at: 1) as! NSString
                MenuArray.append(
                    CellItem(id: Px,
                             name: "\(Px+1) \(String(BookName))" ,
                             push: String(linkName))
                    
                )
            }
        }
        
    }
}

struct C03taiyuMenu_Previews: PreviewProvider {
    static var previews: some View {
        C03taiyuMenu()
    }
}
