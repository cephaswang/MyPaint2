//
//  DownloadProgressView.swift
//  AudioPlayer WatchKit Extension
//
//  Created by admin on 2022/4/11.
//  https://www.youtube.com/watch?v=OPLlRd54mnk

import SwiftUI

struct DownloadProgressView: View {
    @Binding var progress:CGFloat
    @EnvironmentObject var downloadModel:DownloadTaskModel
    var scaleVar:CGFloat = 120
    var body: some View {
        ZStack{
            Color.primary
                .opacity(0.25)
                .ignoresSafeArea()
            VStack(spacing:15){
                ZStack{
                    Circle()
                        .fill(Color.gray.opacity(0.3))
                        ProgressShape(progress: progress)
                        .fill(Color.gray.opacity(0.4))
                        .rotationEffect(.init(degrees: -90))
                }
                .frame(width: scaleVar, height: scaleVar)
                
                /*
                Button {
                    downloadModel.cancelTask()
                    print(1)
                } label: {
                    Text("Cancel")
                    .fontWeight(.semibold)
                    
                }
                .padding(.top)
                */

            }
            .padding(.vertical,20)
            .padding(.horizontal,50)
            .background(Color.white)
            .cornerRadius(8)
        }
    }
}


struct DownloadProgressView_Previews: PreviewProvider {
    static var previews: some View {
        DownloadProgressView(progress:.constant(0.5))
    }
}

struct ProgressShape:Shape {
    var progress:CGFloat
    var scaleVar_Helf:CGFloat = 60
    func path(in rect: CGRect) -> Path {
        return Path{path in path.move(to: CGPoint(x: rect.midX, y: rect.midY) )
            path.addArc(center: CGPoint(x: rect.midX, y: rect.midY), radius: scaleVar_Helf, startAngle: .zero, endAngle: .init(degrees: Double(progress * 360)), clockwise: false)
        }
    }
}
