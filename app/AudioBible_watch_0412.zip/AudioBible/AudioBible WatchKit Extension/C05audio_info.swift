//
//  C05audioPlayer.swift
//  AudioPlayer WatchKit Extension
//
//  Created by admin on 2022/4/10.
//

import Foundation
import AVFoundation
import MediaPlayer

class C05audio_info {
    var player:AVAudioPlayer?
    
    func initPlayer(url:URL){
        do {
            // AVAudioPlayer: How to Change the Playback Speed of Audio?
            // https://stackoverflow.com/questions/2350657/avaudioplayer-how-to-change-the-playback-speed-of-audio
            
            self.player = try AVAudioPlayer(contentsOf: url)
            self.player?.enableRate = true
            self.player?.prepareToPlay()
        } catch let error as NSError {
            print(error.debugDescription)
        }
    }
    
    func Play(){
        self.player?.play()
    }
    func Pause(){
        self.player?.pause()
    }
    
    func isPlaying()->Bool{
        return ((self.player?.isPlaying) != nil)
    }
    
    func setRate(rate:Float){
        self.player?.rate = rate
    }
    
    // MARK: - sessionSimpleDownload
        // https://www.jianshu.com/p/6ca4864b3600
        func sessionSimpleDownload( fileUrl: String , strStore: String){
            // fileUrl http://wpanet.wordproject.com/bibles/app/audio/4/1/1.mp3
            // strStore 1_001.mp3

           var playFileName = String()
            
            if ( strStore != "" ) {
                // 檢查檔案是否巳經下載
                let documnets:String = NSHomeDirectory() + "/Documents/" + strStore
                let fileManager = FileManager.default
                if fileManager.fileExists(atPath: documnets) {
                    playFileName = documnets
                 //   Timer.scheduledTimer(timeInterval: 0.5 , target: self, selector: #selector(startPlay), userInfo: nil, repeats: false)
                    return
                }
            }
            
        //    btnBackword.setEnabled(false)
         //   btnForward.setEnabled(false)
        //    btnPlay.setEnabled(false)
         //   btnPause.setEnabled(false)
            
            // URLSession Cookbook - Networking with URLSession on iOS 11 / Xcode 9 / Swift 4
            // https://www.youtube.com/watch?v=BFaZaUTF6m4
            // Xcode - Swift - Image Downloading Asynchronously using URLSession
            // https://www.youtube.com/watch?v=kHE61puIKMo
            // 下载地址
       //     let url = URL(string: fileUrl )
            // 请求  URLSession.shared.downloadTask
            // let request = URLRequest(url: url!)
            // self.session = URLSession.shared
            // 使用背景設定建立 session，並且給一個session的名字
            // let config = URLSessionConfiguration.background(withIdentifier: "abc")
            // delegateQueue如果為nil，delegate會在另外一個執行緒中被呼叫
            
            // 24955482: NSURLSessionConfiguration default constructor has surprising behavio
            // https://github.com/lionheart/openradar-mirror/issues/7707
          //  let config = URLSessionConfiguration.default
            // let config:URLSessionConfiguration = URLSessionConfiguration.default
         //   self.session = URLSession(configuration: config, delegate: self, delegateQueue: nil)
            // self.session = URLSession(configuration: .ephemeral)
            // self.session.delegate = self  as URLSessionDelegate
          //  let dnTask = self.session?.downloadTask(with: url!)
            
           // dnTask?.resume()
        }
        
}
