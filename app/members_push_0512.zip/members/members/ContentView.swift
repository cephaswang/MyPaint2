import SwiftUI
import WebKit

struct WebView: UIViewRepresentable {

    class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler, UIScrollViewDelegate, URLSessionDelegate , URLSessionDownloadDelegate{

        
        func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
            print(location)
        }
        
        var webView: WKWebView?
        var session:URLSession? = nil
        var DownloadTaskSession : URLSessionDownloadTask!
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            self.webView = webView
            self.webView!.scrollView.delegate = self
        }
        
        // receive message from wkwebview
        func userContentController(
            _ userContentController: WKUserContentController,
            didReceive message: WKScriptMessage
        ) {

            print(message.body)
            
            let json = (message.body as! String).data(using: .utf8)!
            
            struct userinfo: Codable {
                var is_uu: String
                var id: Int
            }
            let decoder = JSONDecoder()
            let userData = try? decoder.decode(userinfo.self, from: json )

            print(userData!.is_uu as String)
            
            //let date = Date()
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
                //self.messageToWebview(msg: "hello, I got your messsage: \(message.body) at \(date)")
                
                let url = FileManager.default.urls(for: .documentDirectory, in: .userDomainMask)[0].appendingPathComponent("fcmToken.txt")
                let tokent = try! String(contentsOfFile: url.path)


                //String urlGet = "https://www.member.5.ibiz.tw/user/api.php?mode=token&type=android&is_uu=" + usrid + "&token=" + token;
                let usrid = userData!.is_uu as String
               // let tokent = "globalString.token_info"
                var urlString:String = ""
                urlString = "http://192.168.0.11/user/api.php?mode=token&type=ios&is_uu=\(usrid)&token=\(tokent)"
                print(urlString)
                self.session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
                self.DownloadTaskSession = self.session!.downloadTask(with: URL(string: urlString)!)
                self.DownloadTaskSession.resume()
                
            }
        }
        
        func messageToWebview(msg: String) {
            self.webView?.evaluateJavaScript("webkit.messageHandlers.bridge.onMessage('\(msg)')")
        }
    }
    

    
    //MARK: - UIScrollViewDelegate
    func scrollViewWillBeginZooming(_ scrollView: UIScrollView, with view: UIView?) {
             scrollView.pinchGestureRecognizer?.isEnabled = false
    }

    
    func makeCoordinator() -> Coordinator {
        return Coordinator()
    }
    
    // Disable zoom in WKWebView?
    // https://stackoverflow.com/questions/40452034/disable-zoom-in-wkwebview
    
    func makeUIView(context: Context) -> WKWebView {
        
        let source: String = "var meta = document.createElement('meta');" +
            "meta.name = 'viewport';" +
            "meta.content = 'width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=no';" +
            "var head = document.getElementsByTagName('head')[0];" +
            "head.appendChild(meta);"

        let script: WKUserScript = WKUserScript(source: source, injectionTime: .atDocumentEnd, forMainFrameOnly: true)
        
        let coordinator = makeCoordinator()
        let userContentController = WKUserContentController()
        userContentController.add(coordinator, name: "bridge")
        userContentController.addUserScript(script)
        
        let configuration = WKWebViewConfiguration()
        configuration.userContentController = userContentController
        
        let _wkwebview = WKWebView(frame: .zero, configuration: configuration)
        _wkwebview.navigationDelegate = coordinator
        
        return _wkwebview
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {

      //  let url:NSURL = NSURL(string: "http://www.member.5.ibiz.tw")!
        
        let url:NSURL = NSURL(string: "http://192.168.0.11/start.php")!
        let request:NSURLRequest = NSURLRequest(url:url as URL)
        webView.load(request as URLRequest)
    }
}


struct ContentView: View {
    
    var body: some View {
        VStack {
            WebView()
        }.navigationBarHidden(true)
    }
}

