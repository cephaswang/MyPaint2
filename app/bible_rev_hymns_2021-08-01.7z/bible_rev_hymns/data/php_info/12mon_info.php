<?php
/**
 * Examples for how to use CFPropertyList
 * Read an XML PropertyList
 * @package plist
 * @subpackage plist.examples
 */

// just in case...
error_reporting( E_ALL );
ini_set( 'display_errors', 'on' );

/**
 * Require CFPropertyList
 */
require_once(dirname(__FILE__).'/CFPropertyList.php');


/*
 * create a new CFPropertyList instance which loads the sample.plist on construct.
 * since we know it's an XML file, we can skip format-determination
 */
 echo '<pre>';

for($Ux=1;$Ux<13;$Ux++){
	$file_name = sprintf("/12mon/tra_daily_%02d.plist",$Ux);
	$plist = new CFPropertyList( dirname(__FILE__).$file_name, CFPropertyList::FORMAT_XML );

	$Ix = 0;
	foreach ( $plist->toArray() as  $key1 => $value1){
		// echo $key1;
		foreach ( $value1 as  $value2){
			$Ix++;
			if($Ix % 2 == 1){
				echo $value2[0];
				echo "\n";
			}
		}
	}
}