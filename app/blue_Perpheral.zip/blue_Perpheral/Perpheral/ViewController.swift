//
//  ViewController.swift
//  Perpheral
//  iOS 程式設計 - 藍牙 (I) - Peripheral
//  https://www.youtube.com/watch?v=_24njKb6JiU
//  Created by admin on 2022/7/3.
//

/*
 
 iOS swift 5: 關於 "CoreBluetooth XPC connection invalid"
 http://snoopymemory.blogspot.com/2019/05/ios-swift-5-about-corebluetooth-xpc.html

 
*/


import Cocoa
import CoreBluetooth

class ViewController: NSViewController , CBPeripheralManagerDelegate{
    
    enum SendDataError:Error{
        case CharacteristicNotFound
    }
    
    let UUID_SERVICE = "A001"
    let UUID_CHARACTERISTIC = "C001"
    
    var peripheralManager:CBPeripheralManager! = nil
    var charDictionary = [String:CBMutableCharacteristic]()
    
    
    func peripheralManagerDidUpdateState(_ peripheral: CBPeripheralManager) {
        guard peripheral.state == .poweredOn else {
            return
        }
        
        var service:CBMutableService
        var characteristic:CBMutableCharacteristic
        var charArray = [CBCharacteristic]()
        
        service = CBMutableService(type: CBUUID(string: UUID_SERVICE), primary: true)

        characteristic = CBMutableCharacteristic(
            type:  CBUUID(string: UUID_CHARACTERISTIC),
            properties: [.notifyEncryptionRequired, .writeWithoutResponse],
            value: nil,
            permissions: [.writeEncryptionRequired])
           
        charArray.append( characteristic)
        
        charDictionary[UUID_CHARACTERISTIC] = characteristic
        
/*
 https://books.google.com.tw/books?id=42R0DwAAQBAJ&pg=PA578&lpg=PA578&dq=%5BString:CBMutableCharacteristic%5D()+swift&source=bl&ots=jAHEY-8V3e&sig=ACfU3U0LV5uHC2eI20dhVQmhUzIuKS_mAQ&hl=zh-TW&sa=X&ved=2ahUKEwie75e_69z4AhUQBd4KHUGFDIEQ6AF6BAgDEAM#v=onepage&q=%5BString%3ACBMutableCharacteristic%5D()%20swift&f=false
 */

        service.characteristics = charArray
        peripheralManager.add(service)
        
    }
    
    /*
     https://gist.github.com/bricklife/45e4a2f53ce4e9ce1c87969070b8f24b
     */

    func peripheralManager(_ peripheral: CBPeripheralManager, didAdd service: CBService, error: Error?) {
        guard error == nil else {
           // print("ERROR:{\(#file,#function)}\n")
            print("ERROR:{\(#file)}\n")
            print(error!.localizedDescription)
            return
        }

        let deviceName = "My Device"

        peripheral.startAdvertising(
            [ CBAdvertisementDataServiceUUIDsKey:[service.uuid],
             CBAdvertisementDataLocalNameKey:deviceName]
        )
    }

    func peripheralManagerDidStartAdvertising(_ peripheral: CBPeripheralManager, error: Error?) {
        print("StartAdvertising")
    }

    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didSubscribeTo characteristic: CBCharacteristic) {
        
        if peripheral.isAdvertising {
            peripheral.stopAdvertising()
            print("stopAdvertising")
        }
        
        if characteristic.uuid.uuidString == UUID_CHARACTERISTIC {
            print("didSubscribeTo:", central, characteristic)
        }
    }
    
    func peripheralManager(_ peripheral: CBPeripheralManager, central: CBCentral, didUnsubscribeFrom characteristic: CBCharacteristic) {
        if characteristic.uuid.uuidString == UUID_CHARACTERISTIC {
            print("didUnsubscribeFrom:", central, characteristic)
        }
    }
    
    func sendData (_ data:Data, uuidString : String) throws{
        guard let characteristic = charDictionary[uuidString] else {
            throw SendDataError.CharacteristicNotFound
        }
        peripheralManager.updateValue(
            data,
            for: characteristic,
            onSubscribedCentrals: nil
        )
    }
    
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveWrite requests: [CBATTRequest]) {
        
        guard let at = requests.first else {
            return
        }
        
        guard let data = at.value else {
            return
        }
        
       // peripheral.respond(to: at , withResult: .success)
        
        DispatchQueue.main.async {
            let string = "> " + String(data: data, encoding: .utf8)!
            print(string)
            
            if self.TextView.string == "" {
                self.TextView.string = string
            } else {
                self.TextView.string = self.TextView.string + "\n" + string
            }
            
        }

    }

    
    func peripheralManager(_ peripheral: CBPeripheralManager, didReceiveRead request: CBATTRequest) {
        if request.characteristic.uuid.uuidString == UUID_CHARACTERISTIC {
            let data = "how are you".data(using: .utf8)
            request.value = data
        }
        peripheral.respond(to: request, withResult: .success)
    }

    override func viewDidLoad() {
        super.viewDidLoad()
        
        let queue = DispatchQueue.global()
        
        peripheralManager = CBPeripheralManager(delegate: self, queue: queue)

        // Do any additional setup after loading the view.
    }

    override var representedObject: Any? {
        didSet {
        // Update the view, if already loaded.
        }
    }

    @IBOutlet var TextView: NSTextView!
    
    @IBOutlet weak var TextField: NSTextField!
    
    @IBAction func sendClick(_ sender: Any) {
        let string = TextField.stringValue
        
        if string == "" {
            return
        }
        
        if self.TextView.string == "" {
            self.TextView.string = string
        } else {
            self.TextView.string = self.TextView.string + "\n" + string
        }
        
        do {
            try sendData(string.data(using: .utf8)!, uuidString: "C001")
        } catch {
            print(error)
        }
        
        // https://www.youtube.com/watch?v=_24njKb6JiU
        
    }
    
    
}

