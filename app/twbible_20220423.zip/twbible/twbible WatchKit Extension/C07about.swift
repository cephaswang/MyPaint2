//
//  C07about.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/19.
//

import SwiftUI

struct C07about: View {
    
    @State var APP_Version:String
    @State var bookTitle:String
    
    var body: some View {
        Text(APP_Version)
        Text("WeChat: cephaswang")
        Text("share35app@gmail.com").navigationBarTitle(bookTitle)
    }
}

struct C07about_Previews: PreviewProvider {
    static var previews: some View {
        C07about(APP_Version:"", bookTitle: "")
    }
}
