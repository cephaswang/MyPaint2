//
//  Menu_Manager.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import Foundation

class C01Menu_info {
    // 日期暫存
    var int_date:Int = 0
    var str_Today : String = ""
    var MenuArray:[CellItem] = []
    var initData  = CommClass()

    func get_Today(offset:Int)->String{
        self.int_date = offset
        let now : Date = my_today()
        var strDate: String = "\(now)"
        strDate = "\(strDate.prefix(10))"
        strDate = "\(strDate.suffix(5))"
        return strDate
    }
    
    func my_today() -> Date {
        // http://my.oschina.net/u/559156/blog/125340
        // NSDate的计算问题、日期计算、时区问题、NSTimer
        let now = Date.init()
        let tz  = NSTimeZone.default as NSTimeZone
        let seconds: Int = tz.secondsFromGMT(for: now) + 24*60*60*int_date
        return Date(timeInterval: TimeInterval(seconds) , since: now)
    }
    
    func getOneDay(strOneDay:String)->[CellItem] {
        let playArray : NSMutableArray = NSMutableArray()
        let OneDaySets:NSArray  = initData.getOneDay(strOneDay: strOneDay)
        var OneItems:[CellItem] = []
        var OneDay:NSArray = []
        var OneArray:NSArray = NSArray()
        for index in (0 ... OneDaySets.count - 1){
            OneDay = OneDaySets.object(at:index) as! NSArray
            OneItems.append(
                CellItem(id: index,
                         name: OneDay.object(at:0) as! String,
                         push: OneDay.object(at:1) as! String)
                             )
            OneArray = [OneDay.object(at:0) as! String, OneDay.object(at:1) as! String]
            playArray.add(OneArray)
        }
        initData.writeDocuArray(destFileName: "playArray.plist", dictSource: playArray)
        return OneItems
    }

}
