//
//  C04bookMark.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/17.
//

import SwiftUI

struct C04bookMark: View {

    @State var PlistName:String = ""
    @State var MenuArray:[CellItem] = []
    @State var isTapped = false
    @State var int_Selected:Int = 0
    var initData  = CommClass()
    @State var bookTitle:String
    @State var noRecord:String

    var body: some View {
        NavigationView {
            if (MenuArray.count > 1){
                List(MenuArray, id: \.id) { (OneItem) in
                    NavigationLink (destination: C05audioPlayer(playIndex:int_Selected), isActive: self.$isTapped) {
                        TableViewCell(textLabel: OneItem.name)
                        .onTapGesture {
                            print("touched is \(OneItem.id)")
                            print("touched item \(OneItem.name)")
                            print("touched push \(OneItem.push)")
                            isTapped.toggle()
                            int_Selected = OneItem.id
                        }
                    }
                }.padding(.all, 0)
            } else {
                Text(noRecord)
            }
        }
        .navigationTitle(bookTitle)
        .onAppear(){
            print("C04bookMark")
            initData.getBookMark()
            let playArray:NSArray = initData.readDocuArray(fileName: "playArray.plist")
            MenuArray = []
            
            if (playArray.count > 1){
                var OneDay:NSArray = []
                
                for Px in (0 ... playArray.count - 1){
                    OneDay = playArray.object(at:Px) as! NSArray
                    MenuArray.append(
                        CellItem(id: Px,
                                 name: "\(Px+1) \(String(OneDay.object(at:0) as! String))",
                                 push: OneDay.object(at:1) as! String)
                       )
                }
                
                
            }
        }
        
    }
}

struct C04bookMark_Previews: PreviewProvider {
    static var previews: some View {
        C04bookMark(bookTitle: "", noRecord: "")
    }
}
