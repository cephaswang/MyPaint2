//
//  twbibleApp.swift
//  twbible WatchKit Extension
//
//  Created by admin on 2022/4/19.
//

import SwiftUI

@main
struct twbibleApp: App {
    var body: some Scene {
        WindowGroup {
            NavigationView {
                C01mainStart()
            }
        }
    }
}
