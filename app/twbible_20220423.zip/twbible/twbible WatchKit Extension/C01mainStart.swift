//
//  C01mainStart.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/19.
//

import SwiftUI

struct C01mainStart: View {
    
    @State var int_date:Int = 0
    @State var OneDate_Array:[CellItem] = []
    @State var CA:C01Menu_info = C01Menu_info()
    @State var int_Selected:Int = 0
    @State var strToday:String = ""
    @State var strBookMark:String = ""
    @State var strConfig:String = ""
    @State var strAbout:String = ""
    @State var strTaiyu:String = ""
    @State var strVersion:String = ""
    @State var strNoRecord:String = ""
    @State var strPlaySpeed:String = ""
    
    
    var initData  = CommClass()
    var srcMenu:NSArray = []
    @State var srcConfig:[String] = ["","",""]
    
    @State var MenuArray:[CellItem] = [
        CellItem(id:1,name:"1 今日讀經",push:""),
        CellItem(id:2,name:"2 舊約聖經",push:""),
        CellItem(id:3,name:"3 新約聖經",push:""),
        CellItem(id:4,name:"4 台語詩歌",push:""),
        CellItem(id:5,name:"5 我的最愛",push:""),
        CellItem(id:6,name:"6 設定",push:""),
        CellItem(id:7,name:"7 關於",push:"")
    ]
    
    @State var OLD_Books:String = ""
    @State var NEW_Books:String = ""
 
    var body: some View {
        ScrollView {

            VStack {

                HStack {
                    Button(
                        action: {
                            int_date = int_date - 1
                            strToday = CA.get_Today(offset: int_date)
                            OneDate_Array = CA.getOneDay(strOneDay: strToday)
                            print(OneDate_Array)
                            print(strToday)
                    },
                        label: {
                            Image(systemName: "backward.fill")
                                .resizable()
                                .frame(width: 30.0, height: 30.0,alignment: .center)
                    }) .frame(width: 50.0, height: 50.0,alignment: .center)
                    
                    Button(
                        action: {
                            int_date = 0
                            strToday = CA.get_Today(offset: int_date)
                            OneDate_Array = CA.getOneDay(strOneDay: strToday)
                            print(OneDate_Array)
                            print(strToday)
                    },
                        label: {
                            Image(systemName: "repeat.circle.fill")
                                .resizable()
                                .frame(width: 30.0, height: 30.0,alignment: .center)
                            
                    }).frame(width: 50.0, height: 50.0,alignment: .center)
                    
                    Button(
                        action: {
                            int_date = int_date + 1
                            strToday = CA.get_Today(offset: int_date)
                            OneDate_Array = CA.getOneDay(strOneDay: strToday)
                            print(OneDate_Array)
                            print(strToday)
                    },
                        label: {
                            Image(systemName: "forward.fill")
                                .resizable()
                                .frame(width: 30.0, height: 30.0,alignment: .center)
                            
                    }).frame(width: 50.0, height: 50.0,alignment: .center)
                    // Text(strToday)
                    
                }
                
                
                NavigationLink(destination: C05audioPlayer(playIndex:0, strPlaySpeed: strPlaySpeed)) {
                    Text(MenuArray[0].name).leftAligned()
                }
                NavigationLink(destination: C02bibleMenu(isOldTest:1, bookTitle: OLD_Books) ) {
                    Text(MenuArray[1].name).leftAligned()
                }
                NavigationLink(destination: C02bibleMenu(isOldTest:0, bookTitle: NEW_Books) ) {
                    Text(MenuArray[2].name).leftAligned()
                }
                NavigationLink(destination: C03taiyuMenu( bookTitle: strTaiyu) ) {
                    Text(MenuArray[3].name).leftAligned()
                }
                NavigationLink(destination: C04bookMark( bookTitle: strBookMark, noRecord: strNoRecord) ) {
                    Text(MenuArray[4].name).leftAligned()
                }
                NavigationLink(destination: C06config( bookTitle: strConfig, ItemArray: srcConfig) ) {
                    Text(MenuArray[5].name).leftAligned()
                }
                NavigationLink(destination: C07about(APP_Version: strVersion, bookTitle: strAbout) ) {
                    Text(MenuArray[6].name).leftAligned()
                }
                
            }
            .onAppear(){
                print("C01mainMenu: onAppear")
                strToday = CA.get_Today(offset: int_date)
                OneDate_Array = CA.getOneDay(strOneDay: strToday)
                
                let srcMenuDic:NSDictionary = initData.getPlistDict(fileName: "c01_data", subName: "plist")
                let srcMenu:NSArray = srcMenuDic.object(forKey: "menu") as! NSArray
                MenuArray = []
                for index in 0...srcMenu.count - 1 {
                    MenuArray.append(CellItem(id: index, name: srcMenu.object(at: index) as! String, push: ""))
                }
                
                let srcConfigArray:NSArray = srcMenuDic.object(forKey: "config") as! NSArray
                
                srcConfig[0] = "\(srcConfigArray.object(at: 0))"
                srcConfig[1] = "\(srcConfigArray.object(at: 1))"
                srcConfig[2] = "\(srcConfigArray.object(at: 2))"
                
                let strVersionArray:NSArray = srcMenuDic.object(forKey: "version") as! NSArray
                strVersion = "\(strVersionArray.object(at: 0))"
                
                let strBookmarkArray:NSArray = srcMenuDic.object(forKey: "bookmark") as! NSArray
                strNoRecord = "\(strBookmarkArray.object(at: 0))"

                let strPlaySpeedArray:NSArray = srcMenuDic.object(forKey: "playAudio") as! NSArray
                strPlaySpeed = "\(strPlaySpeedArray.object(at: 0))"
                
                
                OLD_Books   = MenuArray[1].name
                NEW_Books   = MenuArray[2].name
                strTaiyu    = MenuArray[3].name
                strBookMark = MenuArray[4].name
                strConfig   = MenuArray[5].name
                strAbout    = MenuArray[6].name
                
            }
            .onDisappear(){
               // int_Selected = 0
                print("C01mainMenu: onDisappear")
            }

        }.navigationBarTitle(strToday)
    }
}

// SwiftUI text-alignment
// https://stackoverflow.com/questions/56443535/swiftui-text-alignment

struct LeftAligned: ViewModifier {
    func body(content: Content) -> some View {
        HStack {
            content
            Spacer()
        }
    }
}


extension View {
    func leftAligned() -> some View {
        return self.modifier(LeftAligned())
    }
}

struct C01mainStart_Previews: PreviewProvider {
    static var previews: some View {
        C01mainStart()
    }
}
