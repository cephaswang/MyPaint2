package org.shar35.wear.demowatch;

import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.dd.plist.NSArray;
import com.dd.plist.NSDictionary;
import com.dd.plist.PropertyListParser;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;



public class C03oneBookSet extends AppCompatActivity {

    // 舊約新約各書
    NSDictionary b2ndDict = null;
    static NSArrayAdapter adapter;
    static NSArrayIndexAdapter index_adater;
    ListView listView_Books,listView_Index;
    LinearLayout indexLayout;
    NSArray indexInfo;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c03one_book_set);

        Intent intent = getIntent();
        String BookName = intent.getStringExtra("BookName");
        String plistfile = intent.getStringExtra("plistfile");
        setTitle(BookName);

      //  String bookList = "tra_book_01.plist";

        listView_Books = findViewById(R.id.BookList);
        listView_Index = findViewById(R.id.indexList);
        indexLayout = findViewById(R.id.indexLayout);

        System.out.println("C03oneBookSet");

        NSArray rootArray = null;

        // 讀取菜單文檔
        try {
            AssetManager am = getAssets();
            String audioPLIST = null;
            if (Locale.getDefault().equals (Locale.SIMPLIFIED_CHINESE)){
                audioPLIST = plistfile;
            } else {
                audioPLIST = plistfile;
            }
            InputStream is = am.open(audioPLIST);
            // 全部內容
            rootArray = (NSArray) PropertyListParser.parse(is);
        } catch(Exception ex) {
            ex.printStackTrace();
            Toast.makeText(getApplicationContext(), "讀取菜單文檔 失敗" , Toast.LENGTH_LONG).show();
        }

        // 要播放的陣列
        final NSArray PlayList = new NSArray(rootArray.count());
        for ( int Ux = 0 ; Ux < rootArray.count() ; Ux++ ){
            NSArray oneChapArray = (NSArray)rootArray.objectAtIndex(Ux);
            NSArray oneChap = new NSArray(2);
            oneChap.setValue(0, oneChapArray.objectAtIndex(0).toString().substring(4) );
            oneChap.setValue(1, oneChapArray.objectAtIndex(1).toString().substring(4) );
            PlayList.setValue(Ux, oneChap);
        }
        System.out.println(PlayList.toXMLPropertyList().toString());

        File path = this.getFilesDir();
        File file = new File(path, "play.plist");
        FileOutputStream stream = null;
        try {
            stream = new FileOutputStream(file);
            stream.write( PlayList.toXMLPropertyList().getBytes() );
            stream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }


        adapter = new NSArrayAdapter(this , rootArray);

        listView_Books.setAdapter(adapter);
        listView_Books.setOnItemClickListener(
                (adapterView, view, i, l) -> {
                    TextView plistfileU = view.findViewById(R.id.plistfile);
                    System.out.println(plistfileU.getText().toString());
                }
        );


        index_adater =  new NSArrayIndexAdapter(this , rootArray);
        listView_Index.setAdapter(index_adater);

        if (rootArray.count() < 5) {
            indexLayout.setVisibility(View.GONE);
        }

        listView_Index.setOnItemClickListener(
                (adapterView, view, i, l) -> {
                    TextView plistfileU = view.findViewById(R.id.plistfile);
                    System.out.println(plistfileU.getText().toString());
                    int Pos = Integer.valueOf(plistfileU.getText().toString());
                    listView_Books.setSelection(Pos - 1);
                }
        );

    }

    public static class ViewHolder {
        public TextView BookName;
        public TextView plistfile;
    }

    // https://stackoverflow.com/questions/9440138/how-to-convert-jsonarray-to-listview
    public class NSArrayAdapter  extends BaseAdapter  {

        NSArray data;
        Context context;
        String [] keyArray;

        public NSArrayAdapter(Context context, NSArray data) {
            super();
            this.context=context;
            this.data = data;
         //   keyArray = data.allKeys();
         //   Arrays.sort(keyArray);
        }

        @Override
        public int getCount() {
            return data.count();
        }

        @Override
        public Object getItem(int i) {
            return data.objectAtIndex(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup parent) {
            C02bibleMenu.ViewHolder holder  = null;
            if ( convertView == null ) {
                LayoutInflater inflater=getLayoutInflater();
                convertView = inflater.inflate( R.layout.rowbookname, parent , false);
                holder = new C02bibleMenu.ViewHolder();
                holder.BookName   =(TextView)convertView.findViewById( R.id.BookName);
                holder.plistfile   =(TextView)convertView.findViewById( R.id.plistfile);
                convertView.setTag(holder);
            } else {
                holder = (C02bibleMenu.ViewHolder)convertView.getTag();
            }
            NSArray oneBook = (NSArray)data.objectAtIndex(i);
            holder.BookName.setText( oneBook.objectAtIndex(0).toString().substring(4)  );
            holder.plistfile.setText( oneBook.objectAtIndex(1).toString() );
            return convertView;
        }

    }

    public class NSArrayIndexAdapter  extends BaseAdapter  {

        NSArray data;
        Context context;
        // String [] keyArray;

        public NSArrayIndexAdapter(Context context, NSArray data) {
            super();
            this.context=context;
            this.data = data;
            //   keyArray = data.allKeys();
            //   Arrays.sort(keyArray);
        }

        @Override
        public int getCount() {
            return (int)( data.count() / 5 + 1);
        }

        @Override
        public Object getItem(int i) {
            return data.objectAtIndex(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint("Range")
        @Override
        public View getView(int i, View convertView, ViewGroup parent) {
            C02bibleMenu.ViewHolder holder  = null;
            if ( convertView == null ) {
                LayoutInflater inflater=getLayoutInflater();
                convertView = inflater.inflate( R.layout.rowbookname, parent , false);
                holder = new C02bibleMenu.ViewHolder();
                holder.BookName   =(TextView)convertView.findViewById( R.id.BookName);
                holder.plistfile   =(TextView)convertView.findViewById( R.id.plistfile);
                convertView.setTag(holder);
            } else {
                holder = (C02bibleMenu.ViewHolder)convertView.getTag();
            }

            int Bx = i* 5;
            if (Bx == 0){
                Bx = 1;
            }

            holder.BookName.setText( String.valueOf(Bx) );
            holder.plistfile.setText( String.valueOf(Bx) );
            holder.BookName.setTextColor(Color.BLACK);
            holder.BookName.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
            holder.BookName.setTextSize(16);
            return convertView;
        }

    }

}