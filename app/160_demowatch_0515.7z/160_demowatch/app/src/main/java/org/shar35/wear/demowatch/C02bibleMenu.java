package org.shar35.wear.demowatch;



import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.Intent;
import android.content.res.AssetManager;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.dd.plist.NSArray;
import com.dd.plist.NSDictionary;
import com.dd.plist.PropertyListParser;
import java.io.InputStream;
import java.util.Arrays;
import java.util.Locale;




public class C02bibleMenu extends AppCompatActivity {

    // 舊約新約各書
    NSDictionary b2ndDict = null;
    static NSDictionaryAdapter adapter;
    static NSDictionaryIndexAdapter index_adater;
    ListView listView_Books, listView_Index;
    String idBook = "";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c02biblemenu);

        Intent intent = getIntent();
        idBook = intent.getStringExtra("id");
        String title = intent.getStringExtra("title");
        setTitle(title);

        listView_Books = findViewById(R.id.BookList);
        listView_Index = findViewById(R.id.indexList);

        System.out.println("C02bibleMenu");

        NSDictionary rootDict = null;

        // 讀取菜單文檔
        try {
            AssetManager am = getAssets();
            String audioPLIST = null;
            if (Locale.getDefault().equals (Locale.SIMPLIFIED_CHINESE)){
                audioPLIST = "tra_books_66.plist";
            } else {
                audioPLIST = "tra_books_66.plist";
            }
            InputStream is = am.open(audioPLIST);
            // 全部內容
            rootDict = (NSDictionary) PropertyListParser.parse(is);
        } catch(Exception ex) {
            ex.printStackTrace();
            Toast.makeText(getApplicationContext(), "讀取菜單文檔 失敗" , Toast.LENGTH_LONG).show();
        }

        String [] names1ST  = rootDict.allKeys();
        Arrays.sort(names1ST);

        for ( int Ix = 0; Ix < names1ST.length; Ix++ ){
            if (Ix != Integer.valueOf(idBook) ){
                continue;
            }
            b2ndDict = (NSDictionary) rootDict.objectForKey(names1ST[Ix]);
        }

        adapter = new NSDictionaryAdapter(this , b2ndDict);

        listView_Books.setAdapter(adapter);
        listView_Books.setOnItemClickListener(
                (adapterView, view, i, l) -> {
                    TextView plistfile = view.findViewById(R.id.plistfile);
                    TextView BookName = view.findViewById(R.id.BookName);
                    System.out.println(plistfile.getText().toString());

                    Intent intentU = new Intent();
                    intentU.setClass( C02bibleMenu.this,C03oneBookSet.class);
                    intentU.putExtra("BookName",BookName.getText().toString());
                    intentU.putExtra("plistfile",plistfile.getText().toString());
                    startActivity(intentU);
                }
        );

        index_adater =  new NSDictionaryIndexAdapter(this , b2ndDict);
        listView_Index.setAdapter(index_adater);

        listView_Index.setOnItemClickListener(
                (adapterView, view, i, l) -> {
                    TextView plistfileU = view.findViewById(R.id.plistfile);
                    System.out.println(plistfileU.getText().toString());
                    int Pos = Integer.valueOf(plistfileU.getText().toString());
                    listView_Books.setSelection(Pos - 1);
                }
        );

    }



    public static class ViewHolder {
        public TextView BookName;
        public TextView plistfile;
    }

    // https://stackoverflow.com/questions/9440138/how-to-convert-jsonarray-to-listview
    public class NSDictionaryAdapter  extends BaseAdapter {

        NSDictionary data;
        Context      context;
        String [] keyArray;

        public NSDictionaryAdapter(Context context, NSDictionary data) {
            super();
            this.context=context;
            this.data = data;
            keyArray = data.allKeys();
            Arrays.sort(keyArray);
        }

        @Override
        public int getCount() {
            return keyArray.length;
        }

        @Override
        public Object getItem(int i) {
            return data.objectForKey(keyArray[i]);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup parent) {
            ViewHolder holder  = null;
            if ( convertView == null ) {
                LayoutInflater inflater=getLayoutInflater();
                convertView = inflater.inflate( R.layout.rowbookname, parent , false);
                holder = new ViewHolder();
                holder.BookName   =(TextView)convertView.findViewById( R.id.BookName);
                holder.plistfile   =(TextView)convertView.findViewById( R.id.plistfile);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder)convertView.getTag();
            }
            NSArray oneBook = (NSArray)data.objectForKey(keyArray[i]);
            holder.BookName.setText( keyArray[i].substring(1) );
            holder.plistfile.setText( oneBook.objectAtIndex(1).toString() );
            return convertView;
        }

    }

    public class NSDictionaryIndexAdapter  extends BaseAdapter  {

        NSDictionary data;
        Context context;
        String [] keyArray;

        public NSDictionaryIndexAdapter(Context context, NSDictionary data) {
            super();
            this.context=context;
            this.data = data;
            keyArray = data.allKeys();
            Arrays.sort(keyArray);
        }

        @Override
        public int getCount() {
            return (int)( keyArray.length / 5 + 1);
        }

        @Override
        public Object getItem(int i) {
            return keyArray[i];
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint("Range")
        @Override
        public View getView(int i, View convertView, ViewGroup parent) {
            C02bibleMenu.ViewHolder holder  = null;
            if ( convertView == null ) {
                LayoutInflater inflater=getLayoutInflater();
                convertView = inflater.inflate( R.layout.rowbookname, parent , false);
                holder = new C02bibleMenu.ViewHolder();
                holder.BookName   =(TextView)convertView.findViewById( R.id.BookName);
                holder.plistfile   =(TextView)convertView.findViewById( R.id.plistfile);
                convertView.setTag(holder);
            } else {
                holder = (C02bibleMenu.ViewHolder)convertView.getTag();
            }

            int Cx = Integer.valueOf(C02bibleMenu.this.idBook);

            int Bx = i* 5;
            if (Bx == 0 ){
                Bx = 1;
            }

            if (Cx == 1 && Bx > 1){
                holder.plistfile.setText( String.valueOf(Bx+1) );
            } else {
                holder.plistfile.setText( String.valueOf(Bx) );
            }

            if (Cx == 1 ){
                if (Bx < 2) {
                    Bx = Bx + 39;
                } else {
                    Bx = Bx + 39 + 1;
                }
            }

            holder.BookName.setText( String.valueOf(Bx) );
            holder.BookName.setTextColor(Color.BLACK);
            holder.BookName.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
            holder.BookName.setTextSize(16);
            return convertView;
        }

    }


}