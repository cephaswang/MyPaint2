package org.shar35.wear.demowatch;

import androidx.appcompat.app.AppCompatActivity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Binder;
import android.os.Bundle;
import android.os.IBinder;
import android.widget.SeekBar;
import android.widget.TextView;

import com.dd.plist.NSArray;

public class b05player extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener {

    // --Seekbar variables --
    private static SeekBar seekBar;
    private static TextView title_txt;
    private Intent seekBar_intent;
    private b05PlayService musicService;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b05player);

        // --Reference seekbar in main.xml
        seekBar = (SeekBar) findViewById( R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(this);

        // 登記進度條廣播
        // --- set up seekbar intent for broadcasting new position to service ---
        seekBar_intent = new Intent(".sendseekbar");

        // 標題文字
        title_txt = (TextView)findViewById( R.id.title_txt);

        // 更新服務 Fix Service 2020 01 28
        bindServiceConnection();

        regSYNC();
    }

    //  回调onServiceConnected 函数，通过IBinder 获取 Service对象，实现Activity与 Service的绑定
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            musicService = ((b05PlayService.MyBinder) (service)).getService();
            // Log.i("musicService", musicService + "");
            // musicTotal.setText(time.format(musicService.mediaPlayer.getDuration()));
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            musicService = null;
        }
    };

    // ===========================================================================
    // 更新服務 Fix Service 2020 01 28
    // https://www.cnblogs.com/yanglh6-jyx/p/Android_Service_MediaPlayer.html
    // https://github.com/yanglh751202951/SYSU_Android6
    //  在Activity中调用 bindService 保持与 Service 的通信
    private void bindServiceConnection() {
        Intent intent = new Intent(b05player.this, b05PlayService.class);
        intent.putExtra("PlayIndexID", String.valueOf(0) );
        startService(intent);
        bindService(intent, serviceConnection, this.BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        unregSYNC();

        final Intent intentSRV = new Intent(b05player.this, b05PlayService.class);
        stopService(intentSRV);
        unbindService(serviceConnection);

    }

    // -- Broadcast Receiver to update position of seekbar from service --
    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateUI(intent);
        }
    };

    // 更新進度條，時間標簽
    private void updateUI(Intent serviceIntent) {

       // boolMusicPlaying = true;
      //  boolPlayIsPause  = false;

        // 媒體總長度
        String mediamax = serviceIntent.getStringExtra("mediamax");
        int seekMax = Integer.parseInt(mediamax);
        seekBar.setMax(seekMax);

        // 目前播放的進度
        int seekProgress =  Integer.parseInt( serviceIntent.getStringExtra("counter"));
        seekBar.setProgress(seekProgress);

        String PlayTITLE = serviceIntent.getStringExtra("PlayTITLE");
        title_txt.setText( PlayTITLE );


        int intPlayIndexID =  Integer.parseInt(serviceIntent.getStringExtra("PlayIndexID"));

        /*
        // 變換到下一個

        if (intPlayIndexID != PlayIndexID){
            PlayIndexID = intPlayIndexID;

            b03player.this.FixIcon ( sp_width , (float)4.5 , R.id.btn_Play , R.mipmap.btn_pause );

            NSArray PItemArray = (NSArray)rootArray.objectAtIndex(PlayIndexID);
            String  sTitleString = PItemArray.objectAtIndex(0).toString().substring(4);

            // 進度標題
            try {
                // 聖經，才顯示
                if (PItemArray.count() ==4){
                    sTitleString = PItemArray.objectAtIndex(4).toString().substring(4);
                    str_daymonth.setText(sTitleString );
                }
            } catch (Exception e) {
                e.printStackTrace();
            }

            // 檢查，是否有對應經文
            this.CheckShowText();

            // 廣告變換
            if (isREMOTE == 1){
                String []names1ST = adverDict.allKeys();
                adverIX = adverIX % names1ST.length;
                //	ChangADV (adverIX);
                adverIX += 1;
            }
        }

        // 調整書簽圖示
        if ( PlayIndexID_PRE != PlayIndexID ){
            if ( is_bookmark(PlayIndexID) > 0 ){
                btn_bookMark.setImageResource( R.mipmap.ic_book_add);
            } else {
                btn_bookMark.setImageResource( R.mipmap.ic_book_out);
            }
            PlayIndexID_PRE = PlayIndexID;
        }

        if (pdBuff != null) {
            pdBuff.dismiss();
            pdBuff= null;
        }


        // 顯示進度時間
        str_timeStart.setText(sectoTimeStr(seekProgress));
        str_timeLeft.setText("-"+sectoTimeStr((int)(seekMax-seekProgress)));
        int_timeLeft = (int)(seekMax-seekProgress);

        // 結束前，啟動檢查，若停止，則回復進度條位置
        if ( int_timeLeft < 1000 ){
            handler.removeCallbacks(checkRepeat);
            handler.postDelayed(checkRepeat, 3000);
        }
        */
    }

    // 取消進度條同步
    private void unregSYNC() {
        unregisterReceiver(broadcastReceiver);
//        unregisterReceiver(broadcastBufferReceiver);
    }
    // 登記進度條同步
    private void regSYNC() {
        registerReceiver(broadcastReceiver, new IntentFilter( "seekprogress") );
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        int seekPos = seekBar.getProgress();
        seekBar_intent.putExtra("seekpos", seekPos);
        sendBroadcast(seekBar_intent);

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}