package org.shar35.wear.demowatch;

import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.media.MediaPlayer;
import android.os.Binder;
import android.os.Handler;
import android.os.IBinder;
import androidx.annotation.Nullable;
import com.dd.plist.NSArray;
import com.dd.plist.PropertyListParser;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;


public class b05PlayService extends Service implements MediaPlayer.OnCompletionListener, MediaPlayer.OnPreparedListener,
        MediaPlayer.OnBufferingUpdateListener, MediaPlayer.OnSeekCompleteListener {

    private MediaPlayer mediaPlayer = null;
    public static NSArray rootArray = null;
    private int PlayIndexID = 0;
    Intent seekIntent;
    private final Handler handler = new Handler();


    private final BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        public void onReceive(final Context context, final Intent intent) {
            final int seekPos = intent.getIntExtra("seekpos", 0);
            if (mediaPlayer.isPlaying()) {
                mediaPlayer.seekTo(seekPos);
            }
        }
    };

    // ============================================================
    // 更新服務 Fix Service 2020 01 28
    // https://www.cnblogs.com/yanglh6-jyx/p/Android_Service_MediaPlayer.html
    // https://github.com/yanglh751202951/SYSU_Android6
    //  在Activity中调用 bindService 保持与 Service 的通信
    //  通过 Binder 来保持 Activity 和 Service 的通信

    public MyBinder IBinder = new MyBinder();
    public class MyBinder extends Binder {
        b05PlayService getService() {
            return b05PlayService.this;
        }
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        PlayIndexID = Integer.parseInt(intent.getExtras().getString("PlayIndexID"));
        return null;
    }

    @Override
    public void onCreate() {
        super.onCreate();

        seekIntent = new Intent("seekprogress");

        mediaPlayer = new MediaPlayer();
        mediaPlayer.setOnCompletionListener(this);
        mediaPlayer.setOnPreparedListener(this);
        mediaPlayer.setOnBufferingUpdateListener(this);
        mediaPlayer.setOnSeekCompleteListener(this);
        mediaPlayer.reset();

        // 讀取播放菜單
        try {
            File path = this.getFilesDir();
            File file = new File(path, "play.plist");
            final InputStream inStream = new FileInputStream(file);
            rootArray = (NSArray) PropertyListParser.parse(inStream);

            System.out.println(rootArray.toXMLPropertyList().toString());
        } catch (final IOException e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        } catch (final Exception e) {
            // TODO Auto-generated catch block
            e.printStackTrace();
        }
       // System.out.println(rootArray.toXMLPropertyList().toString());

        PlayAudio_Next (0);



        // ---Set up receiver for seekbar change ---
        registerReceiver(broadcastReceiver, new IntentFilter(".sendseekbar"));

    }

    // 播放下一首
    private void play_Prev () {
        if ( PlayIndexID > 0 ) {
            PlayIndexID -= 1;
        } else {
            PlayIndexID = (rootArray.count() - 1);
        }
        this.PlayAudio_Next(PlayIndexID);
    }

    // 播放下一首
    private void play_Next () {
        if ( PlayIndexID < (rootArray.count() - 1) ) {
            PlayIndexID += 1;
        } else {
            PlayIndexID = 0;
        }
        this.PlayAudio_Next(PlayIndexID);
    }


    // Add for Telephony Manager
    public void pauseMedia() {
        // Log.v(TAG, "Pause Media");
        if (mediaPlayer.isPlaying()) {
            mediaPlayer.pause();
            // intSeekPos = mediaPlayer.getCurrentPosition();
        }
    }

    private void PlayAudio_Next ( final int Ax ){
        System.out.println("PlayAudio_Next:" + Ax);
        PlayIndexID = Ax;
        NSArray playSrc = (NSArray) rootArray.objectAtIndex(PlayIndexID);
        String  SongName = playSrc.objectAtIndex(0).toString();
        String  SongAddr = playSrc.objectAtIndex(1).toString();
        System.out.println(playSrc.toXMLPropertyList().toString());

        if (Ax > 0){
         //   return;
        }

        try {
            mediaPlayer.reset();
            mediaPlayer.setDataSource(SongAddr);
            mediaPlayer.prepare();
        } catch (IOException e) {
        }
        mediaPlayer.start();

      //  mediaPlayer.seekTo( mediaPlayer.getDuration() - 20 );

        setupHandler();

        // mediaPlayer.setDataSource(download_AsyncTask_str);

        //PlayIndexID = PlayIndexID + 1;
        //PlayIndexID = PlayIndexID % rootArray.count();
    }

    // 廣播播放進度
    private void LogMediaPosition() {
        if (mediaPlayer.isPlaying()) {
            Integer mediaPosition = mediaPlayer.getCurrentPosition();

            NSArray playSrc = (NSArray) rootArray.objectAtIndex(PlayIndexID);
            String  SongName = playSrc.objectAtIndex(0).toString();

            seekIntent.putExtra("counter", Integer.toString(mediaPosition));
            seekIntent.putExtra("mediamax", String.valueOf(mediaPlayer.getDuration()));
            seekIntent.putExtra("PlayIndexID", String.valueOf(PlayIndexID));
            seekIntent.putExtra("PlayTITLE", SongName );

            sendBroadcast(seekIntent);
        }
    }

    // ---Send seekbar info to activity----
    private void setupHandler() {
        handler.removeCallbacks(sendUpdatesToUI);
        handler.postDelayed(sendUpdatesToUI, 300); // 1 second
    }

    private final Runnable sendUpdatesToUI = new Runnable() {
        public void run() {
            // // Log.d(TAG, "entered sendUpdatesToUI");
            LogMediaPosition();
          //  getConfig();
            handler.postDelayed(this, 300); // 2 seconds
        }
    };


    @Override
    public void onDestroy() {

        handler.removeCallbacks(sendUpdatesToUI);

        if ( mediaPlayer != null ){
            mediaPlayer.release();
        }

        // 取消廣播接收
     //   unregisterReceiver(UserControlReceiver);
        unregisterReceiver(broadcastReceiver);

        super.onDestroy();
    }


    // 播放結束事件s
    @Override
    public void onCompletion(MediaPlayer mediaPlayer) {
        NSArray playSrc = (NSArray) rootArray.objectAtIndex(PlayIndexID);
        if ( PlayIndexID < playSrc.count() ) {
            this.play_Next();
        }
    }

    @Override
    public void onBufferingUpdate(MediaPlayer mediaPlayer, int i) {

    }

    // 預備完成，開始播放
    @Override
    public void onPrepared(MediaPlayer mediaPlayer) {

    }

    @Override
    public void onSeekComplete(MediaPlayer mediaPlayer) {

    }



}
