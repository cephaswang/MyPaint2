package org.shar35.wear.demowatch;

import android.app.Service;
import android.content.Intent;
import android.os.IBinder;

public class b02DownService extends Service {

    private static String  AudioServer = DCSTools.AudioServer;

    public b02DownService() {
    }

    @Override
    public IBinder onBind(Intent intent) {
        // TODO: Return the communication channel to the service.
        throw new UnsupportedOperationException("Not yet implemented");
    }
}