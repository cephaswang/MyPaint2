<?php

for ($mx=1; $mx<13; $mx++){
	$ma_path = sprintf("m%03d.json",$mx);
	$handle = @fopen($ma_path, "r");
	$data = "";
	if ($handle) {
		while (($buffer = fgets($handle, 4096)) !== false) {
			$data .= $buffer;
		}
		if (!feof($handle)) {
			echo "Error: unexpected fgets() fail\n";
		}
		fclose($handle);
	}
	//$jsonobj = json_decode($data, true);

	to_day ($mx, $data);
}

function to_day ($month, $jsonobj) {

	$obj = json_decode($jsonobj, true);
	//$month = 6;
	$dir_path = sprintf("m%02d",$month);
	mkdir($dir_path,0777);

	for ( $Ix = 1; $Ix<= sizeof($obj); $Ix++){
		$file_path = sprintf($dir_path."/d%02d_%02d.json", $month, $Ix);
		$fp = fopen($file_path, 'w');
		fwrite($fp, json_encode( $obj[$Ix]) );
		fclose($fp);
	}
}