import java.util.function.Function;
import java.util.ArrayList;
import java.util.*;
import java.util.function.UnaryOperator;

public class Myclass  {


    public static void main(String[]args){

        List<String>dates = new ArrayList<String>();
        //Function<String,String>replaceslashes = dates -> dates.replace("-","/");
        UnaryOperator<String>replaceslashes = date -> date.replace("-","/");
        //Map<String,String>replaceslashes = dates.replace("-","/");
        dates.replaceAll(replaceslashes);

    }
}