interface Foo{
    int x = 10;
}


public class C8 {
    public static void main(String[]args){
        Foo.x=20;
        System.out.println(Foo.x);
    }
}

// error
