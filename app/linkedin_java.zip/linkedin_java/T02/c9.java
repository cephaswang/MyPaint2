import java.util.function.Function;

public class C9 {

    public static void main(String[]args){
        Function <Integer, String> oddOrEven =  x -> {
            return x % 2==0? "even":"odd";
        };
    }
}

// Function <Integer, String>