interface MyInterface{
    int foo(int x);

    public static void main(String[]args){
    }
}


public class Myclass implements MyInterface{
    //..-

    public static void main(String[]args){
    }

    public int foo(int x){
        return x * 100;
    }
}


