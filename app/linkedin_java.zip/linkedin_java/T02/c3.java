public class Myclass  {

//public enum Direction{
//    North('N'), South('S'), East('E'), West('W');

public enum Direction{
    North, South, East, West;

//  private final String shortCode;
    private String shortCode;

    public String getshortCode(){
        return shortCode;
    }
}

    public static void main(String[]args){
    }
}