public class c5 {


    public static void main(String[]args){
        int [] num  = new int[10];
    }
}

// Make age static