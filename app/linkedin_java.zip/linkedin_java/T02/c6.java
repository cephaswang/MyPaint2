public class Nosey {
    static int age;

    public static void main(String[]args){
        System.out.println("Your age is:" + age);
    }
}

// Make age static