public class C11 {

    public static void main(String[]args){
        int x = 0;
        int y = 2;
        String buy = "bitcoin";
        System.out.println(buy.substring(x,x+1)+buy.substring(y,y+2));
    }

}

// btc