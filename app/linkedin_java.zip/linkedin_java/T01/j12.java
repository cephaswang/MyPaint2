import java.util.*;
import java.util.function.Function;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


class j12
{
	public static void main(String[] args) {
		Map< String, Integer > forestSpecies = new HashMap<>();
		forestSpecies.put ( "a",30);
		forestSpecies.put ( "b",30);
		forestSpecies.put ( "c",30);
		forestSpecies.put ( "d",30);
		int forestCount = forestSpecies.size();
		System.out.println(forestCount);
	}
}

