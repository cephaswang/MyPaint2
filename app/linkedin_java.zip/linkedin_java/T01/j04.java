import java.util.*;
import java.util.function.Function;


class j04
{
    List<String> theList = Arrays.asList("humble","element","dna");


	public static void main(String[] args) {
		new j04().a1();
		new j04().a2();
		new j04().a3();
	}

    public void a1 () {

        for ( int i = 0; i < theList.size(); i++ ){
            System.out.println(theList.get(i));
        }
    };

    public void a2 () {
        theList.forEach(System.out::println);
    }


    public void a3 () {
        for ( Object object: theList){
            System.out.println(object);
        }
    }

    public void a4 () {
		/*
        Iterator it =  theList.iterator();
		//###########################
		// 只有一個參數，是錯誤的。
        for ( it.hasNext()){
            System.out.println(it.next());
        }
		*/
    }

}
/*

。

*/