import java.util.*;
import java.util.function.Function;
import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;


class j09
{

	public static void main(String[] args) {
		double pickle = 2;
		int jav = pickle;
	}


/*
The compiler is complaining about this assignment of the
variable pickle to the variable jar.
How would you fix this ?

编译器抱怨这个分配
变量 pickle 到变量 jar。
你会如何解决这个问题？

use the new keyword to create a new integer from pickle before assigning it to jar
make pickle into a double by adding + ".0"
use the method toInt() to convert pickle fefore assigning it to jar.
cast pickle to an int before assigning it to jar

在将其分配给 jar 之前，使用 new 关键字从 pickle 创建一个新整数
通过添加 + ".0" 使泡菜变成双精度
使用 toInt() 方法转换泡菜，然后将其分配给 jar。
在将 pickle 分配给 jar 之前将其转换为 int
 */


}

