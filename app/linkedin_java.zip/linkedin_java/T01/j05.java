import java.util.*;
import java.util.function.Function;


class j05
{
	String berry = "blue";
    

	public static void main(String[] args) {
        new j05().juicy("straw");
    }

	void juicy(String berry){

		this.berry = "rasp";
		System.out.println( berry + "berry");
	}


}
/*

C:\Users\1003\Documents\java>java j05.java
strawberry

*/