//
//  C04bookMark.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/17.
//

import SwiftUI

struct C06config: View {
    
    @Environment(\.presentationMode) var mode: Binding<PresentationMode>
    
    @StateObject var downloadModel = DownloadTaskModel()
    
    @State var int_date:Int = 0
    @State var OneDate_Array:[CellItem] = []
    @State var Download_Array:[CellItem] = []
    @State var CA:C01Menu_info = C01Menu_info()
    @State var strToday:String = ""
    @State var playSpeed:Float = 1
    @State var bookTitle:String = ""
    @State var PlistName:String = ""
    @State var MenuArray:[CellItem] = []

    @State var isTapped = false
    @State var int_Selected:Int = 0
    var initData  = CommClass()
    @State var checkTimer:Timer?
    @State var download_index:Int = 0
    

    var body: some View {
        ScrollView {
        
        
        VStack{
            Text(String(format: "Speed: %.1f", Double(playSpeed)))
            HStack {
                Button(
                    action: {
                        if (playSpeed > 0.1){
                            playSpeed -= 0.1
                            initData.setSpeed(speed: String(format: "%.1f", Double(playSpeed)))
                        }
                        
                },
                    label: {
                        Image(systemName: "minus.circle.fill")
                            .resizable()
                            .frame(width: 30.0, height: 30.0,alignment: .center)
                }) .frame(width: 50.0, height: 50.0,alignment: .center)
                
                Button(
                    action: {
                        playSpeed = 1
                        initData.setSpeed(speed: String(format: "%.1f", Double(playSpeed)))
                },
                    label: {
                        Image(systemName: "repeat.circle.fill")
                            .resizable()
                            .frame(width: 30.0, height: 30.0,alignment: .center)
                        
                }).frame(width: 50.0, height: 50.0,alignment: .center)
                
                Button(
                    action: {
                        if (playSpeed < 2){
                            playSpeed += 0.1
                            initData.setSpeed(speed: String(format: "%.1f", Double(playSpeed)))
                        }
                        
                },
                    label: {
                        Image(systemName: "plus.circle.fill")
                            .resizable()
                            .frame(width: 30.0, height: 30.0,alignment: .center)
                        
                }).frame(width: 50.0, height: 50.0,alignment: .center)
                // Text(strToday)
                
            }.padding(.top,5)
            
            
            Button("下載60天檔案") {
                self.checkTimer?.invalidate()
                Download_Array = []
                var Cx:Int = 0
                for Px in 1...60 {
                    strToday = CA.get_Today(offset: Px)
                    OneDate_Array = CA.getOneDay(strOneDay: strToday)
                    for Ux in 0...OneDate_Array.count - 1{
                        var C1:CellItem = OneDate_Array[Ux]
                        Cx += 1
                        C1.id = Cx
                        Download_Array.append(C1)
                    }
                }
                print(Download_Array)
                download_index = 0
                checkTimer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { (_) in
                    downLoadLoop()
                }
            }
            
            Button("下載台語詩歌") {
                self.checkTimer?.invalidate()
                Download_Array = []
                let ArraySRC:NSArray = initData.getTaiSong()
                var OneBook:NSArray
                var BookName:NSString
                var linkName:NSString

                for Px:Int in 0 ... ArraySRC.count - 1 {
                    OneBook  = ArraySRC.object(at: Px) as! NSArray
                    BookName = OneBook.object(at: 0) as! NSString
                    linkName = OneBook.object(at: 1) as! NSString
                    Download_Array.append(
                        CellItem(id: Px,
                                 name: "\(Px+1) \(String(BookName))" ,
                                 push: String(linkName))
                    )
                }
                print(Download_Array)
                download_index = 0
                checkTimer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { (_) in
                    downLoadLoop()
                }
            }.overlay(
                ZStack{
                    if downloadModel.showDownloadProgress{
                        DownloadProgressView(progress: $downloadModel.downloadProgress)
                            .environmentObject(downloadModel)
                    }
                }
            )
            
            Button("下載全部檔案") {
                self.checkTimer?.invalidate()
                Download_Array = []
                var Cx:Int = 0
                for Px in 1...367 {
                    strToday = CA.get_Today(offset: Px)
                    OneDate_Array = CA.getOneDay(strOneDay: strToday)
                    for Ux in 0...OneDate_Array.count - 1{
                        var C1:CellItem = OneDate_Array[Ux]
                        Cx += 1
                        C1.id = Cx
                        Download_Array.append(C1)
                    }
                }
                print(Download_Array)
                download_index = 0
                checkTimer = Timer.scheduledTimer(withTimeInterval: 0.2, repeats: true) { (_) in
                    downLoadLoop()
                }
                
            }.onAppear(){
                playSpeed = initData.getSpeed()
            }
            .onDisappear(){
                self.checkTimer?.invalidate()
            }
            
        }.padding(.top,5)
    }
      .navigationBarTitle("設定").font(.caption)
    }

    func downLoadLoop(){
        if ( downloadModel.showDownloadProgress ){
            return
        }
        print("download_index:\(download_index)")
        print("Download_Array.count:\(Download_Array.count)")
        let G1:CellItem = Download_Array[download_index]
        if ( checkIsDownloaded(urlString: G1.push) == false ){
            downloadRun(urlString: G1.push)
        } else {
            if ( download_index < Download_Array.count - 1){
                download_index += 1
            } else {
                checkTimer?.invalidate()
                self.mode.wrappedValue.dismiss()
            }
        }
    }
    
    func downloadRun(urlString:String){
        downloadModel.startDownload(urlString:urlString ,downOnly: false)
    }
    
    func checkIsDownloaded(urlString: String) -> Bool{
        let nameArray:[String] = urlString.components(separatedBy: "/")
        let strStoreName = "\(nameArray[nameArray.count-2])/\(nameArray[nameArray.count-1])"

        let DocumentDirURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = DocumentDirURL.appendingPathComponent(strStoreName)
        if FileManager.default.fileExists(atPath: fileURL.path){
            print(fileURL.path)
            return true;
        }

        return false
    }
}

struct C06config_Previews: PreviewProvider {
    static var previews: some View {
        C06config()
    }
}
