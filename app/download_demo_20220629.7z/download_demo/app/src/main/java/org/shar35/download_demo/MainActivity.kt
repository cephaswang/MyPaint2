package org.shar35.download_demo

import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.IntentFilter
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.ProgressBar
import android.widget.TextView
import androidx.appcompat.app.AlertDialog
import java.io.File


class MainActivity : AppCompatActivity() {

    val dn: download_thread = download_thread()
    lateinit var button: Button
    lateinit var button_delete: Button

    lateinit var stateProgressBar : ProgressBar
    lateinit var fileTextView : TextView
    lateinit var alertDialog: AlertDialog
    var dialogIsShow:Boolean = false

    // Progress dialogue and broadcast receiver variables
    var mBufferBroadcastIsRegistered = false
    val b01about_boadcast: String = "b01about_boadcast"

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        button = findViewById(R.id.button)
        button_delete = findViewById(R.id.button_delete)

        button.setOnClickListener {
            dialog_status()
            dn.execute(
                this,
                "http://bible.cephas.tw/bible_cantonese/004/4_001.mp3",
                this.filesDir.path,
                "abc/dir/aux",
                b01about_boadcast
            );
/*
"audio/004",
"",
"abc/dir/aux",
*/

        }

        button_delete.setOnClickListener {
            var exfile = File(this.filesDir.path,"/abc/dir/aux/4_001.mp3")
            if (exfile.exists()) {
                exfile.delete()
                println("exfile.delete()")
            }
        }

        // Register broadcast receiver
        if (!mBufferBroadcastIsRegistered) {
            registerReceiver(
                broadcastBufferReceiver, IntentFilter(
                    b01about_boadcast
                )
            )
            mBufferBroadcastIsRegistered = true
        }

    }

    override fun onDestroy() {
        super.onDestroy()

        // Unregister broadcast receiver
        if (mBufferBroadcastIsRegistered) {
            unregisterReceiver(broadcastBufferReceiver)
            mBufferBroadcastIsRegistered = false
        }
    }

    // Set up broadcast receiver
    private val broadcastBufferReceiver: BroadcastReceiver = object : BroadcastReceiver() {
        override fun onReceive(context: Context, bufferIntent: Intent) {
            if ( dialogIsShow == false ){
                dialog_status()
            }

            val bufferValue = bufferIntent.getStringExtra("buffering")
            // 傳入進度睥值
            val StatusValue = bufferIntent.getStringExtra("StatusValue")
            var Mp3SaveName = bufferIntent.getStringExtra("Mp3SaveName")
            // textView.setText(bufferValue + "," + Mp3SaveName + "," + StatusValue)

            if (StatusValue != null) {
                if (StatusValue.toInt() < 100) {
                    // progressBar.progress = StatusValue.toInt()
                    stateProgressBar.progress = StatusValue.toInt()
                    fileTextView.setText(bufferValue + "," + Mp3SaveName + "," + StatusValue)
                } else {
                    dismiss_dialog()
                }
            }
        }
    }
    fun dialog_status() {
        dialogIsShow = true
        val builder = AlertDialog.Builder(this@MainActivity)
        // val layoutInflater = layoutInflater
        // https://stackoverflow.com/questions/35808145/how-do-i-call-findviewbyid-on-an-alertdialog-builder
        val view: View = getLayoutInflater().inflate(R.layout.dialog_status, null)
        stateProgressBar = view.findViewById<ProgressBar>(R.id.progressBar)
        fileTextView = view.findViewById<TextView>(R.id.textView)
        builder.setView(view)
        alertDialog = builder.show()
    }

    fun dismiss_dialog(){
        dialogIsShow = false
        alertDialog.dismiss()
    }


}