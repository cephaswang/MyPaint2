﻿using System;
using System.IO.Ports;
using System.Windows.Forms;
using System.Text;

namespace nfsBreaker
{
    public partial class Form1 : Form
    {
       // SerialPort SerialPort1 = new SerialPort();
        static string recevice_string;
        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            button_scan_Click(sender, e);

            // How to get the correct value from SerialPort.BytesToRead?
            // SerialPort.DataReceived Event
            // https://docs.microsoft.com/en-us/dotnet/api/system.io.ports.serialport.datareceived?redirectedfrom=MSDN&view=dotnet-plat-ext-5.0
           // serialPort1.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            comboBox_cmd.Items.Clear();
            string[] command_str = new string[] { "1-读RS485断路器 Read from RS485 ", "2-写RS485断路器 Write to RS485", "7F-设置断路器地址及型号 Set address and model" };
            comboBox_cmd.Items.AddRange(command_str);
            comboBox_cmd.SelectedIndex = 0;

            comboBox_option.Items.Clear();
            string[] command_action = new string[] { "0-分闸 open", "1-合闸 closed" };
            comboBox_option.Items.AddRange(command_action);
            comboBox_option.SelectedIndex = 0;
        }


        private void button_open_Click(object sender, EventArgs e)
        {
            button_open.Enabled = false;
            button_close.Enabled = true;

            // 偶數 even
            // 奇數 odd
            serialPort1.BaudRate = 9600;
            serialPort1.Parity = Parity.None;
            serialPort1.StopBits = StopBits.One;
            serialPort1.DataBits = 8;
            serialPort1.Handshake = Handshake.None;
            serialPort1.RtsEnable = true;

            try
            {
                serialPort1.PortName = comboBox_port.Text;
                serialPort1.Open();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button_close_Click(object sender, EventArgs e)
        {
            button_open.Enabled = true;
            button_close.Enabled = false;

            try
            {
                serialPort1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
        }

        private void button_write_Click(object sender, EventArgs e)
        {
            recevice_string = null;
            richTextBox_read.Text = "";
            richTextBox_write.Text = "";

            int address_int = Convert.ToInt32(textBox_address.Text, 16);
            byte address_byte = Convert.ToByte(address_int);
            byte Control_byte = 0x0;
            byte Data_length = 0x0;
            byte[] Data_content = { 0 };
            byte[] crc_byte = { 0 };

            byte[] send_byte = { 0, 0, 0, 0, 0, 0, 0, 0 };

            // 1-读RS485断路器 Read from RS485
            if (comboBox_cmd.SelectedIndex == 0)
            {
                // comboBox_option.Enabled = false;

                Control_byte = 0x1;
                Data_length = 0x1;
                Data_content[0] = 0x10;
                send_byte = new byte[] { 0x68, address_byte, Control_byte, Data_length, Data_content[0], 0x0 };
            }

            // 2-写RS485断路器 Write to RS485
            if (comboBox_cmd.SelectedIndex == 1)
            {
                // comboBox_option.Enabled = true;

                // 68 01 02 03 20 01 01 90
                Control_byte = 0x2;
                Data_length = 0x3;
                Data_content = new byte[] { 0x20, address_byte, (byte)comboBox_option.SelectedIndex };
                send_byte = new byte[] { 0x68, address_byte, Control_byte, Data_length, Data_content[0], Data_content[1], Data_content[2], 0x0 };
            }

            // 7F-设置断路器地址及型号 Set address and model
            if (comboBox_cmd.SelectedIndex == 2)
            {
                // comboBox_option.Enabled = false;
                // 68 01 02 03 20 01 01 90
                //address_byte = 0xff;
                Control_byte = 0x7f;
                Data_length = 0x3;
                Data_content = new byte[] { Control_byte, address_byte, 0x00 };
                send_byte = new byte[] { 0x68, 0xff, Control_byte, Data_length, Data_content[0], Data_content[1], Data_content[2], 0x0 };
            }


            GetCRC(send_byte, ref crc_byte);
            send_byte[send_byte.Length - 1] = crc_byte[0];


            if (serialPort1.IsOpen)
            {
                serialPort1.Write(send_byte, 0, send_byte.Length);
            }

            richTextBox_write.Text = BitConverter.ToString(send_byte);

            // 收到的報文
            System.Threading.Thread.Sleep(300);

            richTextBox_read.Text = recevice_string;

        }


        // Visual C# 2010 開發 Modbus CRC 演算
        // http://ezworker2010.blogspot.com/2011/10/visual-c-2010-modbus-crc.html
        private void GetCRC(byte[] message, ref byte[] CRC) // message : Modbus指令 ； CRC : 2 Byte Checksum
        {
            /* 0x1,0x2,0x3,0x4
             * 从帧起始符开始到校验码之前的所有字节的数据和，超过0xFF取低8位（1字节）
             * The total of all bytes from the initial frame up to the check code, limit to 8 bits if exceeds 0xFF (1 byte)
             * 4-1 = 3
             * 0,1,2
             */
            int CRCFull = 0;
            for (int i = 0; i < (message.Length - 1); i++)
            {
                CRCFull = CRCFull + Convert.ToInt32(message[i]);
            }

            CRC[0] = (byte)(CRCFull & 0xFF); // CRC low byte 在前
        }

        private void button_read_Click(object sender, EventArgs e)
        {
            // C# String To Byte Array
            // https://www.c-sharpcorner.com/article/c-sharp-string-to-byte-array/

            // byte[] to hex string [duplicate]
            // https://stackoverflow.com/questions/623104/byte-to-hex-string

            string rec_string = "";
            // byte[] bytes;

            if (serialPort1.IsOpen)
            {
                richTextBox_read.Text = "";
                for (int Ux = 0; Ux < 20; Ux++)
                {
                    try
                    {
                        // SerialPort1.ReadBufferSize
                        rec_string = serialPort1.ReadExisting();
                        byte[] bytes = Encoding.ASCII.GetBytes(rec_string);
                        richTextBox_read.Text = richTextBox_read.Text + BitConverter.ToString(bytes);
                        if (bytes.Length > 0)
                        {
                            // Ux = 10000;
                        }
                        System.Threading.Thread.Sleep(200); //Delay 0.2秒
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }


            }



        }

        private void button_scan_Click(object sender, EventArgs e)
        {


            comboBox_port.Items.Clear();
            string[] ports = SerialPort.GetPortNames();
            comboBox_port.Items.AddRange(ports);
            comboBox_port.SelectedIndex = ports.Length - 1;
            button_close.Enabled = false;
        }

        private void comboBox_cmd_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox_cmd.SelectedIndex == 1)
            {
                comboBox_option.Enabled = true;
            }
            else
            {
                comboBox_option.Enabled = false;
            }
        }

        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            byte[] read = new byte[serialPort1.BytesToRead];
            serialPort1.Read(read, 0, serialPort1.BytesToRead);
            recevice_string = BitConverter.ToString(read);
            richTextBox_read.Text = richTextBox_read.Text + recevice_string + "\r\n" ;
        }
    }

}