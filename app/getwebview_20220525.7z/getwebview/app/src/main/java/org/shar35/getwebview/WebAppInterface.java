package org.shar35.getwebview;

import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.os.Environment;
import android.util.Log;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

public class WebAppInterface {
    private Context context;
    private static final String TAG = "WebAppInterface";

    private DBOpenHelper DBhelper = null;
    private SQLiteDatabase db = null;
    private static final int dbVERSION = 1;
    private static final String dbDBNAME = "b02config.db";

    public WebAppInterface(Context context){
        DBhelper = new DBOpenHelper(context, dbDBNAME, null, dbVERSION);
        this.context = context;
    }

    @JavascriptInterface
    public void setHtml(String message, String url) throws IOException {
        db = DBhelper.getWritableDatabase();

        String b02SQL = "select max(`id`) from history";
        int MaxID = 1;
        Cursor cursor =  db.rawQuery(b02SQL,null);
        while (cursor.moveToNext()) {
            MaxID = cursor.getInt(0);
        }

        String fileName = String.format("%06d.html",MaxID);
        File file = new File( context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) , fileName);
        FileOutputStream stream = new FileOutputStream(file);
        try {
            stream.write( message.getBytes() );
        } finally {
            stream.close();
        }

        b02SQL = "INSERT INTO history ( web_address, store_path, is_src) VALUES ( '" + url + "' , '" + String.format("%06d",MaxID) +  "' , '0' )";
        db.execSQL(b02SQL);
        db.close();
        Log.v(TAG,"b02SQL:" + b02SQL);

        Toast.makeText(context,"save:"  + file.getAbsolutePath().toString() ,Toast.LENGTH_SHORT).show();
    }

}
