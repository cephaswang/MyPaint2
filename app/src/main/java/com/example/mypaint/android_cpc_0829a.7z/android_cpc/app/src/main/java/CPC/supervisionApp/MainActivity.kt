package CPC.supervisionApp

import android.Manifest
import android.Manifest.permission.MANAGE_MEDIA
import android.annotation.SuppressLint
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Color
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.Message
import android.text.method.TextKeyListener.clear
import android.util.DisplayMetrics
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Button
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import androidx.annotation.RequiresApi
import androidx.appcompat.app.AppCompatActivity
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat


// https://www.ssaurel.com/blog/learn-to-create-a-paint-application-for-android/
// https://www.youtube.com/watch?v=uJGcmGXaQ0o
// Learn to create a Paint Application with Android Studio

//  Swift 4.2 Draw Something with CGContext and Canvas View
//  https://www.youtube.com/watch?v=E2NTCmEsdSE
//  https://www.youtube.com/watch?v=7vDfL0K6Jm8


class MainActivity : AppCompatActivity() {
    private var sb_normal: SeekBar? = null
    private var paintView: PaintView? = null
    var buttonBack: Button? = null
    private var mPaintHandler: PaintHandler? = null
    private var mDrawHandler: DrawHandler? = null
    var bmScreen: Bitmap? = null
    var screen: View? = null
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        paintView = findViewById<View>(R.id.paintView) as PaintView
        val metrics = DisplayMetrics()
        windowManager.defaultDisplay.getMetrics(metrics)
        paintView!!.init(metrics)
        mPaintHandler = PaintHandler()
        mDrawHandler = DrawHandler()
        paintView!!.handler = mPaintHandler
        screen = findViewById(R.id.paintView) as View
        sb_normal = findViewById<View>(R.id.seekBar) as SeekBar
        buttonBack = findViewById<View>(R.id.buttonBack) as Button
        sb_normal!!.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(seekBar: SeekBar, progress: Int, fromUser: Boolean) {
                // txt_cur.setText("当前进度值:" + progress + "  / 100 ");
                paintView!!.setStrokeWidth(progress + 1)
                buttonBack!!.text = (progress + 1).toString()
                mPaintHandler!!.obtainMessage(
                    MESSAGE_FONT_SIZE,
                    progress + 1, 0, ""
                ).sendToTarget()
            }

            override fun onStartTrackingTouch(seekBar: SeekBar) {
                // Toast.makeText(mContext, "触碰SeekBar", Toast.LENGTH_SHORT).show();
            }

            override fun onStopTrackingTouch(seekBar: SeekBar) {
                // Toast.makeText(mContext, "放开SeekBar", Toast.LENGTH_SHORT).show();
                buttonBack!!.text = "Undo"
            }
        })
        askPermissions()
        drawAct()
    }

    fun drawAct() {
        paintView!!.SET_FromRemove(true)
        mDrawHandler!!.obtainMessage(MESSAGE_FONT_SIZE, 20, 0, "").sendToTarget()
        mDrawHandler!!.obtainMessage(MESSAGE_FONT_COLOR, Color.RED, 0, "").sendToTarget()

        /*
        var path = "404.96704,488.96484"
        mDrawHandler!!.obtainMessage(MESSAGE_PATH_START, 0, 0, path).sendToTarget()
        path = "410.46716,510.96484"
        mDrawHandler!!.obtainMessage(MESSAGE_PATH_MOVE, 0, 0, path).sendToTarget()
        path = "310.46716,410.96484"
        mDrawHandler!!.obtainMessage(MESSAGE_PATH_MOVE, 0, 0, path).sendToTarget()
        path = "410.46716,510.96484"
        mDrawHandler!!.obtainMessage(MESSAGE_PATH_ENDS, 0, 0, "").sendToTarget()

        //    mDrawHandler.obtainMessage(MESSAGE_ACTS_CLEAR,0,0,"").sendToTarget();
        //   mDrawHandler.obtainMessage(MESSAGE_ACTS_UNDO,0,0,"").sendToTarget();
        */
    }

    /**
     * 方式1：新建Handler子类（内部类）
     */
    // 步骤1：自定义Handler子类（继承Handler类） & 复写handleMessage（）方法
    inner class PaintHandler : Handler() {
        // 通过复写handlerMessage() 从而确定更新UI的操作
        override fun handleMessage(msg: Message) {
            when (msg.what) {
                MESSAGE_FONT_SIZE -> {
                    val font_size = Integer.valueOf(msg.arg1)
                    Log.d(TAG, "font_size$font_size")
                }
                MESSAGE_FONT_COLOR -> {
                    val font_color = Integer.valueOf(msg.arg1)
                    Log.d(TAG, "font_color$font_color")
                }
                MESSAGE_PATH_START -> Log.d(TAG, "path_Start" + msg.obj)
                MESSAGE_PATH_MOVE -> Log.d(TAG, "path_Move" + msg.obj)
                MESSAGE_PATH_ENDS -> Log.d(TAG, "path_Ends" + msg.obj)
                MESSAGE_ACTS_UNDO -> Log.d(TAG, "acts_undo")
                MESSAGE_ACTS_CLEAR -> Log.d(TAG, "acts_clear")
            }
        }
    }

    // 步骤1：自定义Handler子类（继承Handler类） & 复写handleMessage（）方法
    inner class DrawHandler : Handler() {
        // 通过复写handlerMessage() 从而确定更新UI的操作
        override fun handleMessage(msg: Message) {
            when (msg.what) {
                MESSAGE_FONT_SIZE -> {
                    val font_size = Integer.valueOf(msg.arg1)
                    Log.d(TAG, "font_size$font_size")
                    paintView!!.setStrokeWidth(font_size)
                }
                MESSAGE_FONT_COLOR -> {
                    val font_color = Integer.valueOf(msg.arg1)
                    paintView!!.setStrokeColor(font_color)
                }
                MESSAGE_PATH_START -> {
                    Log.d(TAG, "path_Start" + msg.obj)
                    val pathStr = msg.obj as String
                    val Points = pathStr.split(",").toTypedArray()
                    paintView!!.touchStart(Points[0].toFloat(), Points[1].toFloat())
                }
                MESSAGE_PATH_MOVE -> {
                    Log.d(TAG, "path_Move" + msg.obj)
                    val pathStr = msg.obj as String
                    val Points = pathStr.split(",").toTypedArray()
                    paintView!!.touchMove(Points[0].toFloat(), Points[1].toFloat())
                }
                MESSAGE_PATH_ENDS -> {
                    Log.d(TAG, "path_Ends" + msg.obj)
                    paintView!!.touchUp()
                }
                MESSAGE_ACTS_UNDO -> {
                    Log.d(TAG, "acts_undo")
                    paintView!!.onBack(screen)
                }
                MESSAGE_ACTS_CLEAR -> {
                    Log.d(TAG, "acts_clear")
                    paintView!!.clear()
                }
            }
        }
    }

    /*

————————————————
版权声明：本文为CSDN博主「Carson_Ho」的原创文章，遵循 CC 4.0 BY-SA 版权协议，转载请附上原文出处链接及本声明。
原文链接：https://blog.csdn.net/carson_ho/java/article/details/80305411

*/
    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        val menuInflater = menuInflater
        menuInflater.inflate(R.menu.main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.normal -> {
                paintView!!.normal()
                return true
            }
            R.id.emboss -> {
                paintView!!.emboss()
                return true
            }
            R.id.blur -> {
                paintView!!.blur()
                return true
            }
            R.id.clear -> {
                paintView!!.clear()
                mPaintHandler!!.obtainMessage(MESSAGE_ACTS_CLEAR, 0, 0, "").sendToTarget()
                return true
            }
            R.id.save -> {
                println("save")
                bmScreen = getBitmapFromView(paintView!!.rootView)
                paintView!!.saveImage(this, bmScreen)
                bmScreen = null
                return true
            }
        }
        return super.onOptionsItemSelected(item)
    }

    // view.getDrawingCache() is deprecated in Android API 28
    // https://stackoverflow.com/questions/52642055/view-getdrawingcache-is-deprecated-in-android-api-28
    fun getBitmapFromView(view: View): Bitmap {
        val bitmap = Bitmap.createBitmap(
            view.width, view.height, Bitmap.Config.ARGB_8888
        )
        val canvas = Canvas(bitmap)
        view.draw(canvas)
        return bitmap
    }

    @RequiresApi(Build.VERSION_CODES.S)
    private fun askPermissions() {
        val PERMISSION_S = arrayOf(
            Manifest.permission.MANAGE_MEDIA,
            Manifest.permission.MEDIA_CONTENT_CONTROL,
            Manifest.permission.WRITE_EXTERNAL_STORAGE,
            Manifest.permission.READ_EXTERNAL_STORAGE
        )
        val permissionsRequest: MutableSet<String> = HashSet()
        for (permission in PERMISSION_S) {
            val result = ContextCompat.checkSelfPermission(this, permission)
            if (result != PackageManager.PERMISSION_GRANTED) {
                permissionsRequest.add(permission)
            }
        }
        if (!permissionsRequest.isEmpty()) {
            ActivityCompat.requestPermissions(
                this,
                permissionsRequest.toTypedArray(),
                REQ_PERMISSIONS
            )
        }
        println("permissionsRequest:" + permissionsRequest.size)
    }

    @SuppressLint("Override")
    override fun onRequestPermissionsResult(
        requestCode: Int,
        permissions: Array<String>,
        grantResults: IntArray
    ) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults)
        when (requestCode) {
            REQ_PERMISSIONS -> for (result in grantResults) {
                if (result != PackageManager.PERMISSION_GRANTED) {
                    // String text = getString( R.string.text_ShouldGrant) + " : "+ result ;
                    // Toast.makeText(this, text, Toast.LENGTH_LONG).show();
                    // handler.postDelayed(GotoMenu, 4000);
                    return
                }
            }
        }
    }

    fun onBack(view: View?) {
        mPaintHandler!!.obtainMessage(MESSAGE_ACTS_UNDO, 0, 0, "").sendToTarget()
        paintView!!.onBack(screen)
    }

    fun onColorYellow(view: View?) {
        mPaintHandler!!.obtainMessage(MESSAGE_FONT_COLOR, Color.YELLOW, 0, "").sendToTarget()
        paintView!!.setStrokeColor(Color.YELLOW)
    }

    fun onColorRed(view: View?) {
        mPaintHandler!!.obtainMessage(MESSAGE_FONT_COLOR, Color.RED, 0, "").sendToTarget()
        paintView!!.setStrokeColor(Color.RED)
    }

    fun onColorBlue(view: View?) {
        mPaintHandler!!.obtainMessage(MESSAGE_FONT_COLOR, Color.BLUE, 0, "").sendToTarget()
        paintView!!.setStrokeColor(Color.BLUE)
    }

    fun onColorBlack(view: View?) {
        mPaintHandler!!.obtainMessage(MESSAGE_FONT_COLOR, Color.BLACK, 0, "").sendToTarget()
        paintView!!.setStrokeColor(Color.BLACK)
    }

    companion object {
        // 调试信息
        private const val TAG = "MainActivity"
        private const val REQ_PERMISSIONS = 0

        // Constants that indicate the current connection state
        const val MESSAGE_FONT_SIZE = 1 // we're doing nothing
        const val MESSAGE_FONT_COLOR = 2 // now listening for incoming connections
        const val MESSAGE_PATH_START = 3 // now initiating an outgoing connection
        const val MESSAGE_PATH_MOVE = 4 // now connected to a remote device
        const val MESSAGE_PATH_ENDS = 5 // now connected to a remote device
        const val MESSAGE_ACTS_UNDO = 6 // now connected to a remote device
        const val MESSAGE_ACTS_CLEAR = 7 // now connected to a remote device
    }
}