//
//  TableViewCell.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import SwiftUI

struct TableViewCell: View {
    @State var textLabel:String
    var body: some View {
        Text(textLabel)
            .padding()
            .font(.title)
    }
}

struct TableViewCell_Previews: PreviewProvider {
    static var previews: some View {
        TableViewCell(textLabel:"124")
    }
}
