//
//  ContentView.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//


// https://swiftontap.com/view/onappear(perform:)

import SwiftUI

struct TextArray{
    var id:Int
    @State var name:String
    @State var push:String
}

struct C01mainMenu: View {
    
    // 日期暫存
    @State var int_date = 0
    @State var str_Today : String = ""
    
    @State var MenuArray:[TextArray] =
    [
        TextArray(id:1,name:"今日讀經",push:"C05audioPlayer"),
        TextArray(id:2,name:"舊約聖經",push:"C05audioPlayer"),
        TextArray(id:3,name:"新約聖經",push:"C05audioPlayer"),
        TextArray(id:4,name:"台語詩歌",push:"C05audioPlayer"),
        TextArray(id:5,name:"我的最愛",push:"C05audioPlayer"),
        TextArray(id:6,name:"讀經進度",push:"C05audioPlayer")
    ]

    
    init(){
        initMenuArray()
    }
    
   
    
    // MARK: - button Act
        
    mutating func actPrevDay() {
            int_date = int_date - 1
            self.initMenuArray()
            ReLoadTableData()
    }
    /*
        func actToday() {
            int_date = 0
            self.initMenuArray()
            loadTableData()
        }
        func actNextDay() {
            int_date = int_date + 1
            self.initMenuArray()
            loadTableData()
        }
    */
    
    mutating func ReLoadTableData() {
       // MenuArray[id:1] = init(id:1,name:"",push:"")
    }
    

    //  Converted to Swift 4 by Swiftify v4.2.28153 - https://objectivec2swift.com/
    // 取得目前的時間
    mutating func my_today() -> Date {
        // http://my.oschina.net/u/559156/blog/125340
        // NSDate的计算问题、日期计算、时区问题、NSTimer
        let now = Date.init()
        let tz  = NSTimeZone.default as NSTimeZone
        let seconds: Int = tz.secondsFromGMT(for: now) + 24*60*60*int_date
        return Date(timeInterval: TimeInterval(seconds) , since: now)
    }
    
    //  設定選取的日期
    //  Converted to Swift 4 by Swiftify v4.2.28153 - https://objectivec2swift.com/
    //  你需要了解的 Swift 4 新东西之 Substring
    //  https://imtx.me/archives/2382.html
    mutating func initMenuArray() {
        let now : Date = my_today()
        var strDate: String = "\(now)"
        // print ("\(strDate)")
        strDate = "\(strDate.prefix(10))"
        strDate = "\(strDate.suffix(5))"
        // print ("\(strDate)")
        str_Today = strDate
        MenuArray =
        [
            TextArray(id:1,name:"今日讀經" + str_Today,push:"C05audioPlayer"),
            TextArray(id:2,name:"舊約聖經",push:"C05audioPlayer"),
            TextArray(id:3,name:"新約聖經",push:"C05audioPlayer"),
            TextArray(id:4,name:"台語詩歌",push:"C05audioPlayer"),
            TextArray(id:5,name:"我的最愛",push:"C05audioPlayer"),
            TextArray(id:6,name:"讀經進度",push:"C05audioPlayer")
        ]
      //  MenuArray = [TextArray(id:1,name:Menu1.name + str_Today ,push:Menu1.push)
      //               ,Menu2,Menu3,Menu4,Menu5,Menu6]
    }
    
    var body: some View {
        
        NavigationView {
            List(MenuArray, id: \.id) { (OneItem) in
                TableViewCell(textLabel: OneItem.name)
                .onTapGesture {
                    print("touched item \(OneItem.name)")
                    print("touched push \(OneItem.push)")
                    int_date = int_date + 1
                   // initMenuArray()
                  //  C01mainMenu()
                }
            }.padding(.all, 0)
            
            .onAppear(perform:{
                int_date = int_date + 1
                
            })
            
        }
        .navigationTitle("華語聖經")
        .onAppear(perform:{
            int_date = int_date + 1
        })
        
        
        
    }
    
    
}

struct C01mainMenu_Previews: PreviewProvider {
    static var previews: some View {
        C01mainMenu()
    }
}
