﻿Imports System.IO.Ports
Imports System.Threading


' ESP32 DFplayer Mini MP3
' https://www.youtube.com/watch?v=lEaVrSvVTf0

' ESP32 Lesson: DFplayer Mini MP3 
' http://shahrulnizam.com/esp32-lesson-dfplayer-mini-mp3/

' Arduino语音模块-DFPlayer Mini模块
' https://www.ncnynl.com/archives/201606/190.html

' DFPLayer Mini
' https://picaxe.com/docs/spe033.pdf

' Serial Port 系列(13) 基本篇 -- 完整接收資料(二)
' https://dotblogs.com.tw/billchung/2012/02/05/67809

Public Class Form1
    '------------------------------------------------
    Dim myPort As Array
    Delegate Sub SetTextCallback(ByVal [text] As String) 'Added to prevent threading errors during receiveing of data
    '------------------------------------------------
    Private Sub Form1_Load(sender As System.Object, e As System.EventArgs) Handles MyBase.Load

        myPort = IO.Ports.SerialPort.GetPortNames()
        ComboBox_com.Items.AddRange(myPort)
        ComboBox_com.SelectedIndex = 0
        ComboBox_rate.SelectedIndex = 0


        Dim cmdArray() As String = {"1 下一曲 ", "2 上一曲 ", "3 指定曲目（NUM）", "4 音量+ ", "5 音量-",
                "6 指定音量 ", "7 指定EQ 0/1/2/3/4/5", "8 单曲循环指定曲目播放 ", "9 指定播放设备 1/2/3/4/5 ", "A 进入休眠——低功耗 ", "B 保留 ",
                "C 模块复位 ", "D 播放", "E 暂停 ", "F 指定文件夹播放", "10 扩音设置（无）", "11 全部循环播放 ", "12 指定MP3文件夹曲目 ",
                "13 插播广告", "14 支持15个文件夹", "15 停止播放，播放背景", "16 停止播放"}
        ComboBox_cmd.Items.AddRange(cmdArray)
        ComboBox_cmd.SelectedIndex = 0

        Dim queryArray() As String = {"0x3F 发送初始化参数 0-0x0F（低四位每位代表一种设备）", "0x42 查询当前状态 ", "0x43 查询当前音量", "0x48 查询TF卡的总文件数", "0x4C 查询TF的当前曲目"}
        ComboBox_Query.Items.AddRange(queryArray)
        ComboBox_Query.SelectedIndex = 0


        Button_write.Enabled = False

    End Sub
    '------------------------------------------------
    Private Sub ComboBox1_Click(sender As System.Object, e As System.EventArgs) Handles ComboBox_com.Click
    End Sub
    '------------------------------------------------
    Private Sub Button1_Click(sender As System.Object, e As System.EventArgs) Handles Button1.Click
        SerialPort1.PortName = ComboBox_com.Text
        SerialPort1.BaudRate = ComboBox_rate.Text
        'SerialPort1.ReadBufferSize = 40
        SerialPort1.Open()


        Button1.Enabled = False
        Button_write.Enabled = True
        Button4.Enabled = True

    End Sub
    '------------------------------------------------
    Private Sub Button_write_Click(sender As System.Object, e As System.EventArgs) Handles Button_write.Click
        'write
        RichTextBox2.Text = ""
        totalLength = 0

        'ESP32 DFplayer Mini MP3
        'https://www.youtube.com/watch?v=lEaVrSvVTf0
        'http://shahrulnizam.com/esp32-lesson-dfplayer-mini-mp3/

        'Arduino语音模块-DFPlayer Mini模块
        'https://www.ncnynl.com/archives/201606/190.html

        'Dim command() As Byte = {Start_Byte, Version_Byte, Command_Length, CMD, Acknowledge, part1, part2, crc16Data(1), crc16Data(0), endbyte}
        Dim command() As Byte = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

        Dim PartValue_H As Short = Convert.ToByte(TextBox_Value_H.Text)
        Dim PartValue_L As Short = Convert.ToByte(TextBox_Value_L.Text)
        Dim CMD_Value As Byte = ComboBox_cmd.SelectedIndex + 1

        play_cmd(CMD_Value, PartValue_H, PartValue_L, command)

        MsgBox(Convert.ToString(CMD_Value) + ":" + Convert.ToString(PartValue_H, 16) + Convert.ToString(PartValue_L, 16))

        SerialPort1.Write(command, 0, command.Length)

    End Sub


    Function play_cmd(CMD As Byte, part_H As Byte, part_L As Byte, ByRef command As Byte()) As Boolean

        Dim Start_Byte As Byte = &H7E
        Dim Version_Byte As Byte = &HFF
        Dim Command_Length As Byte = &H6
        Dim Feedback As Byte = &H0 '是否需要反馈信息,1反馈,0不反馈
        Dim endbyte As Byte = &HEF
        Dim crc16Data() As Byte = {0, 0}
        Dim partArray() As Byte = {0, 0}

        ' partArray = BitConverter.GetBytes(part)

        Dim checksum As Short
        checksum = Version_Byte
        checksum = checksum + Command_Length
        checksum = checksum + CMD
        checksum = checksum + Feedback
        checksum = checksum + part_H
        checksum = checksum + part_L
        checksum = checksum * -1

        crc16Data = BitConverter.GetBytes(checksum)

        command = {Start_Byte, Version_Byte, Command_Length, CMD, Feedback, part_H, part_L, crc16Data(1), crc16Data(0), endbyte}
        'MsgBox(Convert.ToString(command(0), 16) & ":" & Convert.ToString(command(1), 16) &
        '    ":" & Convert.ToString(command(2), 16) & ":" & Convert.ToString(command(3), 16) &
        '    ":" & Convert.ToString(command(4), 16) & ":" & Convert.ToString(command(5), 16) &
        '    ":" & Convert.ToString(command(6), 16) & ":" & Convert.ToString(command(7), 16) &
        '    ":" & Convert.ToString(command(8), 16) & ":" & Convert.ToString(command(9), 16))

        RichTextBox1.Text = Convert.ToString(command(0), 16) & "-" & Convert.ToString(command(1), 16) &
            "-" & Convert.ToString(command(2), 16) & "-" & Convert.ToString(command(3), 16) &
            "-" & Convert.ToString(command(4), 16) & "-" & Convert.ToString(command(5), 16) &
            "-" & Convert.ToString(command(6), 16) & "-" & Convert.ToString(command(7), 16) &
            "-" & Convert.ToString(command(8), 16) & "-" & Convert.ToString(command(9), 16)

        play_cmd = True
    End Function

    Private Sub Button4_Click(sender As System.Object, e As System.EventArgs) Handles Button4.Click
        SerialPort1.Close()
        Button1.Enabled = True
        Button_write.Enabled = False
        Button4.Enabled = False
    End Sub

    Private totalLength As Int32 = 0
    Private Delegate Sub Display(ByVal buffer As Byte())

    Private Sub DisplayText(ByVal buffer As Byte())
        RichTextBox2.Text &= String.Format("{0}{1}", BitConverter.ToString(buffer), Environment.NewLine)
        totalLength = totalLength + buffer.Length
        Label_Length.Text = totalLength.ToString()
    End Sub

    Private Sub SerialPort1_DataReceived(sender As System.Object, e As System.IO.Ports.SerialDataReceivedEventArgs) Handles SerialPort1.DataReceived
        ' Dim rec_str As String = Convert.ToString(SerialPort1.ReadByte)
        ' ReceivedText(rec_str)

        Dim buffer(1023) As Byte
        Dim length As Int32 = DirectCast(sender, SerialPort).Read(buffer, 0, buffer.Length)
        Array.Resize(buffer, length)
        Dim d As New Display(AddressOf DisplayText)
        Me.Invoke(d, New Object() {buffer})

    End Sub

    'https://dotblogs.com.tw/billchung/2012/01/20/66860
    Private Sub ReceivedText(ByVal [text] As String) 'input from ReadExisting
        If Me.RichTextBox2.InvokeRequired Then
            Dim x As New SetTextCallback(AddressOf ReceivedText)
            Me.Invoke(x, New Object() {(text)})
        Else
            Me.RichTextBox2.Text &= [text] 'append text
        End If
    End Sub

    Private Sub Button_Query_Click(sender As Object, e As EventArgs) Handles Button_Query.Click
        'Query
        RichTextBox2.Text = ""
        totalLength = 0

        Dim command() As Byte = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0}

        ' Dim PartValue As Short = Convert.ToInt16(TextBox_Query.Text)

        Dim PartValue_H As Short = Convert.ToByte(TextBox_Value_H.Text)
        Dim PartValue_L As Short = Convert.ToByte(TextBox_Value_L.Text)
        Dim CMD_Value As Byte = ComboBox_Query.SelectedIndex

        Select Case CMD_Value
            Case 0
                CMD_Value = &H3F
            Case 1
                CMD_Value = &H42
            Case 2
                CMD_Value = &H43
            Case 3
                CMD_Value = &H48
            Case 4
                CMD_Value = &H4C
        End Select

        play_cmd(CMD_Value, PartValue_H, PartValue_L, command)
        SerialPort1.Write(command, 0, command.Length)
        Thread.Sleep(200)

        ' https://docs.microsoft.com/zh-tw/dotnet/api/system.io.ports.serialport.readtimeout?view=dotnet-plat-ext-5.0
        SerialPort1.ReadTimeout = 1000
        'SerialPort1.WriteTimeout = 500

        Dim returnStr As String = Nothing
        Dim receiving As Boolean = True

        Try
            While receiving = True
                Dim receivedValue As Int32 = SerialPort1.ReadByte()
                Select Case receivedValue
                    Case -1
                        receiving = False
                        Exit While
                    Case Else
                        returnStr &= Convert.ToString(receivedValue) & vbCrLf
                        receiving = False
                        Exit While
                End Select
            End While

        Catch ex As TimeoutException
            'returnStr = "Error: Serial Port read timed out."
            MsgBox("Error: Serial Port read timed out.")
        End Try

        RichTextBox2.Text = returnStr

    End Sub

    Private Sub Button_Clear_Click(sender As Object, e As EventArgs) Handles Button_Clear.Click
        RichTextBox2.Text = ""
    End Sub


End Class
