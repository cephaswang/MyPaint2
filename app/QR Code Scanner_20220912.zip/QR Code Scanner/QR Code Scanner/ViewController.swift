//
//  ViewController.swift
//  QR Code Scanner
//
//  Created by admin on 2022/9/12.
//

/*

Bar | QR Code Scanner in iOS with swift 5
https://www.youtube.com/watch?v=nsL79UTmK94

Swift 5: How to create an app to scan QR codes?
https://www.youtube.com/watch?v=mhm3Q13SWkc
 
*/

import UIKit
import AVFoundation

class ViewController: UIViewController {
    
    var captureSession = AVCaptureSession()
    var previewLayer: AVCaptureVideoPreviewLayer!
    var qrcodeFrameView:UIView?
    
    // https://developer.apple.com/documentation/avfoundation/avmetadataobject/objecttype
    private let supportedCodeTypes = [
        AVMetadataObject.ObjectType.upce,
        AVMetadataObject.ObjectType.code39,
        AVMetadataObject.ObjectType.code39Mod43,
        AVMetadataObject.ObjectType.code93,
        AVMetadataObject.ObjectType.code128,
        AVMetadataObject.ObjectType.ean8,
        AVMetadataObject.ObjectType.ean13,
        AVMetadataObject.ObjectType.aztec,
        AVMetadataObject.ObjectType.pdf417,
        AVMetadataObject.ObjectType.dataMatrix,
        AVMetadataObject.ObjectType.qr
       ]
    
    @IBOutlet weak var messageLabel: UILabel!

    override func viewDidLoad() {
        super.viewDidLoad()
    }

    @IBAction func scan(_ sender: Any) {
        self.demo ()
    }

    func demo (){

        guard let videoCaptureDevice = AVCaptureDevice.default( .builtInWideAngleCamera , for: .video , position: .back) else {
            print("Your device is not aplicable for video processing")
            return
        }

        do {
            let videoInput = try AVCaptureDeviceInput (device: videoCaptureDevice )
            captureSession.addInput(videoInput)
        } catch {
            print("Your device can not give video input!")
            return
        }
        
        let metadataOutput = AVCaptureMetadataOutput ()
        if ( self.captureSession.canAddOutput (metadataOutput)) {
            self.captureSession.addOutput (metadataOutput)
            metadataOutput.setMetadataObjectsDelegate(self, queue: DispatchQueue.main)
            metadataOutput.metadataObjectTypes = supportedCodeTypes
        } else {
            return
        }
        self.previewLayer = AVCaptureVideoPreviewLayer(session: self.captureSession)
        self.previewLayer.frame = self.view.layer.bounds
        self.previewLayer.videoGravity = .resizeAspectFill
        self.view.layer.addSublayer(self.previewLayer)
        print("Running")
        self.captureSession.startRunning()

        view.bringSubviewToFront(messageLabel)

        uilayer()
    }
    
    func uilayer(){
        // Initialize QR Code Frame to highlight the QR Code
        qrcodeFrameView = UIView()
        if let qrcodeFrameView = qrcodeFrameView{
            qrcodeFrameView.layer.borderColor = UIColor.yellow.cgColor
            qrcodeFrameView.layer.borderWidth = 2
            view.addSubview(qrcodeFrameView)
            view.bringSubviewToFront(qrcodeFrameView)
        }
    }

}


extension ViewController : AVCaptureMetadataOutputObjectsDelegate{

    func metadataOutput(_ output: AVCaptureMetadataOutput, didOutput metadataObjects: [AVMetadataObject], from connection: AVCaptureConnection) {
        if let first = metadataObjects.first {
            guard let readableObject = first as? AVMetadataMachineReadableCodeObject else {
                return
            }
            
            guard let stringValue = readableObject.stringValue else {
                return
            }
            
            if metadataObjects.count == 0 {
                qrcodeFrameView?.frame = CGRect.zero
                messageLabel.text = "No QR Code is detected"
                return
            }
            
            print(readableObject.type)
            
            let barCodeObject = previewLayer.transformedMetadataObject(for: metadataObjects[0] as! AVMetadataMachineReadableCodeObject)
            qrcodeFrameView?.frame = barCodeObject!.bounds
            messageLabel.text =  "\(readableObject.type)\n\(stringValue)"
            print(stringValue)
        } else {
            print("Not able to read the code! Please try again or be keep your devices on Bar Code or Scanner Code!")
        }
    }

}
