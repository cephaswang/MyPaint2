//
//  memberView.swift
//  demoView
//
//  Created by admin on 2022/5/8.

//
/*
 
 
SwiftUI - Firebase Push Notifications Without Backend Servers - Xcode 13 - Firebase Cloud Messaging
https://www.youtube.com/watch?v=DoITpssj-jk
 
 
SwiftUI 2.0 Push Notifications - Firebase Cloud Messaging - SwiftUI Tutorials
https://www.youtube.com/watch?v=3rRdXvXAsFs
 
 
sugoi.sugoi.design@gmail.com / Dg924@dhHn
 
https://marc.vos.net/howto/macos-web-server/
sudo apachectl start
 
How to communicate between Native(iOS swiftUI) and WKWebView | JSer
https://www.youtube.com/watch?v=t0bKurq_Apk
https://gist.github.com/JSerZANP/ea300d419bfafa79e4f8c0af42d8fec6

 
https://www.youtube.com/watch?v=aMXhaR_LQ7M

 
Push Notifications with Firebase iOS Swift 5 & Xcode 11.5
https://www.youtube.com/watch?v=vvq0etotS8M


Firebase Cloud Messaging
https://firebase.google.com/docs/cloud-messaging

 
 
https://www.member.5.ibiz.tw/user/api.php?mode=token&type=ios&is_uu=daniel&data=
 
 
 d9cRie8-QEqas695yxAUhX:APA91bEQe3TnrN5zGkZGmzRtMJZgDKijVOlJ0hgvlcOWnwrYsF2FREQGUVeJNGIb-08SgkDMWgcmiurQRnKG1xQzJ2_qFyrApA6Iygdo1bU9ghQ4dRFRphXbnX1H_Q7ePc7SKy0393fu
 
 
 19:55 Daniel https://www.member.5.ibiz.tw/app/panel/user.php
 19:55 Daniel 帳號：app
 密碼：Ap924@jdKe
 
 我目前做了二個funcion，一個是讓app可以抓到目前
 user ID的api： https://www.member.5.ibiz.tw/app/api.php?mode=xid
 
 19:55 Daniel https://www.member.5.ibiz.tw/app/panel/user.php
 19:55 Daniel 帳號：app
 密碼：Ap924@jdKe
 19:55 Daniel 如果你正常傳入token，可以在後台看到
 
 
*/


import SwiftUI
import WebKit



struct memberView: UIViewRepresentable {
    class Coordinator: NSObject, WKNavigationDelegate, WKScriptMessageHandler, URLSessionDelegate, URLSessionDownloadDelegate, UNUserNotificationCenterDelegate {
        
        func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
            print(location)
        }

        var webView: WKWebView?
        var session: URLSession? = nil
        var DownloadTaskSession : URLSessionDownloadTask!
        
        func webView(_ webView: WKWebView, didFinish navigation: WKNavigation!) {
            self.webView = webView
            print("didFinish")
            

            
        }
        
        // receive message from wkwebview
        func userContentController(
            _ userContentController: WKUserContentController,
            didReceive message: WKScriptMessage
        ) {
            print(message.body)
            let JSON:String = message.body as! String

            // https://www.avanderlee.com/swift/json-parsing-decoding/
            struct UserInfo: Decodable {
                enum Category: String, Decodable {
                    case is_uu, id
                }
                let is_uu: String
                let id: Int
            }
            
            let jsonData = JSON.data(using: .utf8)!
            let oneUser: UserInfo = try! JSONDecoder().decode(UserInfo.self, from: jsonData)
            // print(oneUser.is_uu)
            
            DispatchQueue.main.asyncAfter(deadline: .now() + 1) { [self] in
                let urlString:String = "https://www.member.5.ibiz.tw/user/api.php?mode=token&type=ios&is_uu=" + oneUser.is_uu + "&data="
                print(urlString)
                // let urlString:String = "http://192.168.0.1/"
                self.session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
                self.DownloadTaskSession = self.session!.downloadTask(with: URL(string: urlString)!)
                self.DownloadTaskSession.resume()
            }
        }


    }
    
    func makeCoordinator() -> Coordinator {
        return Coordinator()
    }
    
    func makeUIView(context: Context) -> WKWebView {
        let coordinator = makeCoordinator()
        let userContentController = WKUserContentController()
        userContentController.add(coordinator, name: "bridge")
        
        let configuration = WKWebViewConfiguration()
        configuration.userContentController = userContentController
        
        let _wkwebview = WKWebView(frame: .zero, configuration: configuration)
        _wkwebview.navigationDelegate = coordinator
        return _wkwebview
    }
    
    func updateUIView(_ webView: WKWebView, context: Context) {
      //  let url:NSURL = NSURL(string: "http://www.member.5.ibiz.tw")!
        let url:NSURL = NSURL(string: "http://192.168.0.103/001.html")!
    
        let request:NSURLRequest = NSURLRequest(url:url as URL)
        webView.load(request as URLRequest)
        
       // var JavaScriptVar:String  = "window.onload = function(){ alert('測試文字'); };"
       // JavaScriptVar = "window.onload = function(){ webkit.messageHandlers.bridge.postMessage( 'window.location.href' ); };"
        //webView.evaluateJavaScript(JavaScriptVar)
    }
}

struct memberView_Previews: PreviewProvider {
    static var previews: some View {
        memberView()
    }
}

// https://www.youtube.com/watch?v=3rRdXvXAsFs
// SwiftUI 2.0 Push Notifications - Firebase Cloud Messaging - SwiftUI Tutorials
