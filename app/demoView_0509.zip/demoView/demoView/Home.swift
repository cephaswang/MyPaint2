//
//  Home.swift
//  demoView
//
//  Created by admin on 2022/5/9.
//

import SwiftUI

struct Home: View {
    
    @State var titleText = ""
    @State var bodyText = ""
    @State var deviceToken = ""
    
    
    var body: some View {
       
        List {
            
            Section {
                TextField("",text:$titleText)
            } header: {
                Text("Message Title")
            }
            
            Section {
                TextField("",text:$bodyText)
            } header: {
                Text("Message Body")
            }
            
            Section {
                TextField("",text:$deviceToken)
            } header: {
                Text("DeviceToken")
            }
            
            Button{
                sendMessageToDevice()
            } label: {
                Text("Send Push Notification")
            }
            
            
        }
        
    }
    
    // https://www.youtube.com/watch?v=DoITpssj-jk
    func sendMessageToDevice(){
        
        guard let url = URL(string: "https://fcm.googleapis.com/fcm/send") else {
            return
        }
        
        let json:[String:Any] = [
            "to":deviceToken,
            "notification":[
                "title":titleText,
                "body":bodyText
            ],
            "data":[
                "user_name":"iJustine"
            ]
        
        ]
        let ServierKey = "AAAAoBF2IfU:APA91bHf3DSL1Qq3tZeDVRjEOLQTGmJV_L1bW7kr18RX7Vjem9Gk0AZiPytH2r8staA0Hccl6u9ToDC5G0ayP-K73O8-YfvUmycuWgn0oEYq9oD6a7a-2GXs3_0PbXBGpvGbQVksc3bk"
        var request = URLRequest(url:url)
        request.httpMethod = "POST"
        request.httpBody = try?JSONSerialization.data(withJSONObject: json, options: [.prettyPrinted] )
        request.setValue("application/json", forHTTPHeaderField: "Content-Type")
        request.setValue("key=\(ServierKey)", forHTTPHeaderField: "Authorization")
        
        let session = URLSession(configuration: .default)
        session.dataTask(with: request){
            _,_, err in
            if let err = err {
                print(err.localizedDescription)
                return
            }
            
            print("Success")
            DispatchQueue.main.async {
                titleText = ""
                bodyText = ""
                deviceToken = ""
            }
        }.resume()
        
    }
}

struct Home_Previews: PreviewProvider {
    static var previews: some View {
        Home()
    }
}
