package org.shar35.audiobiblehk


import android.annotation.SuppressLint
import android.content.Context
import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.dd.plist.NSArray
import com.dd.plist.PropertyListParser
import java.text.SimpleDateFormat
import java.util.*


class d00menu : AppCompatActivity() {

    private var acc_date = 0

    lateinit var btn_date_pre: ImageButton
    lateinit var btn_date_rst: ImageButton
    lateinit var btn_date_nex: ImageButton
    lateinit var menu_list: ListView
    lateinit var context: Context

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_d00menu)

        context = getApplicationContext();

        btn_date_pre = findViewById(R.id.btn_date_pre)
        btn_date_rst = findViewById(R.id.btn_date_rst)
        btn_date_nex = findViewById(R.id.btn_date_nex)
        menu_list    = findViewById(R.id.userlist)

        acc_date = 0
        val mystring = resources.getString(R.string.app_name)
        this.title = mystring +" "+ TodayStr ()

        btn_date_pre.setOnClickListener{
            acc_date -= 1
            val mystring = resources.getString(R.string.app_name)
            this.title = mystring +" "+ TodayStr ()
        }
        btn_date_rst.setOnClickListener{
            acc_date = 0
            val mystring = resources.getString(R.string.app_name)
            this.title = mystring +" "+ TodayStr ()
        }
        btn_date_nex.setOnClickListener{
            acc_date += 1
            val mystring = resources.getString(R.string.app_name)
            this.title = mystring +" "+ TodayStr ()
        }

        val menuData:NSArray = getMenuList( context )
        val arrayAdapter: NSArrayAdapter = NSArrayAdapter(this, menuData)
        menu_list.adapter = arrayAdapter
    }

    private fun getMenuList(context: Context): NSArray {
        var rootArray: NSArray = NSArray(0)
        try {
            val file: String = context.assets.open("tra_menu_01.plist").bufferedReader().use {
                it.readText()
            }
            rootArray = PropertyListParser.parse( file.toString().byteInputStream() ) as NSArray
        } catch (ex: Exception) {
            ex.printStackTrace()
            Toast.makeText( context, "讀取菜單文檔 失敗", Toast.LENGTH_LONG).show()
        }
        return rootArray as NSArray
    }

    fun TodayStr (): String {
        // 系統時間
        val today_str3 = getToday(acc_date)
        val mont_str = today_str3!!.substring(0, 2)
        val date_str = today_str3.substring(3, 5)
        val dayString: String = ( mont_str + "-" + date_str) as String
        return  dayString
    }

    @SuppressLint("SimpleDateFormat")
    fun getToday(Weeks: Int): String? {
        // SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd");
        val formatter = SimpleDateFormat("MM-dd")
        val TX = (60 * 60 * 24 * 1000 * Weeks).toLong()
        val curDate = Date(System.currentTimeMillis() + TX) // 獲取當前時間
        return formatter.format(curDate)
    }

    class NSArrayAdapter(val context: Context, val dataArray: NSArray): BaseAdapter() {

        override fun getCount(): Int {
            return dataArray.count()
        }

        override fun getItem(position: Int): Any {
            return dataArray.objectAtIndex(position)
        }

        override fun getItemId(position: Int): Long {
            return 0
        }

        @SuppressLint("ResourceAsColor")
        override fun getView(position: Int, convertView: View?, parent: ViewGroup?): View {
            val listheroView = LayoutInflater.from( context ).inflate(R.layout.row_c01b, parent, false)
            val textMain: TextView = listheroView.findViewById(R.id.textMain)
            val textEngl: TextView = listheroView.findViewById(R.id.textEnglish)
            val OneRec: NSArray = getItem(position) as NSArray
            textMain.setText( OneRec.objectAtIndex(0).toString() )
            textEngl.setText( OneRec.objectAtIndex(1).toString() )
            return listheroView
        }

    }

}