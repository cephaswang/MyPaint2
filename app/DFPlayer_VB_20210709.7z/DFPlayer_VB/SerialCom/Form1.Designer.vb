﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Form1
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.Button1 = New System.Windows.Forms.Button()
        Me.Button_write = New System.Windows.Forms.Button()
        Me.ComboBox_com = New System.Windows.Forms.ComboBox()
        Me.RichTextBox1 = New System.Windows.Forms.RichTextBox()
        Me.RichTextBox2 = New System.Windows.Forms.RichTextBox()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Button4 = New System.Windows.Forms.Button()
        Me.SerialPort1 = New System.IO.Ports.SerialPort(Me.components)
        Me.ComboBox_rate = New System.Windows.Forms.ComboBox()
        Me.ComboBox_cmd = New System.Windows.Forms.ComboBox()
        Me.TextBox_Value_L = New System.Windows.Forms.TextBox()
        Me.TextBox_Query = New System.Windows.Forms.TextBox()
        Me.ComboBox_Query = New System.Windows.Forms.ComboBox()
        Me.Button_Query = New System.Windows.Forms.Button()
        Me.Label_Length = New System.Windows.Forms.Label()
        Me.Button_Clear = New System.Windows.Forms.Button()
        Me.TextBox_Value_H = New System.Windows.Forms.TextBox()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'Button1
        '
        Me.Button1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Button1.Location = New System.Drawing.Point(646, 68)
        Me.Button1.Name = "Button1"
        Me.Button1.Size = New System.Drawing.Size(75, 46)
        Me.Button1.TabIndex = 0
        Me.Button1.Text = "Init"
        Me.Button1.UseVisualStyleBackColor = True
        '
        'Button_write
        '
        Me.Button_write.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Button_write.Location = New System.Drawing.Point(403, 68)
        Me.Button_write.Name = "Button_write"
        Me.Button_write.Size = New System.Drawing.Size(75, 46)
        Me.Button_write.TabIndex = 1
        Me.Button_write.Text = "Write"
        Me.Button_write.UseVisualStyleBackColor = True
        '
        'ComboBox_com
        '
        Me.ComboBox_com.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_com.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboBox_com.FormattingEnabled = True
        Me.ComboBox_com.Location = New System.Drawing.Point(507, 68)
        Me.ComboBox_com.Name = "ComboBox_com"
        Me.ComboBox_com.Size = New System.Drawing.Size(121, 28)
        Me.ComboBox_com.TabIndex = 3
        '
        'RichTextBox1
        '
        Me.RichTextBox1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.RichTextBox1.Location = New System.Drawing.Point(59, 68)
        Me.RichTextBox1.Name = "RichTextBox1"
        Me.RichTextBox1.Size = New System.Drawing.Size(335, 89)
        Me.RichTextBox1.TabIndex = 4
        Me.RichTextBox1.Text = ""
        '
        'RichTextBox2
        '
        Me.RichTextBox2.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.RichTextBox2.Location = New System.Drawing.Point(59, 210)
        Me.RichTextBox2.Name = "RichTextBox2"
        Me.RichTextBox2.Size = New System.Drawing.Size(335, 89)
        Me.RichTextBox2.TabIndex = 5
        Me.RichTextBox2.Text = ""
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label1.Location = New System.Drawing.Point(59, 39)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(46, 20)
        Me.Label1.TabIndex = 6
        Me.Label1.Text = "Input"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Label2.Location = New System.Drawing.Point(59, 185)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(58, 20)
        Me.Label2.TabIndex = 7
        Me.Label2.Text = "Output"
        '
        'Button4
        '
        Me.Button4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Button4.Location = New System.Drawing.Point(646, 210)
        Me.Button4.Name = "Button4"
        Me.Button4.Size = New System.Drawing.Size(75, 46)
        Me.Button4.TabIndex = 8
        Me.Button4.Text = "Close"
        Me.Button4.UseVisualStyleBackColor = True
        '
        'SerialPort1
        '
        Me.SerialPort1.PortName = "COM6"
        '
        'ComboBox_rate
        '
        Me.ComboBox_rate.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_rate.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboBox_rate.FormattingEnabled = True
        Me.ComboBox_rate.Items.AddRange(New Object() {"9600", "38400", "57600", "115200"})
        Me.ComboBox_rate.Location = New System.Drawing.Point(507, 131)
        Me.ComboBox_rate.Name = "ComboBox_rate"
        Me.ComboBox_rate.Size = New System.Drawing.Size(121, 28)
        Me.ComboBox_rate.TabIndex = 9
        '
        'ComboBox_cmd
        '
        Me.ComboBox_cmd.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_cmd.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboBox_cmd.FormattingEnabled = True
        Me.ComboBox_cmd.Location = New System.Drawing.Point(403, 176)
        Me.ComboBox_cmd.Name = "ComboBox_cmd"
        Me.ComboBox_cmd.Size = New System.Drawing.Size(225, 28)
        Me.ComboBox_cmd.TabIndex = 10
        '
        'TextBox_Value_L
        '
        Me.TextBox_Value_L.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TextBox_Value_L.Location = New System.Drawing.Point(519, 210)
        Me.TextBox_Value_L.Name = "TextBox_Value_L"
        Me.TextBox_Value_L.Size = New System.Drawing.Size(44, 27)
        Me.TextBox_Value_L.TabIndex = 11
        Me.TextBox_Value_L.Text = "0"
        '
        'TextBox_Query
        '
        Me.TextBox_Query.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TextBox_Query.Location = New System.Drawing.Point(403, 354)
        Me.TextBox_Query.Name = "TextBox_Query"
        Me.TextBox_Query.Size = New System.Drawing.Size(121, 27)
        Me.TextBox_Query.TabIndex = 13
        Me.TextBox_Query.Text = "0"
        '
        'ComboBox_Query
        '
        Me.ComboBox_Query.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.ComboBox_Query.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.ComboBox_Query.FormattingEnabled = True
        Me.ComboBox_Query.Location = New System.Drawing.Point(403, 311)
        Me.ComboBox_Query.Name = "ComboBox_Query"
        Me.ComboBox_Query.Size = New System.Drawing.Size(225, 28)
        Me.ComboBox_Query.TabIndex = 12
        '
        'Button_Query
        '
        Me.Button_Query.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Button_Query.Location = New System.Drawing.Point(403, 255)
        Me.Button_Query.Name = "Button_Query"
        Me.Button_Query.Size = New System.Drawing.Size(75, 46)
        Me.Button_Query.TabIndex = 14
        Me.Button_Query.Text = "Query"
        Me.Button_Query.UseVisualStyleBackColor = True
        '
        'Label_Length
        '
        Me.Label_Length.AutoSize = True
        Me.Label_Length.Location = New System.Drawing.Point(61, 327)
        Me.Label_Length.Name = "Label_Length"
        Me.Label_Length.Size = New System.Drawing.Size(70, 12)
        Me.Label_Length.TabIndex = 15
        Me.Label_Length.Text = "Label_Length"
        '
        'Button_Clear
        '
        Me.Button_Clear.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!)
        Me.Button_Clear.Location = New System.Drawing.Point(319, 308)
        Me.Button_Clear.Name = "Button_Clear"
        Me.Button_Clear.Size = New System.Drawing.Size(75, 46)
        Me.Button_Clear.TabIndex = 16
        Me.Button_Clear.Text = "Clear"
        Me.Button_Clear.UseVisualStyleBackColor = True
        '
        'TextBox_Value_H
        '
        Me.TextBox_Value_H.Font = New System.Drawing.Font("新細明體", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.TextBox_Value_H.Location = New System.Drawing.Point(434, 210)
        Me.TextBox_Value_H.Name = "TextBox_Value_H"
        Me.TextBox_Value_H.Size = New System.Drawing.Size(44, 27)
        Me.TextBox_Value_H.TabIndex = 17
        Me.TextBox_Value_H.Text = "0"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label3.Location = New System.Drawing.Point(401, 213)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(22, 19)
        Me.Label3.TabIndex = 18
        Me.Label3.Text = "H"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Font = New System.Drawing.Font("新細明體", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(136, Byte))
        Me.Label4.Location = New System.Drawing.Point(484, 213)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(20, 19)
        Me.Label4.TabIndex = 19
        Me.Label4.Text = "L"
        '
        'Form1
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 12.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.SystemColors.AppWorkspace
        Me.ClientSize = New System.Drawing.Size(805, 433)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.TextBox_Value_H)
        Me.Controls.Add(Me.Button_Clear)
        Me.Controls.Add(Me.Label_Length)
        Me.Controls.Add(Me.Button_Query)
        Me.Controls.Add(Me.TextBox_Query)
        Me.Controls.Add(Me.ComboBox_Query)
        Me.Controls.Add(Me.TextBox_Value_L)
        Me.Controls.Add(Me.ComboBox_cmd)
        Me.Controls.Add(Me.ComboBox_rate)
        Me.Controls.Add(Me.Button4)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.RichTextBox2)
        Me.Controls.Add(Me.RichTextBox1)
        Me.Controls.Add(Me.ComboBox_com)
        Me.Controls.Add(Me.Button_write)
        Me.Controls.Add(Me.Button1)
        Me.Name = "Form1"
        Me.Text = "Form1"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Button1 As System.Windows.Forms.Button
    Friend WithEvents Button_write As System.Windows.Forms.Button
    Friend WithEvents ComboBox_com As System.Windows.Forms.ComboBox
    Friend WithEvents RichTextBox1 As System.Windows.Forms.RichTextBox
    Friend WithEvents RichTextBox2 As System.Windows.Forms.RichTextBox
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Button4 As System.Windows.Forms.Button
    Friend WithEvents SerialPort1 As System.IO.Ports.SerialPort
    Friend WithEvents ComboBox_rate As System.Windows.Forms.ComboBox
    Friend WithEvents ComboBox_cmd As ComboBox
    Friend WithEvents TextBox_Value_L As TextBox
    Friend WithEvents TextBox_Query As TextBox
    Friend WithEvents ComboBox_Query As ComboBox
    Friend WithEvents Button_Query As Button
    Friend WithEvents Label_Length As Label
    Friend WithEvents Button_Clear As Button
    Friend WithEvents TextBox_Value_H As TextBox
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
End Class
