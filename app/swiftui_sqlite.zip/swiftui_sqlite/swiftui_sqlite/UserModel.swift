//
//  UserModel.swift
//  CRUD_SQLite
//
//  Created by Adnan Afzal on 03/12/2020.
//  Copyright © 2020 Adnan Afzal. All rights reserved.
//

import Foundation

class UserModel: Identifiable {
    public var id: Int64 = 0
    public var name: String = ""
    public var email: String = ""
    public var age: Int64 = 0
}
