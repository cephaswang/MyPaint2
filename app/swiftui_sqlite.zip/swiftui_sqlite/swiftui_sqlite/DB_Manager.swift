//
//  DB_Manager.swift
//  CRUD_SQLite
//
//  Created by Adnan Afzal on 03/12/2020.
//  Copyright © 2020 Adnan Afzal. All rights reserved.
//

import Foundation
import SQLite3
 
class DB_Manager {
     
    // sqlite instance
    private var db: OpaquePointer!

    // constructor of this class
    init () {
         
        let dbInfoName:String = "my_users.sqlite3"
        // exception handling

        do {
            // url(for:in:appropriateFor:create:)
            // https://developer.apple.com/documentation/foundation/filemanager/1407693-url
            let fileUrl = try FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
                ).appendingPathComponent(dbInfoName)
            
            print(fileUrl.path)
            
            if sqlite3_open(fileUrl.path, &db) != SQLITE_OK {
                print("error:\(fileUrl.path)")
                return
            }
        } catch {}
         

        // check if the user's table is already created
        if (!UserDefaults.standard.bool(forKey: "is_db_created")) {

            let strSQL = "CREATE TABLE `users` (`id` INTEGER PRIMARY KEY AUTOINCREMENT, `name` TEXT, `email` TEXT,`age` INTEGER );"
            if sqlite3_exec(db, strSQL, nil,nil,nil) != SQLITE_OK {
                print("error:\(strSQL)")
                //return
            } else {
                print("pass:\(strSQL)")
            }
             
            // set the value to true, so it will not attempt to create the table again
            UserDefaults.standard.set(true, forKey: "is_db_created")
         }

    }
    
    public func addUser(nameValue: String, emailValue: String, ageValue: Int64) {
        // 寫入資料表
        let strSQL:String = "INSERT INTO `users` ( `name`,`email`,`age` ) VALUES ( '\(nameValue)','\(emailValue)','\(ageValue)' );"

        if sqlite3_exec(db, strSQL, nil,nil,nil) != SQLITE_OK {
            print("error:\(strSQL)")
            return
        } else {
            print("pass:\(strSQL)")
        }
    }
    
    // return array of user models
    public func getUsers() -> [UserModel] {
         
        // create empty array
        var userModels: [UserModel] = []
     
        let strSQL = String("SELECT `id`,`name`,`email`,`age` FROM `users` order by `id` ")

        if sqlite3_prepare_v2( db, (strSQL as NSString).utf8String , -1, &db, nil ) == SQLITE_OK {
            // loop through all users
            while sqlite3_step(db) == SQLITE_ROW{
                let userModel: UserModel = UserModel()
     
                // set values in model from database
                userModel.id    = Int64(sqlite3_column_int(db, 0))
                userModel.name  = String(cString: sqlite3_column_text(db, 1)!)
                userModel.email = String(cString: sqlite3_column_text(db, 2)!)
                userModel.age   = Int64(sqlite3_column_int(db, 3))

                userModels.append(userModel)
            }
            print("error:\(strSQL)")
        } else {
            print("pass:\(strSQL)")
        }

        // return array
        return userModels
    }
    
    // get single user data
    public func getUser(idValue: Int64) -> UserModel {
     
        // create an empty object
        let userModel: UserModel = UserModel()
        let strSQL = String("SELECT `id`,`name`,`email`,`age` FROM `users` where `id` = '\(String(idValue))' ")

        if sqlite3_prepare_v2( db, (strSQL as NSString).utf8String , -1, &db, nil ) == SQLITE_OK {
            // loop through all users
            while sqlite3_step(db) == SQLITE_ROW{
                // set values in model from database
                userModel.id    = Int64(sqlite3_column_int(db, 0))
                userModel.name  = String(cString: sqlite3_column_text(db, 1)!)
                userModel.email = String(cString: sqlite3_column_text(db, 2)!)
                userModel.age   = Int64(sqlite3_column_int(db, 3))
            }
            print("pass:\(strSQL)")
        } else {
            print("error:\(strSQL)")
        }

        return userModel
    }
    
    // function to update user
    public func updateUser(idValue: Int64, nameValue: String, emailValue: String, ageValue: Int64) {
        let strSQL = String("update `users` set `name` = '\(nameValue)' , `email` = '\(emailValue)' , `age`= '\(String(ageValue))' where `id` = '\(String(idValue))' ")

        if sqlite3_prepare_v2( db, (strSQL as NSString).utf8String , -1, &db, nil ) == SQLITE_OK {
            while sqlite3_step(db) == SQLITE_ROW{
            }
            print("pass:\(strSQL)")
            return
        } else {
            print("error:\(strSQL)")
        }
    }

    // function to delete user
    public func deleteUser(idValue: Int64) {
        let strSQL = String("delete from `users` where `id` = '\(idValue)' ")

        if sqlite3_prepare_v2( db, (strSQL as NSString).utf8String , -1, &db, nil ) == SQLITE_OK {
            while sqlite3_step(db) == SQLITE_ROW{
            }
            print("pass:\(strSQL)")
            return
        } else {
            print("error:\(strSQL)")
        }
    }

}
