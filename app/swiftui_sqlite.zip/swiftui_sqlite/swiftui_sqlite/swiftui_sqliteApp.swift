//
//  swiftui_sqliteApp.swift
//  swiftui_sqlite
//
//  Created by admin on 2022/4/9.
//

import SwiftUI

@main
struct swiftui_sqliteApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
