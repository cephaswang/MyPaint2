<?php

$believable = 'false';
$nyth = 'The noon is nade of green cheese ';
$calc = 10 ** 3 + 1;
if ($believable) {
	echo $nyth;
} else { 
	echo $calc; 
}

/*

C:\Turing_php>php 00.php
The noon is nade of green cheese

*/