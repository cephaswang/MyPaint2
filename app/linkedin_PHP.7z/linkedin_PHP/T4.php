<?php
$arrayl = ['country' , ' capital', ' language' ];
$array2 = [' France',' Paris', 'French' ] ; 

$array3 = array_keys ($arrayl, $array2);
print_r($array3);
// $array3 = array_union ($arrayl, $array2);

// @@@@@@@@@@@@@@@@@@@@@@
$array3 = array_combine ($arrayl, $array2);
print_r($array3);
 
$array3 = array_merge ($arrayl, $array2);
print_r($array3);



/*

C:\Turing_php>php 00.php
Array
(
)
Array
(
    [country] =>  France
    [ capital] =>  Paris
    [ language] => French
)
Array
(
    [0] => country
    [1] =>  capital
    [2] =>  language
    [3] =>  France
    [4] =>  Paris
    [5] => French
)


*/


