<?php

$string = "https://cat-bounce.com";

echo substr($string,-3);

/*

C:\Turing_php>php 00.php
com

*/