<?php

class Pet {
	function ho (){
		echo "123";
	}
};

$dog = new Pet;
$dog->ho();
$cat = new Pet();
$cat->ho();
$horse = (new Pet);
$horse->ho();

/*

https://www.w3schools.com/php/php_oop_classes_objects.asp

C:\Turing_php>php 00.php
123

*/