<?php

$string = ' Shylock in Shakespeare\'s \"Merchant of Venice\" demands his pound of flesh. ';

/*

The opening and closing single quotes should be replaced by double quotes; and the apostrophe should be escaped by a 
backslash. 
All single and double quotes inside a string need to be escaped by backslashes to prevent a parse error. 
Strings should always be wrapped in double quotes; and double quotes inside a string should be escaped by backslashes. 
The apostrophe needs to be escaped by a backslash to prevent it from being treated as the closing quote. 


开始和结束单引号应该用双引号代替； 撇号应该用一个转义反斜杠。
字符串中的所有单引号和双引号都需要用反斜杠转义，以防止解析错误。
字符串应始终用双引号括起来； 字符串中的双引号应该用反斜杠转义。
撇号需要用反斜杠转义，以防止它被视为结束引号。

*/