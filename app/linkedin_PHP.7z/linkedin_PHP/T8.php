<?php

$my_text = 'The quick grey [squirrel]. ';
preg_match('#\[(.*?)\]#' , $my_text, $match);
print $match[1]. "\n"; 

/*

C:\Turing_php>php 00.php
squirrel


*/