﻿namespace nfsBreaker
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.label1 = new System.Windows.Forms.Label();
            this.comboBox_port = new System.Windows.Forms.ComboBox();
            this.button_close = new System.Windows.Forms.Button();
            this.richTextBox_write = new System.Windows.Forms.RichTextBox();
            this.button_write = new System.Windows.Forms.Button();
            this.label4 = new System.Windows.Forms.Label();
            this.textBox_address = new System.Windows.Forms.TextBox();
            this.richTextBox_read = new System.Windows.Forms.RichTextBox();
            this.button_read = new System.Windows.Forms.Button();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.label_cmd = new System.Windows.Forms.Label();
            this.comboBox_cmd = new System.Windows.Forms.ComboBox();
            this.label_option = new System.Windows.Forms.Label();
            this.comboBox_option = new System.Windows.Forms.ComboBox();
            this.button_open = new System.Windows.Forms.Button();
            this.button_scan = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(12, 29);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 12);
            this.label1.TabIndex = 0;
            this.label1.Text = "Port";
            // 
            // comboBox_port
            // 
            this.comboBox_port.FormattingEnabled = true;
            this.comboBox_port.Location = new System.Drawing.Point(103, 26);
            this.comboBox_port.Name = "comboBox_port";
            this.comboBox_port.Size = new System.Drawing.Size(121, 20);
            this.comboBox_port.TabIndex = 1;
            // 
            // button_close
            // 
            this.button_close.Location = new System.Drawing.Point(474, 26);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(89, 35);
            this.button_close.TabIndex = 3;
            this.button_close.Text = "close";
            this.button_close.UseVisualStyleBackColor = true;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // richTextBox_write
            // 
            this.richTextBox_write.Location = new System.Drawing.Point(103, 79);
            this.richTextBox_write.Name = "richTextBox_write";
            this.richTextBox_write.Size = new System.Drawing.Size(248, 136);
            this.richTextBox_write.TabIndex = 5;
            this.richTextBox_write.Text = "";
            // 
            // button_write
            // 
            this.button_write.Location = new System.Drawing.Point(277, 221);
            this.button_write.Name = "button_write";
            this.button_write.Size = new System.Drawing.Size(74, 27);
            this.button_write.TabIndex = 9;
            this.button_write.Text = "write";
            this.button_write.UseVisualStyleBackColor = true;
            this.button_write.Click += new System.EventHandler(this.button_write_Click);
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(10, 115);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(42, 12);
            this.label4.TabIndex = 22;
            this.label4.Text = "Address";
            // 
            // textBox_address
            // 
            this.textBox_address.Location = new System.Drawing.Point(12, 130);
            this.textBox_address.Name = "textBox_address";
            this.textBox_address.Size = new System.Drawing.Size(44, 22);
            this.textBox_address.TabIndex = 21;
            this.textBox_address.Text = "1";
            // 
            // richTextBox_read
            // 
            this.richTextBox_read.Location = new System.Drawing.Point(103, 254);
            this.richTextBox_read.Name = "richTextBox_read";
            this.richTextBox_read.Size = new System.Drawing.Size(248, 136);
            this.richTextBox_read.TabIndex = 23;
            this.richTextBox_read.Text = "";
            // 
            // button_read
            // 
            this.button_read.Location = new System.Drawing.Point(277, 396);
            this.button_read.Name = "button_read";
            this.button_read.Size = new System.Drawing.Size(74, 27);
            this.button_read.TabIndex = 24;
            this.button_read.Text = "read";
            this.button_read.UseVisualStyleBackColor = true;
            this.button_read.Click += new System.EventHandler(this.button_read_Click);
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(12, 79);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 12);
            this.label2.TabIndex = 25;
            this.label2.Text = "Send";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(12, 254);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 26;
            this.label3.Text = "Recevice";
            // 
            // label_cmd
            // 
            this.label_cmd.AutoSize = true;
            this.label_cmd.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label_cmd.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_cmd.Location = new System.Drawing.Point(357, 81);
            this.label_cmd.Name = "label_cmd";
            this.label_cmd.Size = new System.Drawing.Size(40, 16);
            this.label_cmd.TabIndex = 28;
            this.label_cmd.Text = "指令";
            // 
            // comboBox_cmd
            // 
            this.comboBox_cmd.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_cmd.FormattingEnabled = true;
            this.comboBox_cmd.Location = new System.Drawing.Point(357, 100);
            this.comboBox_cmd.Name = "comboBox_cmd";
            this.comboBox_cmd.Size = new System.Drawing.Size(384, 24);
            this.comboBox_cmd.TabIndex = 27;
            this.comboBox_cmd.SelectedIndexChanged += new System.EventHandler(this.comboBox_cmd_SelectedIndexChanged);
            // 
            // label_option
            // 
            this.label_option.AutoSize = true;
            this.label_option.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_option.Location = new System.Drawing.Point(357, 138);
            this.label_option.Name = "label_option";
            this.label_option.Size = new System.Drawing.Size(40, 16);
            this.label_option.TabIndex = 30;
            this.label_option.Text = "選項";
            // 
            // comboBox_option
            // 
            this.comboBox_option.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_option.FormattingEnabled = true;
            this.comboBox_option.Location = new System.Drawing.Point(357, 157);
            this.comboBox_option.Name = "comboBox_option";
            this.comboBox_option.Size = new System.Drawing.Size(384, 24);
            this.comboBox_option.TabIndex = 29;
            // 
            // button_open
            // 
            this.button_open.Location = new System.Drawing.Point(354, 26);
            this.button_open.Name = "button_open";
            this.button_open.Size = new System.Drawing.Size(89, 35);
            this.button_open.TabIndex = 2;
            this.button_open.Text = "open";
            this.button_open.UseVisualStyleBackColor = true;
            this.button_open.Click += new System.EventHandler(this.button_open_Click);
            // 
            // button_scan
            // 
            this.button_scan.Location = new System.Drawing.Point(594, 26);
            this.button_scan.Name = "button_scan";
            this.button_scan.Size = new System.Drawing.Size(89, 35);
            this.button_scan.TabIndex = 31;
            this.button_scan.Text = "scan";
            this.button_scan.UseVisualStyleBackColor = true;
            this.button_scan.Click += new System.EventHandler(this.button_scan_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(753, 453);
            this.Controls.Add(this.button_scan);
            this.Controls.Add(this.label_option);
            this.Controls.Add(this.comboBox_option);
            this.Controls.Add(this.label_cmd);
            this.Controls.Add(this.comboBox_cmd);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.button_read);
            this.Controls.Add(this.richTextBox_read);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_address);
            this.Controls.Add(this.button_write);
            this.Controls.Add(this.richTextBox_write);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.button_open);
            this.Controls.Add(this.comboBox_port);
            this.Controls.Add(this.label1);
            this.Name = "Form1";
            this.Text = "Form1";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.ComboBox comboBox_port;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.RichTextBox richTextBox_write;
        private System.Windows.Forms.Button button_write;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.TextBox textBox_address;
        private System.Windows.Forms.RichTextBox richTextBox_read;
        private System.Windows.Forms.Button button_read;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.Label label_cmd;
        private System.Windows.Forms.ComboBox comboBox_cmd;
        private System.Windows.Forms.Label label_option;
        private System.Windows.Forms.ComboBox comboBox_option;
        private System.Windows.Forms.Button button_open;
        private System.Windows.Forms.Button button_scan;
    }
}

