﻿using System;
using System.Windows.Forms;
using System.IO.Ports;
using System.Text;

/*
 
https://www.youtube.com/watch?v=Fer_q9LXDnQ
C# Tutorial - Serial Communication | FoxLearn

*/

namespace wash
{
    public partial class Form1 : Form
    {
        SerialPort SerialPort1 = new SerialPort();

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {
            string[] ports = SerialPort.GetPortNames();
            comboBox_port.Items.AddRange(ports);
            comboBox_port.SelectedIndex = ports.Length - 1;
            button_close.Enabled = false;
        }

        private void button_open_Click(object sender, EventArgs e)
        {
            button_open.Enabled = false;
            button_close.Enabled = true;

            try
            { 
            SerialPort1.PortName = comboBox_port.Text;
            SerialPort1.Open();
            } 
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button_close_Click(object sender, EventArgs e)
        {
            button_open.Enabled = true;
            button_close.Enabled = false;

            try
            {
                SerialPort1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_write_Click(object sender, EventArgs e)
        {
            //byte[] send_byte = new byte[10];
            //send_byte =[0x7e, 0xff , 0x6, 0x1 , 0 , 0 , 0 , 0xfe , 0xfa , 0xef];
           byte[] send_byte = { 0x7e, 0xff, 0x6, 0x1, 0, 0, 0, 0xfe, 0xfa, 0xef }; //下一首
           // byte[] send_byte = { 0x7e, 0xff, 0x6, 0x43, 0, 0, 0, 0xfe, 0xb8, 0xef }; //讀取音量Ｑ
            // 
            try
            {
                if (SerialPort1.IsOpen)
                {
                    SerialPort1.Write(send_byte,0, send_byte.Length);
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_read_Click(object sender, EventArgs e)
        {
            // C# String To Byte Array
            // https://www.c-sharpcorner.com/article/c-sharp-string-to-byte-array/

            // byte[] to hex string [duplicate]
            // https://stackoverflow.com/questions/623104/byte-to-hex-string

            try
            {
                string rec_string = "";
                rec_string = SerialPort1.ReadExisting();
                byte[] bytes = Encoding.ASCII.GetBytes(rec_string);
                richTextBox_read.Text = BitConverter.ToString(bytes);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (SerialPort1.IsOpen)
            {
                SerialPort1.Close();
            }
        }
    }
}
