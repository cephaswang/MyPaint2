﻿namespace wash
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.comboBox_port = new System.Windows.Forms.ComboBox();
            this.button_open = new System.Windows.Forms.Button();
            this.button_close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox_write = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.richTextBox_read = new System.Windows.Forms.RichTextBox();
            this.button_write = new System.Windows.Forms.Button();
            this.button_read = new System.Windows.Forms.Button();
            this.SuspendLayout();
            // 
            // comboBox_port
            // 
            this.comboBox_port.FormattingEnabled = true;
            this.comboBox_port.Location = new System.Drawing.Point(85, 26);
            this.comboBox_port.Name = "comboBox_port";
            this.comboBox_port.Size = new System.Drawing.Size(157, 20);
            this.comboBox_port.TabIndex = 0;
            // 
            // button_open
            // 
            this.button_open.Location = new System.Drawing.Point(280, 23);
            this.button_open.Name = "button_open";
            this.button_open.Size = new System.Drawing.Size(74, 27);
            this.button_open.TabIndex = 1;
            this.button_open.Text = "open";
            this.button_open.UseVisualStyleBackColor = true;
            this.button_open.Click += new System.EventHandler(this.button_open_Click);
            // 
            // button_close
            // 
            this.button_close.Location = new System.Drawing.Point(380, 23);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(74, 27);
            this.button_close.TabIndex = 2;
            this.button_close.Text = "close";
            this.button_close.UseVisualStyleBackColor = true;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(24, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "Port";
            // 
            // richTextBox_write
            // 
            this.richTextBox_write.Location = new System.Drawing.Point(85, 71);
            this.richTextBox_write.Name = "richTextBox_write";
            this.richTextBox_write.Size = new System.Drawing.Size(401, 136);
            this.richTextBox_write.TabIndex = 4;
            this.richTextBox_write.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 74);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(28, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "Send";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 263);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(47, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "Recevice";
            // 
            // richTextBox_read
            // 
            this.richTextBox_read.Location = new System.Drawing.Point(85, 263);
            this.richTextBox_read.Name = "richTextBox_read";
            this.richTextBox_read.Size = new System.Drawing.Size(401, 136);
            this.richTextBox_read.TabIndex = 6;
            this.richTextBox_read.Text = "";
            // 
            // button_write
            // 
            this.button_write.Location = new System.Drawing.Point(412, 213);
            this.button_write.Name = "button_write";
            this.button_write.Size = new System.Drawing.Size(74, 27);
            this.button_write.TabIndex = 8;
            this.button_write.Text = "write";
            this.button_write.UseVisualStyleBackColor = true;
            this.button_write.Click += new System.EventHandler(this.button_write_Click);
            // 
            // button_read
            // 
            this.button_read.Location = new System.Drawing.Point(412, 405);
            this.button_read.Name = "button_read";
            this.button_read.Size = new System.Drawing.Size(74, 27);
            this.button_read.TabIndex = 9;
            this.button_read.Text = "read";
            this.button_read.UseVisualStyleBackColor = true;
            this.button_read.Click += new System.EventHandler(this.button_read_Click);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(498, 446);
            this.Controls.Add(this.button_read);
            this.Controls.Add(this.button_write);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.richTextBox_read);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.richTextBox_write);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.button_open);
            this.Controls.Add(this.comboBox_port);
            this.Name = "Form1";
            this.Text = "Wash";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_port;
        private System.Windows.Forms.Button button_open;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox_write;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox richTextBox_read;
        private System.Windows.Forms.Button button_write;
        private System.Windows.Forms.Button button_read;
    }
}

