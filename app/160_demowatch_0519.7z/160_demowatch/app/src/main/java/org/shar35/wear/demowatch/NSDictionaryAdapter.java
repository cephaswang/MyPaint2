package org.shar35.wear.demowatch;

public interface NSDictionaryAdapter {
}
