package org.shar35.wear.demowatch;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.DownloadManager;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.database.Cursor;
import android.media.MediaPlayer;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.os.FileUtils;
import android.view.View;
import android.webkit.URLUtil;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Toast;

import java.io.File;
import java.io.IOException;

public class getfile extends AppCompatActivity {

    private Button startDownload;
    private Button showImage;
    private ImageView imageView;
    private DownloadManager manager;
    private BroadcastReceiver receiver;
     private static final String url = "http://bible.cephas.tw/bible_cantonese/001/1_001.mp3";
    //     private static final String url = "https://pgw.udn.com.tw/gw/photo.php?u=https://uc.udn.com.tw/photo/2022/05/15/realtime/17006240.jpg&x=0&y=0&sw=0&sh=0&sl=W&fw=800&exp=3600&w=800&nt=1";
    private DownloadManager.Request request;
    private long downloadId;

    private MediaPlayer mediaPlayer = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_getfile);

        String a01 = String.valueOf(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)) + "/001/" +  "1_001.mp3";

        File imageFile = new File(String.valueOf(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)) + "/001/", "1_001.mp3");
        if(imageFile.exists()){
            System.out.println("Yes");
        } else {
            System.out.println("NoNoNoNoNo");
        }

        System.out.println(a01);

        initData();
        initView();
    }

    private void initData(){
        manager = (DownloadManager) getSystemService(DOWNLOAD_SERVICE);
        receiver = new BroadcastReceiver() {
            @Override
            public void onReceive(Context context, Intent intent) {
                String action = intent.getAction();
                if(DownloadManager.ACTION_DOWNLOAD_COMPLETE.equals(action)){
                    DownloadManager.Query query = new DownloadManager.Query();
                    query.setFilterById(downloadId);
                    Cursor c = manager.query(query);
                    if (c.moveToFirst()) {
                        int columnIndex = c.getColumnIndex(DownloadManager.COLUMN_STATUS);
                        if (DownloadManager.STATUS_SUCCESSFUL == c.getInt(columnIndex)) {
                            @SuppressLint("Range") String uriString = c.getString(c.getColumnIndex(DownloadManager.COLUMN_LOCAL_URI));
                            System.out.println(uriString);
                            File a = new File(Environment.DIRECTORY_DOWNLOADS + "/001/" , "1_001.mp3");
                            System.out.println(a.getAbsolutePath());
                           // imageView.setImageURI(Uri.parse(uriString));
                            Toast.makeText(getfile.this, "download success", Toast.LENGTH_SHORT).show();

                            mediaPlayer = new MediaPlayer();

                            try {
                            //   Uri Src = new Uri(Environment.DIRECTORY_DOWNLOADS + "/001/", "1_001-8.mp3");
                                mediaPlayer.reset();
                                mediaPlayer.setDataSource(String.valueOf(getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS)) + "/001/" +  "1_001-8.mp3" );
                                mediaPlayer.prepare();
                                mediaPlayer.start();
                            } catch (IOException e) {
                                e.printStackTrace();
                            }

                        }
                    }
                }
            }
        };
        registerReceiver(receiver, new IntentFilter(DownloadManager.ACTION_DOWNLOAD_COMPLETE));

        request = new DownloadManager.Request(Uri.parse(url));
        String title = URLUtil.guessFileName(url,null,null);
        request.setTitle(title);

        System.out.println("title:" + title);
        request.setDestinationInExternalFilesDir( this, Environment.DIRECTORY_DOWNLOADS + "/001/" , title );

    }

    private void initView(){
        startDownload = (Button) findViewById(R.id.start_download);
        showImage = (Button) findViewById(R.id.show_image);
        imageView = (ImageView) findViewById(R.id.image);
        startDownload.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                downloadId = manager.enqueue(request);
            }
        });
        showImage.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent i = new Intent();
                i.setAction(DownloadManager.ACTION_VIEW_DOWNLOADS);
                startActivity(i);
            }
        });
    }

}