//
//  ViewController.swift
//  NySiri
//
//  Created by admin on 2022/9/11.
//

/*

Use Mic & Speech Recognition in App (Swift 5) Xcode 11 - 2020
https://www.youtube.com/watch?v=vg2_b_jrorU

https://gist.github.com/jacobbubu/1836273
 
https://github.com/cephaswang/MyPaint2/blob/master/app/SpeechRecognition.swift

Creating an API key to use Google Translate API | MIT App Inventor 2 advanced course
https://www.youtube.com/watch?v=c214TXW7JRI
 
https://cloud.google.com/
 
 
https://github.com/maximbilan/SwiftGoogleTranslate
 
【教程】教你找到免費的Google Translate API（谷歌翻譯介面）+C#版的Google翻譯函式
https://www.796t.com/content/1549191982.html
 
*/

import UIKit
import InstantSearchVoiceOverlay
import AVFoundation

// import SwiftGoogleTranslate
// import Firebase

class ViewController: UIViewController {

    lazy var voiceOverlay: VoiceOverlayController = {
      let recordableHandler = {
          // en_US zh_TW
        return SpeechController(locale: Locale(identifier: "zh_TW"))
      }
      return VoiceOverlayController(speechControllerHandler: recordableHandler)
    }()

    
    @IBOutlet var myButton : UIButton!
    @IBOutlet weak var myTextView: UITextView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        myButton.backgroundColor = .systemRed
        myButton.setTitleColor(.white, for: .normal)
    }

    @IBAction func didTabButton(){
       // speekToFile()
        speech()
        
    //    speek()
        
        /*
        SwiftGoogleTranslate.shared.start(with: "API_KEY_HERE")
        
        // Creating an API key to use Google Translate API | MIT App Inventor 2 advanced course
        // https://www.youtube.com/watch?v=c214TXW7JRI
        SwiftGoogleTranslate.shared.translate("大家好", "zh-TW", "en") { (text, error) in
          if let t = text {
            print(t)
              self.myTextView.text = t
          }
        }
        */

        

        
    }
    
    
    func speechtotext(){
        
        /*
        let identifiers : NSArray = NSLocale.availableLocaleIdentifiers as NSArray
        let locale = NSLocale(localeIdentifier: "en_US")
        let list = NSMutableString()
        for identifier in identifiers {
            let name = locale.displayName(forKey: NSLocale.Key.identifier, value: identifier)!
            list.append("\(identifier)\t\(name)\n")
        }
        print(list)
        */

        voiceOverlay.start(on: self, textHandler: { text ,final , _ in
            if final{
                print("Final text:\(text)")
                self.myTextView.text = text
            } else {
                print("In processes:\(text)")
            }
        },errorHandler:{error in})
        
    }
    

    func speech(){
        print("func speech()")
        // https://github.com/cagdaseksi/letslearnswift/tree/master/AvSpeechSynthesizer
        // https://www.youtube.com/watch?v=ee5qwsDs_pc
        
        let utterance = AVSpeechUtterance(string: "Hello swift.")
        utterance.voice = AVSpeechSynthesisVoice(language: "en-GB")
        utterance.rate = 0.5
        
        let synthesizer = AVSpeechSynthesizer()
        synthesizer.speak(utterance)
    }
    
    
    func saveAVSpeechUtteranceToFile(utterance: AVSpeechUtterance, fileURL: URL) throws {
       let synthesizer = AVSpeechSynthesizer()
       
       var output: AVAudioFile?
      // Logger.shared.debug("Saving region utterance to file: \(fileURL.absoluteString)")
       try? FileManager.default.removeItem(at: fileURL)
       synthesizer.write(utterance) { buffer in
          guard let pcmBuffer = buffer as? AVAudioPCMBuffer else {
           //  Logger.shared.error("unknow buffer type: \(buffer)")
             return
          }
          if pcmBuffer.frameLength == 0 {
             // no length
          }else{
             if output == nil {
                output = try! AVAudioFile(forWriting: fileURL, settings: pcmBuffer.format.settings, commonFormat: .pcmFormatInt16, interleaved: false)
             }
             try! output!.write(from: pcmBuffer)
          }
       }
    }

    func speekToFile(){
        print("speekToFile()")

        let utterance = AVSpeechUtterance(string: "Hello swift.")
        utterance.voice = AVSpeechSynthesisVoice(language: "en-GB")
        utterance.rate = 0.5

        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0]
        
        let filepath = URL(fileURLWithPath: documentsPath + "/test.caf")
        print(filepath.path)
        try? saveAVSpeechUtteranceToFile(utterance: utterance, fileURL: filepath)
    }

}

