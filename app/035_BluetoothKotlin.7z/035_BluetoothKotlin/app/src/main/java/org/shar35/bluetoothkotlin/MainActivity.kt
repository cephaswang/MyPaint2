package org.shar35.bluetoothkotlin

/*

Bluetooth Kotlin – Android Studio Tutorial
https://www.youtube.com/watch?v=PtN6UTIu7yw

*/


import android.annotation.SuppressLint
import android.app.Activity
import android.bluetooth.BluetoothAdapter
import android.content.Intent
import android.os.Bundle
import android.widget.Button
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity


class MainActivity : AppCompatActivity() {

    lateinit var bAdapter: BluetoothAdapter
    lateinit var bluetoothStartTv: TextView
    lateinit var bluetoothIv: ImageView
    lateinit var TurnOnBtn: Button
    lateinit var TurnOffBtn: Button
    lateinit var DiscoverableBtn: Button
    lateinit var pairedBtn: Button
    lateinit var pairedTv: TextView

    // Android Studio | Kotlin Bluetooth | Manage current connection
    // https://stackoverflow.com/questions/65013329/android-studio-kotlin-bluetooth-manage-current-connection
    private val REQUEST_CODE_ENABLE_BT: Int = 1
    private val REQUEST_CODE_DISCOVERABLE_BT: Int = 1

    @SuppressLint("MissingPermission")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        bluetoothStartTv = findViewById(R.id.bluetoothStartTv)
        bluetoothIv = findViewById(R.id.bluetoothIv)
        TurnOnBtn = findViewById(R.id.TurnOnBtn)
        TurnOffBtn = findViewById(R.id.TurnOffBtn)
        DiscoverableBtn = findViewById(R.id.DiscoverableBtn)
        pairedBtn = findViewById(R.id.pairedBtn)
        pairedTv = findViewById(R.id.pairedTv)

        bAdapter = BluetoothAdapter.getDefaultAdapter()

        if (bAdapter == null) {
            bluetoothStartTv.text = "Bluetooth is not abailable"
        } else {
            bluetoothStartTv.text = "Bluetooth is abailable"
        }

        if (bAdapter.isEnabled) {
            bluetoothIv.setImageResource(R.mipmap.ic_bluttooth_on)
        } else {
            bluetoothIv.setImageResource(R.mipmap.ic_bluttooth_off)
        }

        TurnOnBtn.setOnClickListener {
            if (bAdapter.isEnabled) {
                bluetoothIv.setImageResource(R.mipmap.ic_bluttooth_on)
                Toast.makeText(this , "Already on", Toast.LENGTH_LONG).show()
            } else {
                val intent = Intent(BluetoothAdapter.ACTION_REQUEST_ENABLE)
                startActivityForResult(intent,REQUEST_CODE_ENABLE_BT)
            }
        }

        TurnOffBtn.setOnClickListener {
            if (! bAdapter.isEnabled) {
                Toast.makeText(this , "Already off", Toast.LENGTH_LONG).show()
            } else {
                bAdapter.disable()
                bluetoothIv.setImageResource(R.mipmap.ic_bluttooth_off)
                Toast.makeText(this , "bluetooth turned off", Toast.LENGTH_LONG).show()
            }
        }

        DiscoverableBtn.setOnClickListener {
            if (! bAdapter.isDiscovering){
                Toast.makeText(this , "Making Your device discoverable", Toast.LENGTH_LONG).show()
                var intent = Intent(BluetoothAdapter.ACTION_REQUEST_DISCOVERABLE)
                startActivityForResult(intent,REQUEST_CODE_DISCOVERABLE_BT)
            }
        }

        pairedBtn.setOnClickListener {
            if (! bAdapter.isEnabled) {
                pairedTv.text = "Paired Devices"
                val devices = bAdapter.bondedDevices
                for(device in devices){
                    val deviceName = device.name
                    val deviceAddress = device
                    pairedTv.append("\nDevice: $deviceName, $device")
                }

                Toast.makeText(this , "Already off", Toast.LENGTH_LONG).show()
            } else {
                bAdapter.disable()
                bluetoothIv.setImageResource(R.mipmap.ic_bluttooth_off)
                Toast.makeText(this , "bluetooth turned off", Toast.LENGTH_LONG).show()
            }
        }

    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        when(requestCode){
            REQUEST_CODE_ENABLE_BT ->
                if(requestCode == Activity.RESULT_OK){
                    bluetoothIv.setImageResource(R.mipmap.ic_bluttooth_on)
                    Toast.makeText(this , "Bluetooth is on", Toast.LENGTH_LONG).show()
                } else {
                    Toast.makeText(this , "Could not on Bluetooth", Toast.LENGTH_LONG).show()
                }
        }
        super.onActivityResult(requestCode, resultCode, data)
    }
}