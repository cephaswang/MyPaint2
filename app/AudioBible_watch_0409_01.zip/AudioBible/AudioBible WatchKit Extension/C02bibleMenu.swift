//
//  C02bibleMenu.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import SwiftUI

struct C02bibleMenu: View {
    
    @State var indexBook:Int = 0
    @State var MenuArray:[CellItem] = [CellItem(id:1,name:"今日",push:"C05audioPlayer"),
                                       CellItem(id:2,name:"舊約",push:"C05audioPlayer")]
    
   // var CA:C01Menu_info = C01Menu_info()
    @State var bookTitle:[String] = ["0舊約聖經","1舊約聖經","2新約聖經","3新約聖經","4新約聖經","5新約聖經","6新約聖經","7新約聖經","8新約聖經"]

    var body: some View {
        NavigationView {
            List(MenuArray, id: \.id) { (OneItem) in
                TableViewCell(textLabel: OneItem.name)
                .onTapGesture {
                    print("touched item \(OneItem.name)")
                    print("touched push \(OneItem.push)")
                }
            }.padding(.all, 0)
        }
        .navigationTitle(bookTitle[indexBook])
        .onAppear(){
            print("C02bibleMenu:\(indexBook)")
        }
    }
}

struct C02bibleMenu_Previews: PreviewProvider {
    static var previews: some View {
        C02bibleMenu(indexBook:1)
    }
}
