//
//  Menu_Manager.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import Foundation



class C01Menu_info {
    // 日期暫存
    var int_date:Int = 0
    var str_Today : String = ""
    var MenuArray:[CellItem] = []

    func get_Today()->String{
        return str_Today
    }
    
    func my_today() -> Date {
        // http://my.oschina.net/u/559156/blog/125340
        // NSDate的计算问题、日期计算、时区问题、NSTimer
        let now = Date.init()
        let tz  = NSTimeZone.default as NSTimeZone
        let seconds: Int = tz.secondsFromGMT(for: now) + 24*60*60*int_date
        return Date(timeInterval: TimeInterval(seconds) , since: now)
    }
    
    func initMenuArray(offset:Int) -> [CellItem] {
        self.int_date = offset
        let now : Date = my_today()
        var strDate: String = "\(now)"
        // print ("\(strDate)")
        strDate = "\(strDate.prefix(10))"
        strDate = "\(strDate.suffix(5))"
        // print ("\(strDate)")
        str_Today = strDate
        MenuArray =
        [
            CellItem(id:1,name:"今日讀經" + str_Today,push:""),
            CellItem(id:2,name:"舊約聖經",push:""),
            CellItem(id:3,name:"新約聖經",push:""),
            CellItem(id:4,name:"台語詩歌",push:""),
            CellItem(id:5,name:"我的最愛",push:""),
            CellItem(id:6,name:"讀經進度",push:"")
        ]
      return MenuArray
    }
    
    
    
}
