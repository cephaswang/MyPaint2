//
//  ContentView.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//


// https://swiftontap.com/view/onappear(perform:)

import SwiftUI

struct C01mainMenu: View {
    @State var isTapped = false
    @State var int_date:Int = 0
    @State var MenuArray:[CellItem] = []
    @State var CA:C01Menu_info = C01Menu_info()
    @State var int_Selected:Int = 0

    // MARK: - button Act
        
    func actPrevDay() {
        if (int_date > 1){
            int_date = int_date - 1
        }
    }
    
    func actToday() {
        int_date = 0
    }
    
    func actNextDay() {
        int_date = int_date + 1
    }

    
    var body: some View {

        NavigationView {
            List(MenuArray, id: \.id) { (OneItem) in
                // SwiftUI Tutorial - Lists and Navigation
                // https://www.youtube.com/watch?v=Cl2gAs7hySk
                NavigationLink (destination: chooseDestination(), isActive: self.$isTapped) {
                    TableViewCell(textLabel: OneItem.name)
                    .onTapGesture {
                        print("touched item \(OneItem.name)")
                        print("touched push \(OneItem.push)")
                        isTapped.toggle()
                        int_Selected = OneItem.id
                    }
                }
            }.padding(.all, 0)
        }
        .navigationBarTitle("華語聖經")
        .onAppear(){
            MenuArray = CA.initMenuArray(offset:int_date)
        }
    }
    
    @ViewBuilder
    func chooseDestination() -> some View {
        switch int_Selected {
            case 1: C02bibleMenu(indexBook:1)
            case 2: C02bibleMenu(indexBook:2)
            case 3: C02bibleMenu(indexBook:3)
            case 4: C02bibleMenu(indexBook:4)
            case 5: C02bibleMenu(indexBook:5)
            case 6: C02bibleMenu(indexBook:6)
            default: EmptyView()
        }
    }
    
}

struct C01mainMenu_Previews: PreviewProvider {
    static var previews: some View {
        C01mainMenu()
    }
}
