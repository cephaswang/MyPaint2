package org.shar35.getwebview;

// Android WebView - Binding JavaScript code to Android code
// https://www.youtube.com/watch?v=9RwJeocTgJg

import android.app.Activity;
import android.os.Bundle;
import android.util.Log;
import android.view.KeyEvent;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private WebView myWebView;

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        myWebView = (WebView) findViewById(R.id.webView);
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        myWebView.setWebViewClient( new WebViewClient() );
        myWebView.addJavascriptInterface(new WebAppInterface(this ), "Android");
        myWebView.loadUrl("https://udn.com/");

        myWebView.setWebViewClient(
                new WebViewClient(){

                    public void onLoadResource(WebView view, String url) {
                         Log.v(TAG,"onLoadResource:" + url);
                    }

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        Log.v(TAG, "onPageFinished:" + url);

                        myWebView.loadUrl("javascript:(function() { "
                                + "window.Android.setHtml('<html>'+"
                                + "document.getElementsByTagName('html')[0].innerHTML+'</html>');})();");
                    }

                });

    }



}