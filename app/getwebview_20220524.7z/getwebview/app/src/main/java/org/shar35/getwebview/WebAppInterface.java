package org.shar35.getwebview;

import android.content.Context;
import android.webkit.JavascriptInterface;
import android.widget.Toast;

public class WebAppInterface {
    private Context context;


    public WebAppInterface(Context context){
        this.context = context;
    }


    @JavascriptInterface
    public void setHtml(String message){
        Toast.makeText(context,message,Toast.LENGTH_LONG).show();
    }


}
