fun main(){
	var highScores = listOf( 4000, 2000, 10200, 12000, 9030)
	println(highScores)
	highScores = highScores.sortedDescending()
	println(highScores)
}

/*

System.out: [4000, 2000, 10200, 12000, 9030]
System.out: [12000, 10200, 9030, 4000, 2000]

*/