Both cost and  @JvmField create constants. What can @JvmField do that const cannot?

class Styles {
    companion object {
        const val COLOR = "Blue"
        @JvmField val SIZE="Really big"
    }
}

const works only with strings and primitives. JvaField does not have that restriction.
out const is not.
JvaField is compatible with Java, @@@@@
JvaField is always inlined for faster code.
JvaField works as a top-level variable, but const works only in a class.

https://www.youtube.com/watch?v=HmE3lpSmXEY
JvmStatic, JvmOverloads, and JvmField in Kotlin

