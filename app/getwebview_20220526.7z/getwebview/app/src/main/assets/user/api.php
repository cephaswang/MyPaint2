<?php

// 192.168.0.115/api.php?mode=token&type=android&xid=17e84a32e7662016c3fe8ce84e6c5073&token=xxxxxxxxxxxxxxxxxxxxxx

// 192.168.0.115/api.php?mode=token&type=android&is_uu=nice&token=xxxxxxxxxxxxxxxxxxxxxx
session_start();

echo $_SESSION['token'];
echo "<br>";
echo $_SESSION['type'];
echo "<br>";
echo $_SESSION['token_time'];


$mysqli = new mysqli("localhost", "root", "abcd1234", "members");

$mode  = $_GET["mode"];

if ( $mode == "log_in" ){

	$is_uu = $_GET["is_uu"];

	// 192.168.0.115/api.php?mode=log_in&is_uu=nice

	$query = "SELECT * FROM `members` where `username` = '".$_GET["is_uu"]."' ";


	/*
	PHP 页面跳转的三种方式
	https://www.jianshu.com/p/8fa51d7fbb7e
	*/

	$result = $mysqli->query($query);
	while ($row = $result->fetch_row()) {
		//echo "<html>";
		$url = "/page/app_home.php?is_uu=".$is_uu;
		echo "<script language='javascript' type='text/javascript'>";
		echo "window.location.href='$url'";
		echo "</script>";
		//echo "<body>";
		print($query);
		printf("<br>\r\n%s (%s)\n", $row[0], $row[1]);
		echo "</body>";
		echo "</html>";
	}
	
	$row_cnt = $result->num_rows;
	
	if ( $row_cnt < 1 ){
		echo "<h1>ERROR</h1>";
		echo "<button onclick=\"goBack()\"><h1>Go Back</h1></button>";
		echo "<script>";
		echo "function goBack() {";
		echo "window.history.back();";
		echo "}";
		echo "</script>";

	}
}


if ( $mode == "token" ){
	$type  = $_GET["type"];
	$token = $_GET["token"];

	$query = "update `members` set `type` = '".$_GET["type"]."' , `date_time` = '".date(DATE_RFC2822)."', `token` = '".
	$_GET["token"]."', `REMOTE_ADDR` = '".$_SERVER['REMOTE_ADDR']."' where `username` = '".$_GET["is_uu"]."' ";
	print("<br>\r\n".$query);
	$result = $mysqli->query($query);
}	