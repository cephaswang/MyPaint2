<?php
date_default_timezone_set('Asia/Taipei');

// app/api.php?mode=token&type=android&token=token_info
// app/api.php?mode=token&type=ios&token=token_info

session_start();

$_SESSION['token']      = $_GET["token"];
$_SESSION['type']       = $_GET["type"];
$_SESSION['token_time'] = date("h:i:sa");

$myfile = fopen("newfile.txt", "w") or die("Unable to open file!");



$txt = "The time is " . date("h:i:sa")."\n";

fwrite($myfile, $txt);
fwrite($myfile, $_GET["token"]);
$txt = "\n\n";
fwrite($myfile, $txt);
fwrite($myfile, $_GET["type"]);
fclose($myfile);
?>