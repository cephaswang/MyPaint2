安卓手機傳入信令到網頁0514
https://www.youtube.com/watch?v=5d0IQjRFNq0


https://www.youtube.com/watch?v=M7z2MFoI6MQ


/usr/local/opt/php@7.4/bin


Send Android Push Notifications Using Firebase Cloud Messaging | Android Studio (With Source Code)