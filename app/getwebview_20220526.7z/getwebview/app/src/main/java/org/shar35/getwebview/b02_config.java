package org.shar35.getwebview;



import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Context;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.graphics.Color;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.BaseAdapter;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.LinearLayout;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;
import com.dd.plist.NSArray;




public class b02_config extends AppCompatActivity {

    static NSArrayAdapter adapter;
    static NSArrayIndexAdapter index_adater;

    ListView listView_Books, listView_Index;
    LinearLayout indexLayout;

    private DBOpenHelper DBhelper = null;
    private SQLiteDatabase db = null;
    private static final int dbVERSION = 1;
    private static final String dbDBNAME = "b02config.db";

    ImageButton Button_empty, Button_save;

    EditText EditText_keyword, EditText_address;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b02_config);

        DBhelper = new DBOpenHelper(b02_config.this, dbDBNAME, null, dbVERSION);

        listView_Books = (ListView) findViewById(R.id.BookList);
        listView_Index = (ListView) findViewById(R.id.indexList);
      //  indexLayout    = findViewById(R.id.indexLayout);
        Button_empty   = (ImageButton) findViewById(R.id.Button_empty);
        Button_save    = (ImageButton) findViewById(R.id.Button_save);

        EditText_keyword = (EditText) findViewById(R.id.EditText_keyword);
        EditText_address = (EditText) findViewById(R.id.EditText_address);

        Button_empty.setOnClickListener(mCorkyListener);
        Button_save.setOnClickListener(mCorkyListener);

        String address = getSharedPreferences("GetWebView", MODE_PRIVATE).getString("EditText_address", "");
        String keyword = getSharedPreferences("GetWebView", MODE_PRIVATE).getString("EditText_keyword", "");
        EditText_keyword.setText(keyword);
        EditText_address.setText(address);


        db = DBhelper.getWritableDatabase();

        String b02SQL = "select count(`id`) from history";
        int MaxID = 1;
        Cursor cursor =  db.rawQuery(b02SQL,null);
        while (cursor.moveToNext()) {
            MaxID = cursor.getInt(0);
        }
        NSArray TotalRecords = new NSArray(MaxID);

        b02SQL = "select id, web_address, is_src from history order by id desc ";
        int Ux = 0;
        cursor =  db.rawQuery(b02SQL,null);
        while (cursor.moveToNext()) {
            NSArray oneItem = new NSArray(3);
            oneItem.setValue(0, cursor.getInt(0) );
            oneItem.setValue(1, cursor.getString(1) );
            oneItem.setValue(2, cursor.getInt(2) );
            TotalRecords.setValue(Ux++, oneItem);
        }
        db.close();

        adapter = new NSArrayAdapter(this , TotalRecords);

        listView_Books.setAdapter(adapter);
        listView_Books.setOnItemClickListener(
                (adapterView, view, i, l) -> {
                    // TextView plistfileU = view.findViewById(R.id.plistfile);
                    // System.out.println(plistfileU.getText().toString());

                    /*
                    Intent intentU = new Intent();
                    intentU.setClass( C03oneBookSet.this,b05player.class);
                    intentU.putExtra("PlayIndexID", String.valueOf(i) );
                    startActivity(intentU);
                    */

                }
        );

        System.out.println( TotalRecords.count() );

        index_adater =  new NSArrayIndexAdapter(this , TotalRecords);
        listView_Index.setAdapter(index_adater);

        if (TotalRecords.count() < 5) {
           // indexLayout.setVisibility(View.GONE);
        }

        listView_Index.setOnItemClickListener(
                (adapterView, view, i, l) -> {
                    TextView plistfileU = view.findViewById(R.id.plistfile);
                    // System.out.println(plistfileU.getText().toString());
                    int Pos = Integer.valueOf(plistfileU.getText().toString());
                    listView_Books.setSelection(Pos - 1);
                }
        );


    }

    private View.OnClickListener mCorkyListener = new View.OnClickListener() {
        public void onClick(View v) {
            switch (v.getId() /*to get clicked view id**/) {

                case R.id.Button_empty:
                    db = DBhelper.getWritableDatabase();
                    String b02SQL = "DELETE FROM history ";
                    db.execSQL(b02SQL);
                    b02SQL = "UPDATE sqlite_sequence SET seq = 0 WHERE name = 'history' ";
                    db.execSQL(b02SQL);
                    db.close();

                    Toast.makeText(b02_config.this, "清除記錄表", Toast.LENGTH_LONG).show();

                    break;

                case R.id.Button_save:
                    Toast.makeText(b02_config.this, "保存設定值", Toast.LENGTH_LONG).show();

                    SharedPreferences pref = getSharedPreferences("GetWebView", MODE_PRIVATE);
                    pref.edit()
                            .putString("EditText_address", EditText_address.getText().toString())
                            .putString("EditText_keyword", EditText_keyword.getText().toString())
                            .commit();

                    break;

            }
        }
    };

    public static class ViewHolder {
        public TextView BookName;
        public TextView plistfile;
    }



    // https://stackoverflow.com/questions/9440138/how-to-convert-jsonarray-to-listview
    public class NSArrayAdapter  extends BaseAdapter  {

        NSArray data;
        Context context;
        String [] keyArray;

        public NSArrayAdapter(Context context, NSArray data) {
            super();
            this.context=context;
            this.data = data;
            //   keyArray = data.allKeys();
            //   Arrays.sort(keyArray);
        }

        @Override
        public int getCount() {
            return data.count();
        }

        @Override
        public Object getItem(int i) {
            return data.objectAtIndex(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @Override
        public View getView(int i, View convertView, ViewGroup parent) {
            ViewHolder holder  = null;
            if ( convertView == null ) {
                LayoutInflater inflater=getLayoutInflater();
                convertView = inflater.inflate( R.layout.rowbookname, parent , false);
                holder = new ViewHolder();
                holder.BookName   =(TextView)convertView.findViewById( R.id.BookName);
                holder.plistfile  =(TextView)convertView.findViewById( R.id.plistfile);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder)convertView.getTag();
            }
            NSArray oneBook = (NSArray)data.objectAtIndex(i);
            holder.BookName.setText(  oneBook.objectAtIndex(0).toString() );
            holder.plistfile.setText( oneBook.objectAtIndex(1).toString() );

            String data_info = oneBook.objectAtIndex(1).toString();

            if ( data_info.contains( EditText_address.getText().toString() ) ){
                holder.BookName.setBackgroundColor(Color.parseColor("#FF420E"));
            } else {
                holder.BookName.setBackgroundColor(Color.parseColor("#484848"));
            }


            return convertView;
        }

    }

    public class NSArrayIndexAdapter  extends BaseAdapter  {

        NSArray data;
        Context context;
        Integer step = 20;
        Integer myCount = 0;

        public NSArrayIndexAdapter(Context context, NSArray data) {
            super();
            this.context = context;
            this.data    = data;
            //   keyArray = data.allKeys();
            //   Arrays.sort(keyArray);
        }

        @Override
        public int getCount() {
            myCount = (int)( data.count() / step + 1);
            // System.out.println( String.format("Count: %d",myCount));
            return (int)(  myCount );
        }

        @Override
        public Object getItem(int i) {
            return data.objectAtIndex(i);
        }

        @Override
        public long getItemId(int i) {
            return i;
        }

        @SuppressLint("Range")
        @Override
        public View getView(int i, View convertView, ViewGroup parent) {
            ViewHolder holder  = null;
            if ( convertView == null ) {
                LayoutInflater inflater=getLayoutInflater();
                convertView = inflater.inflate( R.layout.rowbookindex, parent , false);
                holder = new ViewHolder();
                holder.BookName   =(TextView)convertView.findViewById( R.id.BookName);
                holder.plistfile  =(TextView)convertView.findViewById( R.id.plistfile);
                convertView.setTag(holder);
            } else {
                holder = (ViewHolder)convertView.getTag();
            }

            int Bx = i * step;
            if (Bx == 0){
                Bx = 1;
            }

            // int Cx = myCount - Bx;

            holder.BookName.setText( String.valueOf( Bx ) );
            holder.plistfile.setText( String.valueOf(Bx) );
            holder.BookName.setTextColor( Color.GREEN );
            holder.BookName.setTextAlignment(View.TEXT_ALIGNMENT_TEXT_END);
            holder.BookName.setTextSize(16);
            return convertView;
        }

    }



}