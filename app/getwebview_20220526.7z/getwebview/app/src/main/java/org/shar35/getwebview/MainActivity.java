package org.shar35.getwebview;

// Android WebView - Binding JavaScript code to Android code
// https://www.youtube.com/watch?v=9RwJeocTgJg

import android.app.Activity;
import android.content.Intent;
import android.content.res.AssetFileDescriptor;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.media.MediaPlayer;
import android.os.Bundle;
import android.os.Environment;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JavascriptInterface;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import java.io.File;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private WebView myWebView;
    MediaPlayer m;

    private ImageButton Button_save, Button_open, Button_config;
    private EditText EditText_address;

    private DBOpenHelper DBhelper = null;
    private SQLiteDatabase db = null;
    private static final int dbVERSION = 1;
    private static final String dbDBNAME = "b02config.db";

    @Override protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);


        String sotrePATH = this.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS).getAbsolutePath().toString();
        File PREpath =  new File( sotrePATH );
        PREpath.mkdirs();

        DBhelper = new DBOpenHelper(MainActivity.this, dbDBNAME, null, dbVERSION);

        String web_address = "https://www.member.5.ibiz.tw/";

        /*
        db = DBhelper.getWritableDatabase();
        String b02SQL = "select web_address from address";
        Cursor cursor =  db.rawQuery(b02SQL,null);
        while (cursor.moveToNext()) {
            //web_address = cursor.getString(0);
        }
        db.close();
        */

        Button_config    = (ImageButton) findViewById(R.id.Button_config);
        Button_open      = (ImageButton) findViewById(R.id.Button_open);
        Button_save      = (ImageButton) findViewById(R.id.Button_save);
        EditText_address = (EditText) findViewById(R.id.EditText_address);

        EditText_address.setText( web_address );

        myWebView = (WebView) findViewById(R.id.webView);
        WebSettings webSettings = myWebView.getSettings();
        webSettings.setJavaScriptEnabled(true);

        myWebView.setWebViewClient( new WebViewClient() );
        myWebView.addJavascriptInterface(new WebAppInterface(this ), "Android");
        myWebView.loadUrl( web_address );

        myWebView.setWebViewClient(
                new WebViewClient(){

                    public void onLoadResource(WebView view, String url) {

                        String address = getSharedPreferences("GetWebView", MainActivity.MODE_PRIVATE).getString("EditText_address", "");

                        if ( address.length() > 3 && url.contains(address)){
                            playBeep();
                        }

                        Log.v(TAG,"onLoadResource:" + url);
                        db = DBhelper.getWritableDatabase();
                        String b02SQL = "INSERT INTO history ( web_address ,  store_path , is_src ) VALUES ( '" + url + "' , '1'  , '1' );";
                        db.execSQL(b02SQL);
                        db.close();
                        // Log.v(TAG,"b02SQL:" + b02SQL);
                    }

                    @Override
                    public void onPageFinished(WebView view, String url) {
                        Log.v(TAG, "onPageFinished:" + url);

                        myWebView.loadUrl("javascript:(function() { "
                                + "window.Android.setHtml('<html>'+"
                                + "document.getElementsByTagName('html')[0].innerHTML+'</html>', '" + url + "');})();");

                    }

                });

        Button_save.setOnClickListener(mCorkyListener);
        Button_open.setOnClickListener(mCorkyListener);
        Button_config.setOnClickListener(mCorkyListener);

    }


    private View.OnClickListener mCorkyListener = new View.OnClickListener() {
        public void onClick(View v) {
            switch (v.getId() /*to get clicked view id**/) {
                case R.id.Button_open:
                   // System.out.println( EditText_address.getText().toString() );
                    myWebView.loadUrl ( EditText_address.getText().toString() );

                    /*
                    String b02SQL = "INSERT OR REPLACE INTO address ( web_address ) VALUES ( '" + EditText_address.getText().toString() + "' )";
                    System.out.println( b02SQL );
                    db = DBhelper.getWritableDatabase();
                    db.execSQL(b02SQL);
                    db.close();
                    */

                    Toast.makeText(MainActivity.this, "開啟網頁", Toast.LENGTH_LONG).show();

                    break;

                case R.id.Button_save:
                    Toast.makeText(MainActivity.this, "保存網頁", Toast.LENGTH_LONG).show();

                    myWebView.loadUrl("javascript:(function() { "
                            + "window.Android.setHtml('<html>'+"
                            + "document.getElementsByTagName('html')[0].innerHTML+'</html>', '" + EditText_address.getText() +"');})();");
                    break;

                case R.id.Button_config:

                    Toast.makeText(MainActivity.this, "設定", Toast.LENGTH_LONG).show();

                    Intent intent = new Intent();
                    intent.setClass( MainActivity.this,b02_config.class);
                    startActivity(intent);

                    break;
            }
        }
    };

    public void playBeep() {
        try {
            m = new MediaPlayer();

            AssetFileDescriptor descriptor = this.getAssets().openFd("beep.mp3");
            m.setDataSource(descriptor.getFileDescriptor(), descriptor.getStartOffset(), descriptor.getLength());
            descriptor.close();

            m.prepare();
            m.setVolume(1f, 1f);
            m.setLooping(false);
            m.start();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}