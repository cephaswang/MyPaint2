package org.shar35.getwebview;


import android.content.Context;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteDatabase.CursorFactory;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Environment;

import java.io.File;


public class DBOpenHelper extends SQLiteOpenHelper
{

    public DBOpenHelper(Context context, String DBNAME, CursorFactory factory, int VERSION)
    {
        super(context,  context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) + "/" +DBNAME, factory, VERSION);
        System.out.println( context.getExternalFilesDir(Environment.DIRECTORY_DOWNLOADS) + "/" +DBNAME );
    }

    @Override
    public void onCreate(SQLiteDatabase db)
    {
        // 記錄設定值，FIELDS
        String b02SQL = "CREATE TABLE 'history' (  'id' INTEGER UNIQUE, 'web_address' TEXT, 'store_path' TEXT, 'is_src' INTEGER, PRIMARY KEY('id' AUTOINCREMENT) )";
        db.execSQL(b02SQL);

        b02SQL = "CREATE TABLE 'address' (  'web_address' TEXT )";
        db.execSQL(b02SQL);

        System.out.println("建立資料表:" + b02SQL);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion)
    {
//		Log.i("StudentDAOTest", "UpGrade!");
//		String tempTable = "temp_student";
//		db.execSQL("alter table "+STUDENT +" rename to "+tempTable);
//		db.execSQL("create table "+STUDENT+" (sid integer primary key,name varchar(20),age integer,sex varchar(4))");
//		String sql = "insert into "+STUDENT+" (name,age,sex) select name,age,'男' from "+tempTable;
//		db.execSQL(sql);
    }
}