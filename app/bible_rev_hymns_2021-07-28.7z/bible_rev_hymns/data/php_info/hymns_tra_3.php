<?php
/**
 * Examples for how to use CFPropertyList
 * Read an XML PropertyList
 * @package plist
 * @subpackage plist.examples
 */

// just in case...
error_reporting( E_ALL );
ini_set( 'display_errors', 'on' );

/**
 * Require CFPropertyList
 */
require_once(dirname(__FILE__).'/CFPropertyList.php');


/*
 * create a new CFPropertyList instance which loads the sample.plist on construct.
 * since we know it's an XML file, we can skip format-determination
 */
$plist = new CFPropertyList( dirname(__FILE__).'/hymns_tra.plist', CFPropertyList::FORMAT_XML );

/*
 * retrieve the array structure of sample.plist and dump to stdout
 */

echo '<pre>';
//var_dump( $plist->toArray() );
//echo '</pre>';
// echo "md mp3\r\n";

$file = 6900;
foreach ( $plist->toArray() as  $key1 => $value1){

	$file += 1;
	echo $file;
	echo "#";
	list($_,$key1_var) = explode(",",$key1);
	echo $key1_var;
	echo "\r\n";

	foreach ( $value1 as  $key2 => $value2){
/*
		echo $file+1;
		echo "#";
		echo $key2;
		echo "\r\n";
		$file += 1;
*/
		foreach ( $value2 as  $key3 => $value3){
			//echo $key3;
			//echo "\r\n";
			/*
			echo $value3[0];
			echo "\r\n";
			echo $value3[1];
			echo "\r\n";
			echo $value3[2];
			echo "\r\n";
			ezoecloud.twgbr.org
			*/

			//$url_address = str_replace("SERVERIP2", "ezoecloud.twgbr.org", $value3[1]);
			//list($_,$url_address) = explode(",",$url_address);

			//list($_,$name) = explode(",",$value3[2]);
			//list($dir,$file) = explode("_",$name);
			//if ($file == 1){
			//echo "md ".sprintf("%02d",$dir)."\r\n";
			//}

			//$file += 1;

			/*
			list($_,$name) = explode(",",$value3[0]);
			$file += 1;
			echo sprintf("%03d,",$file).$name;
			echo "\r\n";
			*/
		}
	}

}

?>