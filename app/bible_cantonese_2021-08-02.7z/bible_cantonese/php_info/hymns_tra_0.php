<?php

//phpinfo();


$str = "775,776,777,779,780,786,788,792,796,801,802,805,807,823,843,851,867,879,903,927,943,959,976";

$str_array = explode (",",$str);

foreach ($str_array as &$value) {
    echo ($value+1).",";
}
