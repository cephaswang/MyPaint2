package com.chinalwb.are.spans;

import android.text.style.SuperscriptSpan;

/**
 * Created by wliu on 2018/4/3.
 */

public class AreSuperscriptSpan extends SuperscriptSpan {
}
