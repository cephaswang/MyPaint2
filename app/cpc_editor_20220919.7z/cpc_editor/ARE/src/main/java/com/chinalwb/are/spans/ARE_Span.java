package com.chinalwb.are.spans;

/**
 * Created by wliu on 2018/2/11.
 */

public interface ARE_Span {
    public String getHtml();
}
