//
//  AudioPlayerApp.swift
//  AudioPlayer WatchKit Extension
//
//  Created by admin on 2022/4/10.
//

import SwiftUI
import WatchKit
import AVKit
import AVFoundation



@main



struct AudioPlayerApp: App {
   // static let previewPlayer: AVAudioPlayer = AVAudioPlayer()
    var body: some Scene {
        WindowGroup {
            NavigationView {
                Home()
              //  C05audioPlayer()
               // C05audioPlayer()
              //  AudioPlayerControlsView(player: AudioPlayerApp.previewPlayer)
            }
        }
    }
}
