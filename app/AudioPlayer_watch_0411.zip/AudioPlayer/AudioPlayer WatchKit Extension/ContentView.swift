//
//  ContentView.swift
//  TestForSOQuestion
//
// https://stackoverflow.com/questions/70498732/create-audio-player-cell-with-slider-in-swiftui



//
//  ContentView.swift
//  TestForSOQuestion
//

import SwiftUI
import WatchKit
import AVKit
import AVFoundation
import Combine


class PlayerTimeObserver: ObservableObject {
  let player: AVAudioPlayer
  init(player: AVAudioPlayer) {
    self.player = player
  }
  
  func pause(_ flag: Bool) {}
}

class PlayerDurationObserver {
  let player: AVAudioPlayer
  
  init(player: AVAudioPlayer) {
    self.player = player
  }
}

class PlayerItemObserver {
  let player: AVAudioPlayer
  init(player: AVAudioPlayer) {
    self.player = player
  }
}


struct Audiomessage : Identifiable {
  var id: UUID
  var url : String
  var isPlaying : Bool
}

let player = AVAudioPlayer()

struct ContentView: View {
  private let items = [ Audiomessage(id: UUID(), url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3", isPlaying: false),
              Audiomessage(id: UUID(), url: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3", isPlaying: false)]
  
  var body: some View {
    VStack{
      LazyVStack {
          /*
        ForEach(items) { reason in
          AudioPlayerControlsView(player: player ).onTapGesture {
            guard let url = URL(string: reason.url) else {
              return
            }
            player =  try AVAudioPlayer(contentsOf: url)
            player?.prepareToPlay()
            player?.play()
              
          }

        }*/
      }
      .padding(.bottom,37)
      .padding()
    }
    .padding(.horizontal,10)
  }
}

struct ContentView_Previews: PreviewProvider {
    static var previews: some View {
        ContentView()
    }
}

