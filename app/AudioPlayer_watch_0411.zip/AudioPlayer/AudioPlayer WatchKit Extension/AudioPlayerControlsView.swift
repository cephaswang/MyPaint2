//  AudioPlayerControlsView.swift
//  TestForSOQuestion
//
//
// https://stackoverflow.com/questions/70498732/create-audio-player-cell-with-slider-in-swiftui

// https://codewithchris.com/avaudioplayer-tutorial/

import SwiftUI
import Combine
import WatchKit
import AVKit
import AVFoundation

enum Utility {
  static func formatSecondsToHMS(_ seconds: TimeInterval) -> String {
    let secondsInt:Int = Int(seconds.rounded(.towardZero))
    
    let dh: Int = (secondsInt/3600)
    let dm: Int = (secondsInt - (dh*3600))/60
    let ds: Int = secondsInt - (dh*3600) - (dm*60)
    
    let hs = "\(dh > 0 ? "\(dh):" : "")"
    let ms = "\(dm<10 ? "0" : "")\(dm):"
    let s = "\(ds<10 ? "0" : "")\(ds)"
    
    return hs + ms + s
  }
}

struct AudioPlayerControlsView: View {

  private enum PlaybackState: Int {
    case waitingForSelection
    case buffering
    case playing
  }
  
  @State private var url:URL?
    
  @State var player: AVAudioPlayer

  @State private var C1:String = "00:00"
  @State private var C2:String = "00:00"
  @State private var currentTime: TimeInterval = 0
  @State private var currentDuration: TimeInterval = 0
  @State private var state = PlaybackState.waitingForSelection
  
  var body: some View {
    VStack {
      if state == .waitingForSelection {
        Text("Select a song below")
      } else if state == .buffering {
        Text("Buffering...")
      } else {
        Text("Great choice!")
      }
           
      Slider(value: $currentTime,
           in: 0...currentDuration,
           onEditingChanged: sliderEditingChanged,
             minimumValueLabel: Text("\(C1)"),
             maximumValueLabel: Text("\(C2)")) {
          // I have no idea in what scenario this View is shown...
          Text("seek/progress slider")
      }
    //  .disabled(state != .playing)
      
    }
    .padding()
    .onAppear(){
        
            
        Timer.scheduledTimer(withTimeInterval: 10, repeats: true) { (_) in
            if ( !self.player.isPlaying ){
                
                do {
                    guard let url = Bundle.main.url(forResource: "demo", withExtension: "mp3" ) else {
                        return
                    }
                    
                    self.player = try AVAudioPlayer(contentsOf: url)
                    self.player.prepareToPlay()
                    self.player.play()
                } catch let error as NSError {
                    print(error.debugDescription)
                }
            }
            
            /*
            if ( self.player.isPlaying ) {
                currentTime     = self.player.currentTime
                currentDuration = self.player.duration
                C1 = Utility.formatSecondsToHMS(currentTime)
                C2 = Utility.formatSecondsToHMS(currentDuration)
                print(C1)
                state = .playing
            } else {
                state = .waitingForSelection
            }
            */
            print("00--00--00")

        }
    }

  }
    
// MARK: - updateProgress
    private func updateProgress(){
       // imageBar.setHidden(false)
       // updateProgressSlider(info: -1)
    }
    
  
  // MARK: Private functions
  private func sliderEditingChanged(editingStarted: Bool) {
    if editingStarted {
      // Tell the PlayerTimeObserver to stop publishing updates while the user is interacting
      // with the slider (otherwise it would keep jumping from where they've moved it to, back
      // to where the player is currently at)
     // timeObserver.pause(true)
    }
    else {
      // Editing finished, start the seek
      state = .buffering
        _ = CMTime(seconds: currentTime,
                  preferredTimescale: 600)
      //  player.currentTime = currentTime

      //  self.timeObserver.pause(false)
        self.state = .playing
      
    }
  }
}

struct AudioPlayerControlsView_Previews: PreviewProvider {
  static let previewPlayer: AVAudioPlayer = AVAudioPlayer()
    static var previews: some View {
        AudioPlayerControlsView(player: previewPlayer)
    }
}
