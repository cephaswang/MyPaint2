//
//  C05download.swift
//  AudioPlayer WatchKit Extension
//
//  Created by admin on 2022/4/11.
//

// https://www.youtube.com/watch?v=OPLlRd54mnk

import SwiftUI
import Foundation

class C05download:ObservableObject{
    
    @Published var downloadURL:URL!
    @Published var alertMsg:String = ""
    @Published var showAlert:Bool = false
    
    func startDownload(urlString: String){
        guard let VaildURL = URL(string: urlString) else{
            self.reportError(error: "Invalid URL !!!")
            return
        }
        
        
    }
    
    func reportError(error:String){
        alertMsg = error
        showAlert.toggle()
    }
    
}
