//
//  C05downPage.swift
//  AudioPlayer WatchKit Extension
//
//  Created by admin on 2022/4/11.
// https://www.youtube.com/watch?v=OPLlRd54mnk

import SwiftUI

struct C05downPage: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct C05downPage_Previews: PreviewProvider {
    static var previews: some View {
        C05downPage()
    }
}

let url = "http://bible.cephas.tw/privacy.html"
