//
//  C05audioPlayer.swift
//  AudioPlayer WatchKit Extension
//
//  Created by admin on 2022/4/10.
//

import Foundation
import AVFoundation
import MediaPlayer

class C05audio_info {
    var player:AVAudioPlayer?
    
    func initPlayer(url:URL){
        do {
            // AVAudioPlayer: How to Change the Playback Speed of Audio?
            // https://stackoverflow.com/questions/2350657/avaudioplayer-how-to-change-the-playback-speed-of-audio
            
            self.player = try AVAudioPlayer(contentsOf: url)
            self.player?.enableRate = true
            self.player?.prepareToPlay()
        } catch let error as NSError {
            print(error.debugDescription)
        }
    }
    
    func Play(){
        self.player?.play()
    }
    func Pause(){
        self.player?.pause()
    }
    
    func isPlaying()->Bool{
        return ((self.player?.isPlaying) != nil)
    }
    
    func setRate(rate:Float){
        self.player?.rate = rate
    }
}
