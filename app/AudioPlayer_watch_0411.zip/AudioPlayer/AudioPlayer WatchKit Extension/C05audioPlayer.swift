//
//  C05audioPlayer.swift
//  AudioPlayer WatchKit Extension
//
//  Created by admin on 2022/4/10.
//

import SwiftUI

struct C05audioPlayer: View {
    
    @State var CA:C05audio_info = C05audio_info()
    @State var isPlay:String = "play"
    
    var body: some View {
        Text(isPlay)
            .onTapGesture {
                print(1)
                if ( isPlay == "play" ){
                    if( !CA.isPlaying() ){
                        if let url = Bundle.main.url(forResource: "01000", withExtension: "mp3"){
                            CA.initPlayer(url: url)
                        } else {
                            return
                        }
                    }

                    CA.setRate(rate: 1)
                    CA.Play()
                    
                    isPlay = "pause"
                } else {
                    CA.Pause()
                    isPlay = "play"
                }
            }
    }
}

struct C05audioPlayer_Previews: PreviewProvider {
    static var previews: some View {
        C05audioPlayer()
    }
}
