//
//  DownloadTaskModel.swift
//  AudioPlayer WatchKit Extension
//
//  Created by admin on 2022/4/11.
// SwiftUI 2.0 URL Session Download Task With Document Interaction Controller - SwiftUI Tutorials
// https://www.youtube.com/watch?v=OPLlRd54mnk

import SwiftUI
import WatchKit

class DownloadTaskModel: NSObject, ObservableObject , URLSessionDownloadDelegate, URLSessionDelegate {

    @Published var downloadURL:URL!
    @Published var alertMsg:String = ""
    @Published var showAlert:Bool = false
    @Published var DownloadTaskSession : URLSessionDownloadTask!
    @Published var downloadProgress:CGFloat = 0
    @Published var showDownloadProgress:Bool = false
    
    @State     var CA:C05audio_info = C05audio_info()

    var session:URLSession? = nil
    var strStoreName:String? = nil
    @Published  var playFileName:String? = nil
    var IS_downOnly:Bool = false
    
    func startDownload(urlString: String , downOnly:Bool){
        guard URL(string: urlString) != nil else{
            self.reportError(error: "Invalid URL !!!")
            return
        }
        
        let nameArray:[String] = urlString.components(separatedBy: "/")
        self.strStoreName = "\(nameArray[nameArray.count-2])/\(nameArray[nameArray.count-1])"

        let DocumentDirURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = DocumentDirURL.appendingPathComponent(strStoreName!)
        print ("fileURL.path:\(fileURL.path)")

        // Create book Dir
        let dataPath = DocumentDirURL.appendingPathComponent((nameArray[nameArray.count-2]))
        // print ("dataPath.path:\(dataPath.path)")
        if !FileManager.default.fileExists(atPath: dataPath.path) {
            do {
                try FileManager.default.createDirectory(atPath: dataPath.path, withIntermediateDirectories: true, attributes: nil)
            } catch {
                print(error.localizedDescription);
            }
        }

        if FileManager.default.fileExists(atPath: fileURL.path){
            self.playFileName = fileURL.path
            if let url = URL(string: self.playFileName! ){
                CA.initPlayer(url: url)
            } else {
                return
            }
            // Timer.scheduledTimer(timeInterval: 0.5 , target: self, selector: #selector(self.startPlay), userInfo: nil, repeats: false)
            return
        } else {
            print ("no")
            downloadProgress = 0
            withAnimation { showDownloadProgress = true }
            
            IS_downOnly = downOnly

            self.session = URLSession(configuration: .default, delegate: self, delegateQueue: nil)
            DownloadTaskSession = self.session!.downloadTask(with: URL(string: urlString)!)
            DownloadTaskSession.resume()
        }
    }
    
    func reportError(error:String){
        alertMsg = error
        showAlert.toggle()
    }

    
    
    func urlSession(_ session: URLSession, task: URLSessionTask, didCompleteWithError error: Error?) {
        DispatchQueue.main.async { [self] in
            if let error = error {
                withAnimation { self.showDownloadProgress = false }
                self.reportError(error: error.localizedDescription)
                return
            }
        }
    }

    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didFinishDownloadingTo location: URL) {
        print(location)

        do {
            if let data = try? Data(contentsOf: location) {
                let DocumentDirURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
                let fileURL = DocumentDirURL.appendingPathComponent(strStoreName!)
                
                // if had file and remove
                try? FileManager.default.removeItem(at: fileURL)
                
                try data.write(to: fileURL)
                self.playFileName = fileURL.path
                print("strStoreName:\(String(describing: strStoreName))")
                
                DispatchQueue.main.async { [self] in
                    self.showDownloadProgress = false
                    /*
                    let controller = UIDocumentInteractionController(url: fileURL)
                    
                    controller.delegate = self
                    controller.presentPreview(animated: true)
                    */
                }
                
            }
        } catch let error as NSError {
            DispatchQueue.main.async { [self] in
                withAnimation { self.showDownloadProgress = false }
                self.reportError(error: error.localizedDescription)
                return
            }
        }
        
        
        
        if (IS_downOnly == true){
            return
        }

        DispatchQueue.main.async { [self] in
            if let url = URL(string: self.playFileName! ){
                CA.initPlayer(url: url)
            } else {
                return
            }
            // Timer.scheduledTimer(timeInterval: 0.5 , target: self, selector: #selector(self.startPlay), userInfo: nil, repeats: false)
        }
    
        return
    }
    
    @objc func startPlay(){
        print("startPlay")
        CA.setRate(rate: 1)
        CA.Play()
    }
    
    // 完成非同步下載
    // Save/load files in app with Swift 4 [duplicate]
    // https://stackoverflow.com/questions/48387293/save-load-files-in-app-with-swift-4
    func urlSession(_ session: URLSession, downloadTask: URLSessionDownloadTask, didWriteData bytesWritten: Int64, totalBytesWritten: Int64, totalBytesExpectedToWrite: Int64) {
       let Progress = CGFloat(totalBytesWritten ) / CGFloat(totalBytesExpectedToWrite)
        print(Progress)
        
        DispatchQueue.main.async {
            self.downloadProgress = Progress
        }
    
    }
    
    func cancelTask(){
        if let task = DownloadTaskSession,task.state == .running {
            DownloadTaskSession.cancel()
            withAnimation { self.showDownloadProgress = false }
        }
    }
    
}
