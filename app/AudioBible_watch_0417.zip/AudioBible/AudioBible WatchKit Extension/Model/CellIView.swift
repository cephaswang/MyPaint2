//
//  TableViewCell.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import Foundation

struct CellItem:Identifiable{
    var id:Int
    var name:String
    var push:String
}

struct CellAudio:Identifiable{
    var id:Int
    var name:String
    var link:String
    var file:String
}
