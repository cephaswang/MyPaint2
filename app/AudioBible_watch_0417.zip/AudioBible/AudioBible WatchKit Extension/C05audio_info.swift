//
//  C05audioPlayer.swift
//  AudioPlayer WatchKit Extension
//
//  Created by admin on 2022/4/10.
//

import SwiftUI
import Foundation
import AVFoundation
import MediaPlayer
import WatchKit

class C05audio_info : NSObject, ObservableObject{

    static var player:AVAudioPlayer?
    static var infoURL:URL?
    var gameTimer: Timer?
    @Published var downloadProgress:CGFloat = 0
    @Published var showDownloadProgress:Bool = false
    
    var initData  = CommClass()
    
    func initPlayer(url:URL){
        do {
            // AVAudioPlayer: How to Change the Playback Speed of Audio?
            // https://stackoverflow.com/questions/2350657/avaudioplayer-how-to-change-the-playback-speed-of-audio
            C05audio_info.infoURL = url
            C05audio_info.player = try AVAudioPlayer(contentsOf: url)
            C05audio_info.player?.enableRate = true
            C05audio_info.player?.prepareToPlay()
        } catch let error as NSError {
            print(error.debugDescription)
        }
    }
    
    func Play(){
        C05audio_info.player?.play()
        gameTimer = Timer.scheduledTimer(timeInterval: 2, target: self, selector: #selector(runTimedCode), userInfo: nil, repeats: true)
        withAnimation { self.showDownloadProgress = true }
    }
    
    func Stop(){
        C05audio_info.player?.stop()
        gameTimer?.invalidate()
    }
    
    func Pause(){
        C05audio_info.player?.pause()
    }
    
    @objc func runTimedCode(){
        DispatchQueue.main.async {
            self.downloadProgress = C05audio_info.player!.currentTime / C05audio_info.player!.duration
            print(self.downloadProgress)
            withAnimation { self.showDownloadProgress = true }
        }
    }
    
    func isPlaying()->Bool{
        if (C05audio_info.player?.isPlaying == true){
            return true
        }
        return false
    }
    
    func setRate(rate:Float){
        C05audio_info.player?.rate = rate
    }

}
