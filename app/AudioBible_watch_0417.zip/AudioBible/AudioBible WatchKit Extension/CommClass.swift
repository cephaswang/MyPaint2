//
//  CommClass.swift
//  AudioBible
//
//  Created by gibs on 2019/2/2.
//  Copyright © 2019 share35app. All rights reserved.
//

import Foundation
import UIKit
import WatchKit
import SQLite3

// SQLite · Swift 起步走 - GitBook
// https://itisjoe.gitbooks.io/swiftgo/content/database/sqlite.html

class CommClass {
    
    let dbInfoName : String = "config_inc.sqlite"
    let Lang_Name  : String = "bible_tamil"
    let audioServer  : String = "bible.cephas.tw"
    let fontTK_Name  : String = "InaiMathi"

    
    // https://medium.com/@mikru168/ios-%E5%8F%96%E5%BE%97%E6%96%87%E5%AD%97%E9%AB%98%E5%BA%A6%E7%9A%84%E6%96%B9%E5%BC%8F-d338893aedee
    // 利用UILabel來取得文字的高度
    // 详解UIView的frame、bounds和center属性
    // https://www.jianshu.com/p/c16c32c45862
    /*
    func getHeight(withLabelText text: String, width: CGFloat, font: UIFont) -> CGFloat {
        let label: UILabel = UILabel(frame: CGRect(x: 0, y: 0, width: width, height: CGFloat(MAXFLOAT)))
        label.numberOfLines = 0
        label.lineBreakMode = NSLineBreakMode.byWordWrapping
        label.font = font
        label.text = text
        label.sizeToFit()
        let currentHeight : CGFloat = label.frame.height
        label.removeFromSuperview()
        return currentHeight
    }
    */
    
    /*
    // Copy file with swift
    // https://stackoverflow.com/questions/48441271/copy-file-with-swift
    func secureCopyItem(at srcURL: URL, to dstURL: URL) -> Bool {
        do {
            if FileManager.default.fileExists(atPath: dstURL.path) {
                try FileManager.default.removeItem(at: dstURL)
            }
            try FileManager.default.copyItem(at: srcURL, to: dstURL)
        } catch (let error) {
            print("Cannot copy item at \(srcURL) to \(dstURL): \(error)")
            return false
        }
        return true
    }
    */
    
    func getOneDayStr(int_date:Int) ->String {
        // http://my.oschina.net/u/559156/blog/125340
        // NSDate的计算问题、日期计算、时区问题、NSTimer
        let now = Date.init()
        let tz  = NSTimeZone.default as NSTimeZone
        let seconds: Int = tz.secondsFromGMT(for: now) + 24*60*60*int_date
        let thisDay: Date = Date(timeInterval: TimeInterval(seconds) , since: now)
        var strDate: String = "\(thisDay)"
        strDate = "\(strDate.prefix(10))"
        strDate = "\(strDate.suffix(5))"
        
        return strDate
    }
    

    func getTaiSong()-> NSArray {
        
        let playArray : NSMutableArray = NSMutableArray()
        let booksDicts : NSDictionary =  getPlistDict(fileName: "tra_taiyousong", subName: "plist")
        var booksKeys : NSArray = booksDicts.allKeys as NSArray
        booksKeys = sortNSArray(srcArray: booksKeys)
               
        if booksKeys.count == 0 {
            return playArray
        }
               
        for Ux in 0 ... booksKeys.count - 1 {
            let oneMark: NSArray = booksDicts.object(forKey: booksKeys.object(at: Ux)) as! NSArray
            var strTitle:NSString = oneMark.object(at: 0) as! NSString
            strTitle = strTitle.substring(from: 3) as NSString
            var strURL:NSString =  oneMark.object(at: 1) as! NSString
            strURL = strURL.replacingOccurrences(of: "SERVERIP2", with: audioServer ) as NSString
           // let strFile:NSString = oneMark.object(at: 2) as! NSString
            // let strEng:NSString = oneMark.object(at: 5) as! NSString
            // let NewArray:NSArray = [ strTitle , strURL , strFile , strFile ]
            let NewArray:NSArray = [ strTitle , strURL ]
            playArray.add( NewArray )
        }
        
        return playArray
    }
    
    
    // getDailyBook ( fileName: "tra_daily_01" , dailyIndex: 0)
    func getMenuBook (isOldSets : Int) -> NSArray {

        // let isOldSets:Int = 1
        var bookSN:Int=0
        let fileName = "tra_books_all"
        let playArray : NSMutableArray = NSMutableArray()
        
        let booksDicts : NSDictionary =  getPlistDict(fileName: fileName, subName: "plist")
        var booksKeys : NSArray = booksDicts.allKeys as NSArray
        // 001,002,003
        booksKeys = sortNSArray(srcArray: booksKeys)

        for Px in 0 ... booksKeys.count - 1 {
            let oneSetDicts: NSDictionary = booksDicts.object(forKey: booksKeys.object(at: Px)) as! NSDictionary
            var oneSetArray: NSArray = oneSetDicts.allKeys as NSArray
            oneSetArray = sortNSArray(srcArray: oneSetArray)
            
            var OneArray:NSArray = NSArray()
            var strBook: NSString = NSString()
            
            for Ix in 0 ... oneSetArray.count - 1 {
                bookSN += 1
                
                if (isOldSets == 1){
                    if ( bookSN > 39 ){
                        continue
                    }
                } else {
                    if ( bookSN < 40 ){
                        continue
                    }
                }
                
                OneArray = oneSetDicts.object(forKey: oneSetArray.object(at: Ix)) as! NSArray
                strBook = oneSetArray.object(at: Ix) as! NSString
                strBook = strBook.substring(from: 4) as NSString
                playArray.add([ strBook , OneArray[1] ])
            }
        }
        
        return playArray as NSArray
    }
    
    
    func getOneBook ( fileName: String) -> NSArray {
        // fileName tra_book_19
        let bookDicts : NSDictionary =  getPlistDict(fileName: fileName, subName: "")
        var bookKeys : NSArray = bookDicts.allKeys as NSArray
        // 001,002,003
        bookKeys = sortNSArray(srcArray: bookKeys)
        let playArray : NSMutableArray = NSMutableArray()
        var FiveArray : NSArray =  NSArray()
        var OneArray : NSArray =  NSArray()
        var strChap: NSString = NSString()
        var strURL: NSString = NSString()
        var strStore: NSString = NSString()
        for Ux in 0 ... bookKeys.count - 1 {
            FiveArray = bookDicts.object(forKey: bookKeys[Ux]) as! NSArray
            for Jx in 0 ... FiveArray.count - 1 {
                OneArray = FiveArray.object(at: Jx) as! NSArray
                strURL = OneArray[1] as! NSString
                strURL = strURL.substring(from: 4) as NSString
                strURL = strURL.replacingOccurrences(of: "SERVERIP2", with: audioServer ) as NSString
        
                strChap = OneArray[0] as! NSString
                strChap = strChap.substring(from: 4) as NSString
                
                strStore = OneArray[2] as! NSString
                strStore = strStore.substring(from: 4) as NSString
                      
                OneArray = [ strChap, strURL , strStore, OneArray[3]  ]
                // print (OneArray)
                playArray.add(OneArray)
            }
        }
        return playArray as NSArray
    }
    
    
    
    func ScreenSize () ->[CGFloat]{
        let currentDevice = WKInterfaceDevice.current()
        let bounds = currentDevice.screenBounds
        let ScreenSize = bounds.size
        return [ScreenSize.width, ScreenSize.height]
    }
    
    // #1 Swift SQLite Tutorial - Creating Database and Table
    // https://www.youtube.com/watch?v=zzhG2MlZ8WU
    func writetoDB(fieldsArray: [String]) {
        var db : OpaquePointer?
        do {
            // url(for:in:appropriateFor:create:)
            // https://developer.apple.com/documentation/foundation/filemanager/1407693-url
            let fileUrl = try FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
                ).appendingPathComponent(dbInfoName)
            
            if sqlite3_open(fileUrl.path, &db) != SQLITE_OK {
                print ("Error opening database")
                return
            }
            
            let strSQL = "CREATE TABLE IF NOT EXISTS FIELDS (FIELD_NAME TEXT PRIMARY KEY, FIELD_DATA TEXT);"
            if sqlite3_exec(db, strSQL, nil,nil,nil) != SQLITE_OK {
                print ("Error create table")
                return
            }
            
            // 寫入資料表
            let updateSQL: String = "INSERT OR REPLACE INTO FIELDS (FIELD_NAME, FIELD_DATA) VALUES ( '\(fieldsArray[0])' , '\(fieldsArray[1])' );"
            
             print ("updateSQL: \(updateSQL)")
            
            if sqlite3_exec(db, updateSQL, nil,nil,nil) != SQLITE_OK {
                print ("Error exec table")
                return
            }
            
        } catch {}
        //  print ("opening database OK!")
    }
    
    // SQLite With Swift Tutorial: Getting Started
    // https://www.raywenderlich.com/385-sqlite-with-swift-tutorial-getting-started
    func readFromDB(fieldsName: String) -> String {
        var db : OpaquePointer?
        var ANSWER : String = "0"
        do {
            // url(for:in:appropriateFor:create:)
            // https://developer.apple.com/documentation/foundation/filemanager/1407693-url
            let fileUrl = try FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
                ).appendingPathComponent(dbInfoName)
            
            if sqlite3_open(fileUrl.path, &db) != SQLITE_OK {
                print ("Error opening database")
                return ""
            }
            
            var strSQL = "CREATE TABLE IF NOT EXISTS FIELDS (FIELD_NAME TEXT PRIMARY KEY, FIELD_DATA TEXT);"
            if sqlite3_exec(db, strSQL, nil,nil,nil) != SQLITE_OK {
                print ("Error create table")
                return ""
            }
            
            strSQL = String("SELECT FIELD_NAME , FIELD_DATA FROM FIELDS WHERE FIELD_NAME = '\(fieldsName)'")
            // sqlite3_prepare_v2( dbInfoName , (strSQL as NSString).UTF8String, -1, &db, nil)
            // print ("strSQL: \(strSQL)")
            if sqlite3_prepare_v2( db, (strSQL as NSString).utf8String , -1, &db, nil ) == SQLITE_OK {
                while sqlite3_step(db) == SQLITE_ROW{
                    // ANSWER = String(cString: sqlite3_column_text(db, 0)!)
                    // print ("ANSWER \(ANSWER)")
                    ANSWER = String(cString: sqlite3_column_text(db, 1)!)
                   // print ("ANSWER \(ANSWER)")
                }
            }
            
            sqlite3_finalize(db)

        } catch {}
        // print ("opening database OK!")
        
        return ANSWER
    }
    
/*
    // https://stackoverflow.com/questions/24263007/how-to-use-hex-color-values
    func colorWithHexString (hex:String) -> UIColor {
        
        var cString = hex.trimmingCharacters(in: CharacterSet.whitespacesAndNewlines).uppercased()
        
        if (cString.hasPrefix("#")) {
            cString = (cString as NSString).substring(from: 1)
        }

        if (cString.count != 6) {
            return UIColor.gray
        }
        
        let rString = (cString as NSString).substring(to: 2)
        let gString = ((cString as NSString).substring(from: 2) as NSString).substring(to: 2)
        let bString = ((cString as NSString).substring(from: 4) as NSString).substring(to: 2)
        
        var r:CUnsignedInt = 0, g:CUnsignedInt = 0, b:CUnsignedInt = 0;
        Scanner(string: rString).scanHexInt32(&r)
        Scanner(string: gString).scanHexInt32(&g)
        Scanner(string: bString).scanHexInt32(&b)
        
        //return UIColor.red
        
        return UIColor(red: CGFloat(r) / 255.0, green: CGFloat(g) / 255.0, blue: CGFloat(b) / 255.0, alpha: CGFloat(1))
    }*/
    
    
    // 陣列排序
    func sortNSArray (srcArray : NSArray) -> NSArray{
        let myArray : NSArray = srcArray.sorted { (s0 , s1) -> Bool in
            return  "\(s0)" < "\(s1)" } as NSArray
        return myArray
    }
    
    
    // 陣列排序
    func sortMarkNSArray (srcArray : NSArray) -> NSArray{
        //  [strTitle , strKeyInfo, strDate]
        let infoDict : NSMutableDictionary = NSMutableDictionary()
        let infoArray : NSMutableArray = NSMutableArray()
        
        if srcArray == NSArray() {
            return infoArray as NSArray
        }
        
        for Ux in 0 ... srcArray.count - 1 {
            let OneArray : NSArray = srcArray.object(at: Ux) as! NSArray

            let strTitle: String = OneArray.object(at: 0) as! String
            let strURL: String = OneArray.object(at: 1) as! String
            let strFile: String = OneArray.object(at: 2) as! String
            let strChap: String = OneArray.object(at: 3) as! String
            let strKeys: String = OneArray.object(at: 4) as! String
            
            infoDict.setValue( [strTitle , strURL , strFile, strChap , strKeys] , forKey: strKeys )
        }
        var infoKeys: NSArray = infoDict.allKeys as NSArray
        infoKeys = sortNSArray(srcArray: infoKeys)
        
        for Ux in 0 ... infoKeys.count - 1 {
            let OneArray : NSArray = infoDict.object(forKey: infoKeys.object(at: Ux)) as! NSArray
            
            let strTitle: String = OneArray.object(at: 0) as! String
            let strURL: String = OneArray.object(at: 1) as! String
            let strFile: String = OneArray.object(at: 2) as! String
            let strChap: String = OneArray.object(at: 3) as! String
           // let strKeys: String = OneArray.object(at: 4) as! String
            
            infoArray.add( [strTitle , strURL , strFile, strChap] )
        }
        
        return infoArray as NSArray
    }
    
    
    // How to convert a string to an int
    // https://www.hackingwithswift.com/example-code/language/how-to-convert-a-string-to-an-int
    // 陣列排序
    func sortIntNSArray (srcArray : NSArray) -> NSArray{
        let myArray : NSArray = srcArray.sorted { (s0 , s1) -> Bool in
            return  (s0 as! NSString).integerValue < (s1  as! NSString).integerValue } as NSArray
        
        return myArray
    }
    
    
    // 讀取 PLIST 文件
    func getPlistDict (fileName:String, subName:String) ->NSDictionary{
        var dataDict : NSDictionary = [:]
        if  let plistPath = Bundle.main.path(forResource: fileName, ofType: subName){
            // print ("plistPath: \(plistPath)")
            var propertyListForamt = PropertyListSerialization.PropertyListFormat.xml //Format of the Property List.
            let plistXML = FileManager.default.contents(atPath: plistPath)!
            // print ("plistXML\(plistXML)")
            var plistData: [String: AnyObject] = [:]
            // How do I get a plist as a Dictionary in Swift?
            // https://stackoverflow.com/questions/24045570/how-do-i-get-a-plist-as-a-dictionary-in-swift
            do {//convert the data to a dictionary and handle errors.
                plistData = try PropertyListSerialization.propertyList(from: plistXML, options: .mutableContainersAndLeaves, format: &propertyListForamt) as! [String:AnyObject]
            } catch {
                print("Error reading plist: \(error), format: \(propertyListForamt)")
            }
            // print(plistData)
            dataDict = plistData as NSDictionary
        }
        return dataDict
    }
    
    
    // 讀取 PLIST 文件
    // NSArray with contents of file not work in ios
    // https://stackoverflow.com/questions/27500048/nsarray-with-contents-of-file-not-work-in-ios
    func getPlistArray (fileName:String, subName:String) ->NSArray{
        var dataDict : NSArray = []
        if  let plistPath = Bundle.main.path(forResource: fileName, ofType: subName){
            dataDict = NSMutableArray(contentsOfFile: plistPath)!
        }
        return dataDict
    }
    
    func removeFile ( destFileName:String ) {
        
        let DocumentDirURL = try! FileManager.default.url(for: .documentDirectory, in: .userDomainMask, appropriateFor: nil, create: true)
        let fileURL = DocumentDirURL.appendingPathComponent(destFileName)
        
        // 刪除的檔案
        let fileManager = FileManager.default
        do {
            try fileManager.removeItem(atPath: fileURL.path)
            // print("delete file: \(fileURL.path)")
        } catch {
            print("Error: \(error)")
        }
    }
    
    // 將 Plist 寫入檔案
    func writeDocuDict (destFileName:String , dictSource : NSDictionary ){
        // 將 Plist 寫入檔案
        // print ( verseDict )
        // Write to plist file in Swift
        // https://stackoverflow.com/questions/24692746/write-to-plist-file-in-swift
        do {
            let plistpath = try FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
                ).appendingPathComponent(destFileName )
               // print ( plistpath )
            dictSource.write(toFile: plistpath.path, atomically: false)
        } catch {
            print (error.localizedDescription)
        }
    }
    
    // 將 Plist 寫入檔案
    func writeDocuArray (destFileName:String , dictSource : NSArray ){
        // 將 Plist 寫入檔案
        // print ( verseDict )
        // Write to plist file in Swift
        // https://stackoverflow.com/questions/24692746/write-to-plist-file-in-swift
        do {
            let plistpath = try FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
                ).appendingPathComponent(destFileName )
               // print ( plistpath )
            dictSource.write(toFile: plistpath.path, atomically: false)
            
            print ( plistpath.path )
        } catch {
            print (error.localizedDescription)
        }
        
    }
    
    func fileExists ( fileName:String ) -> Bool {
        do {
            let plistPath  = try FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
                ).appendingPathComponent(fileName )
        
           // print ( plistPath )
        
            // https://codeday.me/bug/20170910/71349.html
            // 檔案不存在
            let fileManager = FileManager.default.fileExists(atPath: plistPath.path)
            if !fileManager {
                return false
            }
        
        } catch {
            print (error.localizedDescription)
            return false
        }
        
        return true
    }
    
    
    // 讀取 PLIST 文件
    func readDocuDict (fileName:String ) ->NSDictionary{
        var dataDict : NSDictionary = NSDictionary()
        do {
            let plistPath  = try FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
                ).appendingPathComponent(fileName )
            
              // print ( plistPath )
            
            // https://codeday.me/bug/20170910/71349.html
            // 檔案不存在
            let fileManager = FileManager.default.fileExists(atPath: plistPath.path)
            if !fileManager {
                return NSDictionary()
            }
                // print ("plistXML\(plistXML)")
            var plistData: [String: AnyObject] = [:]
                // How do I get a plist as a Dictionary in Swift?
                // https://stackoverflow.com/questions/24045570/how-do-i-get-a-plist-as-a-dictionary-in-swift
            do {//convert the data to a dictionary and handle errors.
                
                var propertyListForamt = PropertyListSerialization.PropertyListFormat.xml //Format of the Property List.
                let plistXML = FileManager.default.contents(atPath: plistPath.path)!
                
                plistData = try PropertyListSerialization.propertyList(from: plistXML, options: .mutableContainersAndLeaves, format: &propertyListForamt) as! [String:AnyObject]
            } catch {
                //, format: \(propertyListForamt)"
                print("Error reading plist: \(error)")
            }
            dataDict = plistData as NSDictionary
        } catch {
            print (error.localizedDescription)
        }
        // print ("dataDict\(dataDict)")
        return dataDict
    }
    
    
    
    // 讀取 PLIST 文件
    // https://stackoverflow.com/questions/36812331/swift-read-plist-file-to-an-array
    func readDocuArray (fileName:String ) ->NSArray{
        var dataDict : NSArray = NSArray()
        do {
            let plistPath  = try FileManager.default.url(
                for: .documentDirectory,
                in: .userDomainMask,
                appropriateFor: nil,
                create: true
                ).appendingPathComponent(fileName )
            
              print ( plistPath )
            
            // https://codeday.me/bug/20170910/71349.html
            // 檔案不存在
            let fileManager = FileManager.default.fileExists(atPath: plistPath.path)
            if !fileManager {
                return NSArray()
            }
                // print ("plistXML\(plistXML)")
            var plistData:NSArray = NSArray()
                // How do I get a plist as a Dictionary in Swift?
                // https://stackoverflow.com/questions/24045570/how-do-i-get-a-plist-as-a-dictionary-in-swift
            do {
                plistData = NSArray (contentsOf: plistPath)!
        
            }
            dataDict = plistData as NSArray
        } catch {
            print (error.localizedDescription)
        }
        // print ("dataDict\(dataDict)")
        return dataDict
    }
    
    
    
    
    // 轉換陣列，播放用
    func arrayToPlay (songArray : NSArray) ->[String]{
        // 標題，網址，檔名，書次章次
        var songString : [String] =  ["","","","",""]// 單一首的陣列，完成的陣列
        
        // print( songArray.count )
        // print( songArray[0] ) // 001,Gen, ഉല്പത്തി 第 1 章
        // print( songArray[1] ) // 001,http://SERVERIP2/bible_malayalam/01_genesis/Bible_ml_01_genesis_01.mp3
        // print( songArray[2] ) // 001,Bible_ml_01_genesis_01.mp3
        
        var tempString : String = "\(songArray[0])"
        songString[0] = String(tempString.suffix(tempString.count - 0))
        // Gen, ഉല്പത്തി 第 1 章
        // print( "songString[0]: \(songString[0])" )
        
        tempString = "\(songArray[1])"
        tempString = tempString.replacingOccurrences(of: "SERVERIP2", with: audioServer )
        songString[1] = String(tempString.suffix(tempString.count - 0))
        // http://share35.pointto.us/bible_malayalam/01_genesis/Bible_ml_01_genesis_01.mp3
        // print( "songString[1]: \(songString[1])" )
        
        tempString = "\(songArray[2])"
        tempString = String(tempString.suffix(tempString.count   - 0))
        
        // Bible_ml_01_genesis_01.mp3
        // print( "songString[2]: \(songString[2])" )
        let tmpArray = tempString.split{$0 == "."}
        songString[2] = "\(tmpArray[0])" // Bible_ml_01_genesis_01
        songString[3] = "\(tmpArray[1])" // mp3
        songString[4] = "\(songArray[3])" // 1,1 書次章次
        
        return songString
    }
    
    func getOneDay(strOneDay:String)->NSArray {
        
        let temp_Today = strOneDay
        var tempString = String(temp_Today.suffix(temp_Today.count - 3))
        let DayNum : Int = Int(tempString)! - 1
        tempString = String(temp_Today.prefix(2))
        let fileName = "tra_daily_\(tempString)"
        print("fileName \(fileName)")
        let DateDict:NSDictionary = getPlistDict(fileName: fileName, subName: "plist")
        // print(DateDict)
        var DateKeys:NSArray = DateDict.allKeys as NSArray
        DateKeys = sortNSArray(srcArray: DateKeys)
        
        let FiveArray:NSArray = DateDict.object(forKey: DateKeys[DayNum]) as! NSArray
        let playArray : NSMutableArray = NSMutableArray()
        var OneArray:NSArray = NSArray()
        var strChap: NSString = NSString()
        var strURL: NSString = NSString()
        var strStore: NSString = NSString()
        for Jx in 0 ... FiveArray.count - 1 {
            OneArray = FiveArray.object(at: Jx) as! NSArray
            // print (OneArray)
            strURL = OneArray[1]  as! NSString
            strURL = strURL.substring(from: 4) as NSString
            strURL = strURL.replacingOccurrences(of: "SERVERIP2", with: audioServer ) as NSString
                       
            strChap = OneArray[0] as! NSString
            strChap = strChap.substring(from: 4) as NSString
                       
            strStore = OneArray[2] as! NSString
            strStore = strStore.substring(from: 4) as NSString
                       
            // OneArray = [ strChap, strURL , strStore, OneArray[3]  ]
            OneArray = [ strChap, strURL ]
                       
            playArray.add(OneArray)
        }
        return playArray
    }
    
        
        
// Create UIDevice Extension To Determine UIDevice Current Model Name
// http://swiftdeveloperblog.com/code-examples/determine-current-device-model/
    
    var modelName: String {
            var systemInfo = utsname()
            uname(&systemInfo)
            let machineMirror = Mirror(reflecting: systemInfo.machine)
            let identifier = machineMirror.children.reduce("") { identifier, element in
                guard let value = element.value as? Int8, value != 0 else { return identifier }
                return identifier + String(UnicodeScalar(UInt8(value)))
            }
            
            switch identifier {
            case "iPod5,1":                                 return "iPod Touch 5"
            case "iPod7,1":                                 return "iPod Touch 6"
            case "iPhone3,1", "iPhone3,2", "iPhone3,3":     return "iPhone 4"
            case "iPhone4,1":                               return "iPhone 4s"
            case "iPhone5,1", "iPhone5,2":                  return "iPhone 5"
            case "iPhone5,3", "iPhone5,4":                  return "iPhone 5c"
            case "iPhone6,1", "iPhone6,2":                  return "iPhone 5s"
            case "iPhone7,2":                               return "iPhone 6"
            case "iPhone7,1":                               return "iPhone 6 Plus"
            case "iPhone8,1":                               return "iPhone 6s"
            case "iPhone8,2":                               return "iPhone 6s Plus"
            case "iPhone9,1", "iPhone9,3":                  return "iPhone 7"
            case "iPhone9,2", "iPhone9,4":                  return "iPhone 7 Plus"
            case "iPhone8,4":                               return "iPhone SE"
            case "iPad2,1", "iPad2,2", "iPad2,3", "iPad2,4":return "iPad 2"
            case "iPad3,1", "iPad3,2", "iPad3,3":           return "iPad 3"
            case "iPad3,4", "iPad3,5", "iPad3,6":           return "iPad 4"
            case "iPad4,1", "iPad4,2", "iPad4,3":           return "iPad Air"
            case "iPad5,3", "iPad5,4":                      return "iPad Air 2"
            case "iPad2,5", "iPad2,6", "iPad2,7":           return "iPad Mini"
            case "iPad4,4", "iPad4,5", "iPad4,6":           return "iPad Mini 2"
            case "iPad4,7", "iPad4,8", "iPad4,9":           return "iPad Mini 3"
            case "iPad5,1", "iPad5,2":                      return "iPad Mini 4"
            case "iPad6,3", "iPad6,4", "iPad6,7", "iPad6,8":return "iPad Pro"
            case "AppleTV5,3":                              return "Apple TV"
            case "i386", "x86_64":                          return "Simulator"
            default:                                        return identifier
            }
        }

    
}
