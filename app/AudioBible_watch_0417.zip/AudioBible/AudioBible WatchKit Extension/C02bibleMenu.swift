//
//  C02bibleMenu.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import SwiftUI

struct C02bibleMenu: View {
    
    @State var isTapped = false
    @State var indexBook:Int = 0
    @State var MenuArray:[CellItem] = []
    @State var CA:C02bible_info = C02bible_info()
    @State var bookTitle:String = ""
    @State var bookTitleArray: [String] = ["新約聖經","舊約聖經"]
    @State var var_bookTitle:String = ""
    @State var var_PlistName:String = ""
    
    var body: some View {
        NavigationView {
            List(MenuArray, id: \.id) { (OneItem) in
                // SwiftUI Tutorial - Lists and Navigation
                // https://www.youtube.com/watch?v=Cl2gAs7hySk
                NavigationLink (destination: C03oneBookSet(bookTitle:var_bookTitle,PlistName:var_PlistName),
                                isActive: self.$isTapped) {
                    TableViewCell(textLabel: OneItem.name)
                    .onTapGesture {
                        isTapped.toggle()
                        print("touched id \(OneItem.id)")
                        print("touched item \(OneItem.name)")
                        print("touched push \(OneItem.push)")
                        var_bookTitle = OneItem.name
                        var_PlistName = OneItem.push
                    }
                }
            }.padding(.all, 0)
        }
        .navigationTitle(bookTitle)
        .onAppear(){
            print("C02bibleMenu:\(indexBook)")
            
            bookTitle = bookTitleArray[indexBook % 2]
            
            let ArraySRC:NSArray = CA.getMenuBook(isOldSets:indexBook % 2)
            var OneBook:NSArray
            var BookName:NSString
            var PlistName:NSString
            var isOldNum: Int = 0

            if ( indexBook % 2 == 1 ){
                isOldNum = 0;
            } else {
                isOldNum = 39
            }
            
            MenuArray = []
            
            for Px:Int in 0 ... ArraySRC.count - 1 {
                OneBook   = ArraySRC.object(at: Px) as! NSArray
                BookName  = OneBook.object(at: 0) as! NSString
                PlistName = OneBook.object(at: 1) as! NSString
                MenuArray.append(CellItem(
                    id: Px+1,
                    name: "\(Px+1+isOldNum) \(String(BookName))" ,
                    push: String(PlistName)))
                
                // print( "CellItem(id:\(Px),name:\"\(BookName)\",push:\"\(PlistName)\"),")
            }
        }
        
    }
}

struct C02bibleMenu_Previews: PreviewProvider {
    var indexBook:Int = 0
    static var previews: some View {
        
        C02bibleMenu(indexBook:0)
    }
}
