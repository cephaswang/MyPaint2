//
//  C02bibleMenu.swift
//  AudioBible WatchKit Extension
//
//  Created by admin on 2022/4/9.
//

import Foundation

class C03oneBook_info {

    var initData  = CommClass()

    func getOneBook (fileName: String) -> NSArray {
        return initData.getOneBook(fileName: fileName)
    }
   
}
