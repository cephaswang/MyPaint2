package com.chinalwb.are.emojipanel;

import android.widget.AdapterView;

/**
 * Created by wliu on 2018/3/17.
 */

public class EmojiGroup {

    public EmojiGroupDesc desc;

    public AdapterView.OnItemClickListener listener;
}


