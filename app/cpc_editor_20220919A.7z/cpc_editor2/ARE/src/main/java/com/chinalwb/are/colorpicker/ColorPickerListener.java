package com.chinalwb.are.colorpicker;

/**
 * Created by wliu on 2018/3/6.
 */

public interface ColorPickerListener {
    public void onPickColor(int color);
}
