package tw.ibiz.members;


import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.os.Build;
import android.util.Log;
import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.core.app.NotificationManagerCompat;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;


// Android 8.0 Oreo 一定得實作的通知頻道Notification channels
// https://litotom.com/android-8-0-oreo-notification-channels/


// https://console.firebase.google.com/u/0/

public class PushNotificationService extends FirebaseMessagingService {

    private  String TAG  = "PushNotificationService";

    private static final String CHANNEL_ID = "Channel Love";

    private commomLib CB = new commomLib();

    @RequiresApi(api = Build.VERSION_CODES.O)
    @Override
    public void onMessageReceived(@NonNull RemoteMessage message) {
        String Title = message.getNotification().getTitle();
        String body  = message.getNotification().getBody();

        CB.playBeep(this);

        NotificationChannel channel = new NotificationChannel(
                CHANNEL_ID,"Heads Up Notification",
                NotificationManager.IMPORTANCE_HIGH

        );

        getSystemService(NotificationManager.class).createNotificationChannel(channel);
        Notification.Builder notification = new Notification.Builder(this,CHANNEL_ID)
                .setContentTitle(Title)
                .setContentText(body)
                .setSmallIcon(R.drawable.ic_launcher_background)
                .setAutoCancel(true);

        NotificationManagerCompat.from(this).notify(1,notification.build());

        super.onMessageReceived(message);
    }

    // 监控令牌的生成
    @Override
    public void onNewToken(@NonNull String token) {
        super.onNewToken(token);
        Log.d(TAG, "Refreshed token: " + token);

        CB.playBeep(this);

        // If you want to send messages to this application instance or
        // manage this apps subscriptions on the server side, send the
        // FCM registration token to your app server.
        // sendRegistrationToServer(token);
    }
}
