package tw.ibiz.members;

// https://www.youtube.com/watch?v=OTBHAf11Zd0&t=355s

//  https://www.youtube.com/watch?v=OTBHAf11Zd0&t=486s

import android.util.Log;
import com.google.firebase.messaging.FirebaseMessagingService;
import com.google.firebase.messaging.RemoteMessage;



public class MyInstanceIDService extends FirebaseMessagingService {

    private  String TAG  = "MyInstanceIDService";
    private commomLib CB = new commomLib();

    @Override
    public void onNewToken(String s) {
        super.onNewToken(s);
        CB.playBeep(this);
        Log.e("NEW_TOKEN",s);
    }

    @Override
    public void onMessageReceived(RemoteMessage remoteMessage) {
        super.onMessageReceived(remoteMessage);

        CB.playBeep(this);
        Log.e("onMessageReceived",remoteMessage.getNotification().toString());
    }

    // 將新的注冊碼，送到後端
    private void sendRegistrationToServer(String refToken){

    }

}
