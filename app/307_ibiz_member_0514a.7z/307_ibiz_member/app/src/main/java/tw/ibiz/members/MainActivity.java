package tw.ibiz.members;


// Send Android Push Notifications Using Firebase Cloud Messaging | Android Studio (With Source Code)
// https://www.youtube.com/watch?v=M7z2MFoI6MQ

/*

第六篇：進階元件使用(webview)
https://ithelp.ithome.com.tw/articles/10239717

*/


import androidx.annotation.NonNull;
import androidx.annotation.RequiresApi;
import androidx.appcompat.app.AppCompatActivity;
import android.content.Context;
import android.net.ConnectivityManager;
import android.net.NetworkInfo;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.messaging.FirebaseMessaging;
import plist.NSDictionary;
import android.view.View;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.EditText;
import android.widget.Button;
import android.os.Handler;


public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private commomLib CB = new commomLib();
    private WebView webView = null;
    private WebView webView_token = null;
    private NSDictionary userInfo = null;
    private EditText EditText_Token;
    private Button Button_Token;
    private PushNotifictionHelper PU = new PushNotifictionHelper();

    public String token_info = "";


    //   private static final String SerVerPath = "https://www.member.5.ibiz.tw/";
    private static final String SerVerPath = "http://192.168.0.111/";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        FirebaseMessaging.getInstance().setAutoInitEnabled(true);
        regFireBase();

        webView  = (WebView)findViewById( R.id.webView);
        webView_token = findViewById(R.id.webView_token);
        EditText_Token = findViewById(R.id.EditText_Token);
        Button_Token = findViewById(R.id.Button_Token);

        // Register the onClick listener with the implementation above
        Button_Token.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v)
            {
                EditText_Token.setText( "" );
            }
        });

    }

// https://stackoverflow.com/questions/4238921/detect-whether-there-is-an-internet-connection-available-on-android
    private boolean isNetworkAvailable() {
        ConnectivityManager connectivityManager
                = (ConnectivityManager) getSystemService(Context.CONNECTIVITY_SERVICE);
        NetworkInfo activeNetworkInfo = connectivityManager.getActiveNetworkInfo();
        return activeNetworkInfo != null && activeNetworkInfo.isConnected();
    }


    @RequiresApi(api = Build.VERSION_CODES.R)
    @Override
    protected void onStart() {
        super.onStart();

          if (!  isNetworkAvailable() ){
              String noconnect = "<h1>沒有網路連線</h1>";
              webView.loadData(noconnect, "text/html", "UTF-8");
              return;
          }

        webView.setWebViewClient(new WebViewClient());
        webView.getSettings().setJavaScriptEnabled(true);

        final Handler handlerA = new Handler();
        handlerA.postDelayed(new Runnable() {
            @Override
            public void run() {
                String url_info = "app/api.php?mode=token&type=android&token="+token_info;
                String body     = "<frameset><frame src='" + url_info + "'></frameset>";
                webView.loadDataWithBaseURL( SerVerPath , body, "text/html", "utf-8",null);
                EditText_Token.setText( url_info );
            }
        }, 100);


        final Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @Override
            public void run() {
               webView.loadUrl( SerVerPath + "start.php");
                //  webView.loadUrl( SerVerPath);
            }
        }, 500);
    }


    public void regFireBase(){
        FirebaseMessaging.getInstance().getToken()
            .addOnCompleteListener(new OnCompleteListener<String>() {
                @Override
                public void onComplete(@NonNull Task<String> task) {
                    if (!task.isSuccessful()) {
                        Log.w(TAG, "Fetching FCM registration token failed", task.getException());
                        return;
                    }
                    token_info =  task.getResult();
                    Log.w(TAG, token_info.toString(), null );
                }
            });
    }

}