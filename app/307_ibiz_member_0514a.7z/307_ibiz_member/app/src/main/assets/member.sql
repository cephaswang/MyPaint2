-- phpMyAdmin SQL Dump
-- version 5.1.3
-- https://www.phpmyadmin.net/
--
-- 主机： 127.0.0.1
-- 生成日期： 2022-05-13 01:08:13
-- 服务器版本： 10.4.24-MariaDB
-- PHP 版本： 8.1.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";

--
-- 数据库： `members`
--

-- --------------------------------------------------------

--
-- 表的结构 `members`
--

CREATE TABLE `members` (
  `ID` int(11) UNSIGNED NOT NULL,
  `username` varchar(20) NOT NULL,
  `password` varchar(20) NOT NULL,
  `token` varchar(400) NOT NULL,
  `type` varchar(20) NOT NULL,
  `date_time` varchar(30) NOT NULL,
  `REMOTE_ADDR` varchar(20) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- 转存表中的数据 `members`
--

INSERT INTO `members` (`ID`, `username`, `password`, `token`, `type`, `date_time`, `REMOTE_ADDR`) VALUES
(1, 'nice', 'pass', 'efV1TFYfTpyAY37mcbwN8X:APA91bHKVEpUWIag6DWNr5p_QmmuxVSFxPYSIvgpg4nAUsRXwlEuesRIxGByXfd5LpZHbRc3hF7JruVqDkMHR6DGcN_MSyix-8m_oqNsv26JNEXhsEWe5jmWdl1IvPMJik2T0_7TiRy0', 'android', 'Fri, 13 May 2022 00:50:54 +020', '192.168.0.101');

--
-- 转储表的索引
--

--
-- 表的索引 `members`
--
ALTER TABLE `members`
  ADD PRIMARY KEY (`ID`);

--
-- 在导出的表使用AUTO_INCREMENT
--

--
-- 使用表AUTO_INCREMENT `members`
--
ALTER TABLE `members`
  MODIFY `ID` int(11) UNSIGNED NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;
COMMIT;
