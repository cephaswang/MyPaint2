package org.shar35.wear.demowatch;


import androidx.appcompat.app.AppCompatActivity;
import android.content.BroadcastReceiver;
import android.content.ComponentName;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.ServiceConnection;
import android.os.Bundle;
import android.os.IBinder;
import android.view.View;
import android.widget.ImageButton;
import android.widget.SeekBar;
import android.widget.TextView;



public class b05player extends AppCompatActivity implements SeekBar.OnSeekBarChangeListener {

    // --Seekbar variables --
    private static SeekBar seekBar;
    private static TextView title_txt;
    private Intent seekBar_intent;
    private b05PlayService musicService;
    private static TextView  str_timeStart = null;
    private static TextView  str_timeLeft  = null;
    private static TextView  text_speed  = null;
    private float int_PLAY_SPEED  = 1.0F;

    private ImageButton btn_backward = null;
    private ImageButton btn_play = null;
    private ImageButton btn_forward = null;
    private ImageButton btn_bookmark = null;
    private ImageButton btn_repeat = null;

    private ImageButton btn_spd_add = null;
    private ImageButton btn_spd_dec = null;

    private boolean is_btn_play = true;
    private boolean is_btn_repeat = false;
    private boolean is_btn_bookmark = false;

    Intent ctrlIntent;

    private  Integer PlayIndexID = 0;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_b05player);

        Intent intent = getIntent();
        PlayIndexID = Integer.parseInt(  intent.getStringExtra("PlayIndexID") );

        System.out.println("PlayIndexID:" + PlayIndexID);

        // --Reference seekbar in main.xml
        seekBar = (SeekBar) findViewById( R.id.seekBar);
        seekBar.setOnSeekBarChangeListener(this);

        // 登記進度條廣播
        // --- set up seekbar intent for broadcasting new position to service ---
        seekBar_intent = new Intent(DCSTools.BROADCAST_SEEKBAR);
        // 登記用戶操作事件廣播
        ctrlIntent = new Intent(DCSTools.BROADCAST_USERCRL);

        // 標題文字
        title_txt = (TextView)findViewById( R.id.title_txt);
        str_timeStart = (TextView)findViewById( R.id.str_timeStart);
        str_timeLeft  = (TextView)findViewById( R.id.str_timeLeft);
        text_speed = (TextView)findViewById( R.id.text_speed);

        btn_backward = (ImageButton)findViewById( R.id.btn_backward);
        btn_play     = (ImageButton)findViewById( R.id.btn_play);
        btn_forward  = (ImageButton)findViewById( R.id.btn_forward);
        btn_bookmark = (ImageButton)findViewById( R.id.btn_bookmark);
        btn_repeat   = (ImageButton)findViewById( R.id.btn_repeat);
        btn_spd_dec  = (ImageButton)findViewById( R.id.btn_spd_dec);
        btn_spd_add  = (ImageButton)findViewById( R.id.btn_spd_add);

        btn_backward.setOnClickListener(mCorkyListener);
        btn_play.setOnClickListener(mCorkyListener);
        btn_forward.setOnClickListener(mCorkyListener);
        btn_bookmark.setOnClickListener(mCorkyListener);
        btn_repeat.setOnClickListener(mCorkyListener);
        btn_spd_dec.setOnClickListener(mCorkyListener);
        btn_spd_add.setOnClickListener(mCorkyListener);

        // 更新服務 Fix Service 2020 01 28
        bindServiceConnection();

        regSYNC();
    }

    // Create an anonymous implementation of OnClickListener
    private View.OnClickListener mCorkyListener = new View.OnClickListener() {
        public void onClick(View v) {

            // do something when the button is clicked
            switch (v.getId() /*to get clicked view id**/) {
                case R.id.btn_backward:
                    ctrlIntent.putExtra("userCTRL", "btn_backward");
                    ctrlIntent.putExtra("value", "0" );
                    break;
                case R.id.btn_play:
                    is_btn_play = !is_btn_play;
                    if(is_btn_play == false){
                        btn_play.setImageResource(R.mipmap.btn_play_ture);
                    } else {
                        btn_play.setImageResource(R.mipmap.btn_play);
                    }
                    ctrlIntent.putExtra("userCTRL", "btn_play");
                    ctrlIntent.putExtra("value", String.valueOf(is_btn_play) );
                    break;
                case R.id.btn_forward:
                    ctrlIntent.putExtra("userCTRL", "btn_forward");
                    ctrlIntent.putExtra("value", "0" );
                    break;
                case R.id.btn_bookmark:
                    is_btn_bookmark = !is_btn_bookmark;
                    if(is_btn_bookmark == true){
                        btn_bookmark.setImageResource(R.mipmap.btn_bookmark_ture);
                    } else {
                        btn_bookmark.setImageResource(R.mipmap.btn_bookmark);
                    }
                    break;
                case R.id.btn_repeat:
                    is_btn_repeat = !is_btn_repeat;
                    if(is_btn_repeat == true){
                        btn_repeat.setImageResource(R.mipmap.btn_repeat_true);
                    } else {
                        btn_repeat.setImageResource(R.mipmap.btn_repeat);
                    }
                    ctrlIntent.putExtra("userCTRL", "btn_repeat");
                    ctrlIntent.putExtra("value", String.valueOf(is_btn_repeat) );
                    break;
                case R.id.btn_spd_dec:
                    if (int_PLAY_SPEED > 0.2){
                        int_PLAY_SPEED -= 0.1;
                    }
                    ctrlIntent.putExtra("userCTRL", "btn_speed");
                    ctrlIntent.putExtra("value", String.format("%.1f", int_PLAY_SPEED));
                    text_speed.setText( String.format("%.1f", int_PLAY_SPEED));
                    break;
                case R.id.btn_spd_add:
                    if (int_PLAY_SPEED < 2){
                        int_PLAY_SPEED += 0.1;
                    }
                    ctrlIntent.putExtra("userCTRL", "btn_speed");
                    ctrlIntent.putExtra("value", String.format("%.1f", int_PLAY_SPEED));
                    text_speed.setText( String.format("%.1f", int_PLAY_SPEED));
                    break;
            }

            sendBroadcast(ctrlIntent);
        }
    };


    //  回调onServiceConnected 函数，通过IBinder 获取 Service对象，实现Activity与 Service的绑定
    private ServiceConnection serviceConnection = new ServiceConnection() {
        @Override
        public void onServiceConnected(ComponentName name, IBinder service) {
            musicService = ((b05PlayService.MyBinder) (service)).getService();
        }
        @Override
        public void onServiceDisconnected(ComponentName name) {
            musicService = null;
        }
    };


    // ===========================================================================
    // 更新服務 Fix Service 2020 01 28
    // https://www.cnblogs.com/yanglh6-jyx/p/Android_Service_MediaPlayer.html
    // https://github.com/yanglh751202951/SYSU_Android6
    //  在Activity中调用 bindService 保持与 Service 的通信
    private void bindServiceConnection() {
        Intent intent = new Intent(b05player.this, b05PlayService.class);
        intent.putExtra("PlayIndexID", String.valueOf(PlayIndexID));
        startService(intent);
        bindService(intent, serviceConnection, this.BIND_AUTO_CREATE);
    }

    @Override
    protected void onDestroy() {
        super.onDestroy();

        unregSYNC();

        final Intent intentSRV = new Intent(b05player.this, b05PlayService.class);
        stopService(intentSRV);
        unbindService(serviceConnection);
    }

    // -- Broadcast Receiver to update position of seekbar from service --
    private BroadcastReceiver broadcastReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            updateUI(intent);
        }
    };

    // 更新進度條，時間標簽
    private void updateUI(Intent serviceIntent) {

        // 媒體總長度
        String mediamax = serviceIntent.getStringExtra("mediamax");
        int seekMax = Integer.parseInt(mediamax);
        seekBar.setMax(seekMax);

        // 目前播放的進度
        int seekProgress =  Integer.parseInt( serviceIntent.getStringExtra("counter"));
        seekBar.setProgress(seekProgress);

        String PlayTITLE = serviceIntent.getStringExtra("PlayTITLE");
        title_txt.setText( PlayTITLE );

        // 顯示進度時間
        str_timeStart.setText(sectoTimeStr(seekProgress));
        str_timeLeft.setText("-"+sectoTimeStr((int)(seekMax-seekProgress)));

    }

    // 將數值時間轉成格式化文字
    public String sectoTimeStr (int totalSecs){
        totalSecs =	(int)(totalSecs/1000);
        // int  hours = (int)(totalSecs / 3600);
        // int  minutes = (int)((totalSecs % 3600) / 60);
        int  minutes = (int)(totalSecs / 60);
        int  seconds = (int)(totalSecs % 60);
        if ( seconds < 0 ){
            seconds = 0;
        }
        // String timeString = String.format ("%d:%02d:%02d",hours,minutes,seconds);
        String timeString = String.format ("%02d:%02d",minutes,seconds);
        return timeString;
    }

    // 取消進度條同步
    private void unregSYNC() {
        unregisterReceiver(broadcastReceiver);
//        unregisterReceiver(broadcastBufferReceiver);
    }

    // 登記進度條同步
    private void regSYNC() {
        registerReceiver(broadcastReceiver, new IntentFilter( DCSTools.BROADCAST_ACTION ) );
    }

    @Override
    public void onProgressChanged(SeekBar seekBar, int i, boolean b) {
        int seekPos = seekBar.getProgress();
        seekBar_intent.putExtra("seekpos", seekPos);
        sendBroadcast(seekBar_intent);

    }

    @Override
    public void onStartTrackingTouch(SeekBar seekBar) {

    }

    @Override
    public void onStopTrackingTouch(SeekBar seekBar) {

    }
}