package org.shar35.wear.demowatch;


import androidx.appcompat.app.AppCompatActivity;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;
import com.dd.plist.NSArray;
import com.dd.plist.NSDictionary;
import com.dd.plist.PropertyListParser;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;



public class C06config extends AppCompatActivity {

    private int acc_date = 0;
    private NSArray TempList = new NSArray(1500);
    private NSArray PlayList = new NSArray(0);

    private Button btn_menu1;
    private Button btn_menu2;

    private TextView textView_Index, textView_Name;
    private ProgressBar progressBar;

    private DCSTools VC = new DCSTools();

    @Override
    protected void onDestroy() {
        super.onDestroy();

        b02DownService.is_run = 0;

        final Intent intentSRV = new Intent(C06config.this, b02DownService.class);
        stopService(intentSRV);

        unregisterReceiver(broadcastBufferReceiver);
    }

    // Set up broadcast receiver
    private BroadcastReceiver broadcastBufferReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent bufferIntent) {
            showPD(bufferIntent);
        }
    };

    private void showPD(Intent bufferIntent) {

        String bufferValue = bufferIntent.getStringExtra("buffering");

        // 傳入進度睥值
        String StatusValue = bufferIntent.getStringExtra("StatusValue");
        String Mp3SaveName = bufferIntent.getStringExtra("Mp3SaveName");
        int bufferIntValue = 0;
        int StatusIntValue = Integer.parseInt(StatusValue);
        progressBar.setProgress(StatusIntValue);

        textView_Index.setText(bufferValue);
        textView_Name.setText(Mp3SaveName);

    }
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c06config);

        registerReceiver(broadcastBufferReceiver, new IntentFilter( DCSTools.BROADCAST_BUFFER2));

        Intent intent = getIntent();
        String title = intent.getStringExtra("title");
        setTitle(title);

        textView_Index = (TextView) findViewById(R.id.textView_Index);
        textView_Name = (TextView) findViewById(R.id.textView_Name);
        progressBar = (ProgressBar) findViewById(R.id.progressBar);

        btn_menu1 = (Button) findViewById(R.id.btn_menu1);
        btn_menu2 = (Button)findViewById(R.id.btn_menu2);
        btn_menu1.setOnClickListener(mCorkyListener);
        btn_menu2.setOnClickListener(mCorkyListener);

        NSDictionary rootDict = null;
        // 讀取菜單文檔
        try {
            AssetManager am = getAssets();
            String audioPLIST = null;
            if (Locale.getDefault().equals (Locale.SIMPLIFIED_CHINESE)){
                audioPLIST = "c01_data.plist";
            } else {
                audioPLIST = "c01_data.plist";
            }
            InputStream is = am.open(audioPLIST);
            // 全部內容
            rootDict = (NSDictionary) PropertyListParser.parse(is);
        } catch(Exception ex) {
            ex.printStackTrace();
            Toast.makeText(getApplicationContext(), "讀取菜單文檔 失敗" , Toast.LENGTH_LONG).show();
        }

        NSArray menuArray = (NSArray) rootDict.get("config");

        btn_menu1.setText(menuArray.objectAtIndex(0).toString());
        btn_menu2.setText(menuArray.objectAtIndex(1).toString());

    }


    // Create an anonymous implementation of OnClickListener
    private View.OnClickListener mCorkyListener = new View.OnClickListener() {
        public void onClick(View v) {

            int Px = 0;
            // do something when the button is clicked
            switch (v.getId() /*to get clicked view id**/) {
                case R.id.btn_menu1:
                    for (int Dx=0 ; Dx < 60 ; Dx++ ){
                        String  today_str  = VC.getToday(Dx);
                        //System.out.println(today_str);
                        NSArray OneDayList = VC.getOneDay(C06config.this, today_str);
                        for (int Jx=0; Jx< OneDayList.count() ; Jx++ ){
                            NSArray OneChap = (NSArray) OneDayList.objectAtIndex(Jx);
                            TempList.setValue(Px,  OneChap );
                            Px++;
                        }
                    }

                    break;

                case R.id.btn_menu2:
                    for (int Dx=0 ; Dx < 367 ; Dx++ ){
                        String  today_str  = VC.getToday(Dx);
                        //System.out.println(today_str);
                        NSArray OneDayList = VC.getOneDay(C06config.this, today_str);
                        for (int Jx=0; Jx< OneDayList.count() ; Jx++ ){
                            NSArray OneChap = (NSArray) OneDayList.objectAtIndex(Jx);
                            TempList.setValue(Px,  OneChap );
                            Px++;
                        }
                    }

                    break;

            }

            PlayList = new NSArray(Px);
            for(int Kx=0 ; Kx<Px ; Kx++){
                PlayList.setValue(Kx,  (NSArray) TempList.objectAtIndex(Kx) );
            }

           // System.out.println( PlayList.toXMLPropertyList().toString() );

            File path = C06config.this.getFilesDir();
            File file = new File(path, "down.plist");
            FileOutputStream stream = null;
            try {
                stream = new FileOutputStream(file);
                stream.write( PlayList.toXMLPropertyList().getBytes() );
                stream.close();
            } catch (FileNotFoundException e) {
                e.printStackTrace();
            } catch (IOException e) {
                e.printStackTrace();
            }

            b02DownService.is_run = 1;

            final Intent intentSRV = new Intent(C06config.this, b02DownService.class);
            startService(intentSRV);
        }
    };

}