package org.shar35.wear.demowatch;


import androidx.appcompat.app.AppCompatActivity;
import android.annotation.SuppressLint;
import android.content.Intent;
import android.content.res.AssetManager;
import android.os.Bundle;
import android.text.format.DateFormat;
import android.view.View;
import android.widget.Button;
import android.widget.ImageButton;
import android.widget.TextView;
import android.widget.Toast;
import com.dd.plist.NSArray;
import com.dd.plist.NSDictionary;
import com.dd.plist.PropertyListParser;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;



public class C01mainStart extends AppCompatActivity {

    private int acc_date = 0;
    private TextView textView_day;
    private ImageButton btn_prev;
    private ImageButton btn_reset;
    private ImageButton btn_next;
    private Button btn_menu1;
    private Button btn_menu2;
    private Button btn_menu3;
    private Button btn_menu4;
    private Button btn_menu5;
    private Button btn_menu6;
    private Button btn_menu7;

    private DCSTools VC = new DCSTools();

    NSArray menuArray = null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c01mainstart);

        textView_day = (TextView) findViewById(R.id.textView_day);

        btn_prev  = (ImageButton) findViewById(R.id.btn_prev);
        btn_reset = (ImageButton) findViewById(R.id.btn_reset);
        btn_next  = (ImageButton) findViewById(R.id.btn_next);

        btn_menu1 = (Button) findViewById(R.id.btn_menu1);
        btn_menu2 = (Button)findViewById(R.id.btn_menu2);
        btn_menu3 = (Button)findViewById(R.id.btn_menu3);
        btn_menu4 = (Button)findViewById(R.id.btn_menu4);
        btn_menu5 = (Button)findViewById(R.id.btn_menu5);
        btn_menu6 = (Button)findViewById(R.id.btn_menu6);
        btn_menu7 = (Button)findViewById(R.id.btn_menu7);

        btn_prev.setOnClickListener(mCorkyListener);
        btn_reset.setOnClickListener(mCorkyListener);
        btn_next.setOnClickListener(mCorkyListener);

        btn_menu1.setOnClickListener(mCorkyListener);
        btn_menu2.setOnClickListener(mCorkyListener);
        btn_menu3.setOnClickListener(mCorkyListener);
        btn_menu4.setOnClickListener(mCorkyListener);
        btn_menu5.setOnClickListener(mCorkyListener);
        btn_menu6.setOnClickListener(mCorkyListener);
        btn_menu7.setOnClickListener(mCorkyListener);

        NSDictionary rootDict = null;
        // 讀取菜單文檔
        try {
            AssetManager am = this.getAssets();
            String audioPLIST = null;
            if (Locale.getDefault().equals (Locale.SIMPLIFIED_CHINESE)){
                audioPLIST = "c01_data.plist";
            } else {
                audioPLIST = "c01_data.plist";
            }
            InputStream is = am.open(audioPLIST);
            // 全部內容
            rootDict = (NSDictionary) PropertyListParser.parse(is);
        } catch(Exception ex) {
            ex.printStackTrace();
            Toast.makeText(getApplicationContext(), "讀取菜單文檔 失敗" , Toast.LENGTH_LONG).show();
        }
        //   String [] names1ST  = rootDict.allKeys();
        menuArray = (NSArray) rootDict.get("menu");
        btn_menu1.setText(menuArray.objectAtIndex(0).toString());
        btn_menu2.setText(menuArray.objectAtIndex(1).toString());
        btn_menu3.setText(menuArray.objectAtIndex(2).toString());
        btn_menu4.setText(menuArray.objectAtIndex(3).toString());
        btn_menu5.setText(menuArray.objectAtIndex(4).toString());
        btn_menu6.setText(menuArray.objectAtIndex(5).toString());
        btn_menu7.setText(menuArray.objectAtIndex(6).toString());

        showList();
    }


    public void showList(){
        String  today_str = VC.getToday(acc_date);
        NSArray PlayList  = VC.getOneDay(C01mainStart.this, today_str);

        File path = this.getFilesDir();
        File file = new File(path, "play.plist");
        FileOutputStream stream = null;
        try {
            stream = new FileOutputStream(file);
            stream.write( PlayList.toXMLPropertyList().getBytes() );
            stream.close();
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }

        textView_day.setText(today_str);
    }

    // Create an anonymous implementation of OnClickListener
    private View.OnClickListener mCorkyListener = new View.OnClickListener() {
        public void onClick(View v) {

            Intent intent = new Intent();

            // do something when the button is clicked
            switch (v.getId() /*to get clicked view id**/) {
                case R.id.btn_prev:
                    acc_date = acc_date - 1;
                    C01mainStart.this.showList();
                    return;
                case R.id.btn_reset:
                    acc_date = 0;
                    C01mainStart.this.showList();
                    return;
                case R.id.btn_next:
                    acc_date = acc_date + 1;
                    C01mainStart.this.showList();
                    return;
                case R.id.btn_menu1:
                    intent.setClass( C01mainStart.this,C02bibleMenu.class);
                    intent.putExtra("id","0");
                    intent.putExtra("title",menuArray.objectAtIndex(0).toString());
                    break;
                case R.id.btn_menu2:
                    intent.setClass( C01mainStart.this,C02bibleMenu.class);
                    intent.putExtra("id","0");
                    intent.putExtra("title",menuArray.objectAtIndex(1).toString());

                    break;
                case R.id.btn_menu3:
                    intent.setClass( C01mainStart.this,C02bibleMenu.class);
                    intent.putExtra("id","1");
                    intent.putExtra("title",menuArray.objectAtIndex(2).toString());
                    break;
                case R.id.btn_menu4:
                    intent.setClass( C01mainStart.this,C03taiyuMenu.class);
                    intent.putExtra("id","1");
                    intent.putExtra("title",menuArray.objectAtIndex(3).toString());
                    break;
                case R.id.btn_menu5:
                    intent.setClass( C01mainStart.this,C04bookMark.class);
                    intent.putExtra("title",menuArray.objectAtIndex(4).toString());
                    break;
                case R.id.btn_menu6:
                    intent.setClass( C01mainStart.this,C06config.class);
                    intent.putExtra("title",menuArray.objectAtIndex(5).toString());
                    break;
                case R.id.btn_menu7:
                    intent.setClass( C01mainStart.this,C07about.class);
                    intent.putExtra("title",menuArray.objectAtIndex(6).toString());
                    break;
            }

            startActivity(intent);

        }
    };


}