package org.shar35.wear.demowatch;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;

public class C04bookMark extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_c04book_mark);

        Intent intent = getIntent();
        //idBook = intent.getStringExtra("id");
        String title = intent.getStringExtra("title");
        setTitle(title);

    }
}