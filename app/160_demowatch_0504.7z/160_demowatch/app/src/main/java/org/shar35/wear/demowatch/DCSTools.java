package org.shar35.wear.demowatch;


import android.content.Context;
import android.content.res.AssetManager;
import com.dd.plist.NSArray;
import com.dd.plist.NSDictionary;
import com.dd.plist.PropertyListParser;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.Date;


public class DCSTools {

    public static final String  AudioServer = "bible.cephas.tw";


    public String getToday ( int date ) {
        SimpleDateFormat formatter = new SimpleDateFormat("MM-dd");
        long TX = 60 * 60 * 24 * 1000 * (long)date;
        Date curDate = new Date( System.currentTimeMillis() + TX ); // 獲取當前時間
        String Today = formatter.format(curDate);
        return Today;
    }

    public  NSArray getOneDay (Context VC, String Oneday_str){

        String mont_str = Oneday_str.substring(0, 2);
        String date_str = Oneday_str.substring(3, 5);
        String audioPLIST = null;
        audioPLIST = "tra_daily_" + String.format("%02d", Integer.parseInt(mont_str)) + ".plist";

        NSDictionary rootDict = null;
        // 讀取菜單文檔
        try {
            AssetManager am = VC.getAssets();
            InputStream is = am.open(audioPLIST);
            rootDict = (NSDictionary) PropertyListParser.parse(is);
        } catch(Exception ex) {
            ex.printStackTrace();
        }

        // 陣列，新約，舊約
        String [] names1ST  = rootDict.allKeys();
        int DataVar = Integer.parseInt(date_str);
        NSArray b2ndDict = (NSArray)rootDict.objectForKey(names1ST[ DataVar -1]);

        // 要播放的陣列
        final NSArray PlayList = new NSArray(b2ndDict.count());
        for ( int Ux = 0 ; Ux < b2ndDict.count() ; Ux++ ){
            NSArray oneChapArray = (NSArray)b2ndDict.objectAtIndex(Ux);
            NSArray oneChap = new NSArray(2);
            oneChap.setValue( 0, oneChapArray.objectAtIndex(0).toString().substring(4) );
            String urlAddress = oneChapArray.objectAtIndex(1).toString().substring(4);
            oneChap.setValue( 1, urlAddress.replace("SERVERIP2",AudioServer) );
            PlayList.setValue(Ux, oneChap);
        }
       // System.out.println(PlayList.toXMLPropertyList().toString());

        return PlayList;
    }

}
