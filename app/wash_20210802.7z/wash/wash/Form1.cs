﻿using System;
using System.Windows.Forms;
using System.IO.Ports;
using System.Text;
using System.IO;

/*

https://www.youtube.com/watch?v=Fer_q9LXDnQ
C# Tutorial - Serial Communication | FoxLearn

*/

namespace wash
{
    public partial class Form1 : Form
    {
       // SerialPort serialPort1 = new SerialPort();
        static string recevice_string;

        public Form1()
        {
            InitializeComponent();
        }

        private void Form1_Load(object sender, EventArgs e)
        {

            // 485 9600,8,1,1,none
            // 


            button_reflash_Click(sender, e);

            // Define the border style of the form to a dialog box.
            this.FormBorderStyle = FormBorderStyle.FixedDialog;

            // Set the MaximizeBox to false to remove the maximize box.
            this.MaximizeBox = false;

            // Set the MinimizeBox to false to remove the minimize box.
            this.MinimizeBox = false;

            // Set the start position of the form to the center of the screen.
            this.StartPosition = FormStartPosition.CenterScreen;

            comboBox_BaudRate.SelectedIndex = 0;
            comboBox_Parity.SelectedIndex = 0;
            comboBox_StopBits.SelectedIndex = 1;
            comboBox_DataBits.SelectedIndex = 3;
            comboBox_mode.SelectedIndex = 0;



            // How to get the correct value from SerialPort.BytesToRead?
            // SerialPort.DataReceived Event
            // https://docs.microsoft.com/en-us/dotnet/api/system.io.ports.serialport.datareceived?redirectedfrom=MSDN&view=dotnet-plat-ext-5.0
           // serialPort1.DataReceived += new SerialDataReceivedEventHandler(DataReceivedHandler);

            string[] command_devices = new string[] { "0-烘乾機", "1-洗脫機", "3-下洗上烘機" };
            comboBox_devices.Items.AddRange(command_devices);
            comboBox_devices.SelectedIndex = 1;

            string[] command_money = new string[] { "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "10" };
            comboBox_money.Items.AddRange(command_money);
            comboBox_money.SelectedIndex = 1;
        }

        private void button_reflash_Click(object sender, EventArgs e)
        {
            button_open.Enabled = true ;
            button_close.Enabled = false;

            comboBox_port.Items.Clear();
            string[] ports = SerialPort.GetPortNames();
            comboBox_port.Items.AddRange(ports);
            comboBox_port.SelectedIndex = ports.Length - 1;
            button_close.Enabled = false;

            try
            {
                serialPort1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }


        private static void DataReceivedHandler(
                object sender,
                SerialDataReceivedEventArgs e)
        {
            SerialPort sp = (SerialPort)sender;
            if (sp.BytesToRead > 0)
            {
                byte[] read = new byte[sp.BytesToRead];
                sp.Read(read, 0, sp.BytesToRead);
                recevice_string = BitConverter.ToString(read);
            }
        }

        private void button_open_Click(object sender, EventArgs e)
        {
            button_open.Enabled = false;
            button_close.Enabled = true;

            serialPort1.RtsEnable = true;

            // BaudRate
            serialPort1.BaudRate = Int32.Parse(comboBox_BaudRate.Text);

            // 停止位元
            if (comboBox_StopBits.SelectedIndex == 0)
            {
                serialPort1.StopBits = StopBits.None;
            }

            if (comboBox_StopBits.SelectedIndex == 1)
            {
                serialPort1.StopBits = StopBits.One;
            }

            if (comboBox_StopBits.SelectedIndex == 2)
            {
                serialPort1.StopBits = StopBits.Two;
            }

            // 資料位元
            if (comboBox_DataBits.SelectedIndex == 0)
            {
                serialPort1.DataBits = 5;
            }

            if (comboBox_DataBits.SelectedIndex == 1)
            {
                serialPort1.DataBits = 6;
            }

            if (comboBox_DataBits.SelectedIndex == 2)
            {
                serialPort1.DataBits = 7;
            }

            if (comboBox_DataBits.SelectedIndex == 3)
            {
                serialPort1.DataBits = 8;
            }

            serialPort1.Handshake = Handshake.None;

            // 校驗
            // 無校驗
            if (comboBox_Parity.SelectedIndex == 0)
            {
                serialPort1.Parity = Parity.None;
            }

            // 奇同位
            if (comboBox_Parity.SelectedIndex == 1)
            {
                serialPort1.Parity = Parity.Odd;
            }

            // 偶同位
            if (comboBox_Parity.SelectedIndex == 2)
            {
                serialPort1.Parity = Parity.Even;
            }


            serialPort1.Handshake = Handshake.None;

            try
            { 
            serialPort1.PortName = comboBox_port.Text;
            serialPort1.Open();
            } 
            catch(Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }

        }

        private void button_close_Click(object sender, EventArgs e)
        {
            button_open.Enabled = true;
            button_close.Enabled = false;

            try
            {
                serialPort1.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void button_write_Click(object sender, EventArgs e)
        {
            recevice_string = null;

            int address_int = Convert.ToInt32(textBox_address.Text, 16);
            byte address_byte = Convert.ToByte(address_int);

            byte[] send_byte = { address_byte, 0x6,0,1,0,1,0,0}; //洗烘
            byte[] crc_byte = {0,0};

            // 讀寫模式
            string[] mode_var = comboBox_mode.Text.Split('-');
            int mode_value = Convert.ToInt32(mode_var[0], 16);
            byte mode_byte = Convert.ToByte(mode_value);
            send_byte[1] = mode_byte;

            string[] com_var = comboBox_cmd.Text.Split('-');
            int value = Convert.ToInt32(com_var[0], 16);
            byte cmd_byte = Convert.ToByte(value);
            send_byte[3] = Convert.ToByte(value);

            // 0-烘乾機
            if (comboBox_devices.SelectedIndex == 0)
            {
                // 選擇程式號
                if (cmd_byte == 0x1 || cmd_byte == 0x33)
                {
                    // 0高溫，1中溫，2低溫
                    send_byte[5] = (byte)comboBox_option.SelectedIndex;
                }

                // 金額
                if (cmd_byte == 0x2 || cmd_byte == 0x34)
                {
                    // 放大100倍，如8要下發800
                    ushort temp_var = (ushort)(Convert.ToInt32(comboBox_money.Text) * 100);
                    send_byte[4] = (byte)((temp_var >> 8) & 0xFF);
                    send_byte[5] = (byte)(temp_var & 0xFF);
                }

                // 3-指令
                if (cmd_byte == 0x3 || cmd_byte == 0x35)
                {

                }

                // 當前程式運行需付的最小金額
                if (cmd_byte == 0x10 || cmd_byte == 0x42)
                {
                    // 放大100倍，如8要下發800
                    ushort temp_var = (ushort)(Convert.ToInt32(comboBox_money.Text));
                    //send_byte[4] = (byte)((temp_var >> 8) & 0xFF);
                    send_byte[1] = 0x3;
                    send_byte[5] = (byte)(temp_var & 0xFF);
                }


                // 11-當前巳付金額
                if (send_byte[3] == 0x11 || cmd_byte == 0x43)
                {
                    // 放大100倍，如8要下發800
                    ushort temp_var = (ushort)(Convert.ToInt32(comboBox_money.Text) * 100);
                    send_byte[4] = (byte)((temp_var >> 8) & 0xFF);
                    send_byte[5] = (byte)(temp_var & 0xFF);
                }

                // 12-當前選擇的程式號
                if (cmd_byte == 0x12 || cmd_byte == 0x44)
                {
                    // 0高溫，1中溫，2低溫
                    send_byte[5] = (byte)comboBox_option.SelectedIndex;
                }

                // 13-運行狀態
                if (cmd_byte == 0x13 || cmd_byte == 0x45)
                {
                    com_var = comboBox_option.Text.Split('-');
                    value = Convert.ToInt32(com_var[0], 16);
                    send_byte[5] = Convert.ToByte(value);
                }

                if (cmd_byte == 0x14 || cmd_byte == 0x15 || cmd_byte == 0x16 || cmd_byte == 0x46 || cmd_byte == 0x47 || cmd_byte == 0x48)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 17-HMI故障組
                if (cmd_byte == 0x17 || cmd_byte == 0x49)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 18-故障組1
                if (cmd_byte == 0x18 || cmd_byte == 0x4A)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 19-故障組2
                if (cmd_byte == 0x19 || cmd_byte == 0x4B)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1A-報警
                if (cmd_byte == 0x1A || cmd_byte == 0x4C)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1B-當前進風口溫度
                if (cmd_byte == 0x1B || cmd_byte == 0x4D)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1C-當前出風口溫度
                if (cmd_byte == 0x1C || cmd_byte == 0x4E)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1D-開關量輸入
                if (cmd_byte == 0x1D || cmd_byte == 0x4F)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1E-繼電器輸出
                if (cmd_byte == 0x1E || cmd_byte == 0x50)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1C-當前出風口溫度
                if (cmd_byte == 0x1C || cmd_byte == 0x4E)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1F-烘乾總時間
                if (cmd_byte == 0x1F || cmd_byte == 0x51)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }


                // 20-投幣總金額低16位
                if (cmd_byte == 0x20 || cmd_byte == 0x52)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }


                // 21-投幣金額高16位
                if (cmd_byte == 0x21 || cmd_byte == 0x53)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }


                // 22-外部支付總金額低16位
                if (cmd_byte == 0x22 || cmd_byte == 0x54)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 23-外部支付總金額高16位
                if (cmd_byte == 0x23 || cmd_byte == 0x55)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 25-當前錢箱幣數
                if (cmd_byte == 0x25 || cmd_byte == 0x56)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 61-程式價格
                if (cmd_byte == 0x61)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

            }

            // 0-洗脫機
            if (comboBox_devices.SelectedIndex == 1)
            {
                // 選擇程式號
                if (cmd_byte == 0x1)
                {
                    // 0高溫，1中溫，2低溫
                    send_byte[5] = (byte)comboBox_option.SelectedIndex;
                }

                // 金額
                if (cmd_byte == 0x2)
                {
                    // 放大100倍，如8要下發800
                    ushort temp_var = (ushort)(Convert.ToInt32(comboBox_money.Text) * 100);
                    send_byte[4] = (byte)((temp_var >> 8) & 0xFF);
                    send_byte[5] = (byte)(temp_var & 0xFF);
                }

                // 3-指令
                if (cmd_byte == 0x3)
                {
                    send_byte[4] = send_byte[5] = 0x0;

                }

                // 6-機器類型
                if (cmd_byte == 0x6)
                {
                    send_byte[4] = send_byte[5] = 0x0;

                }

                // 10-當前程式需付總金額
                if (cmd_byte == 0x10)
                {
                    send_byte[4] = send_byte[5] = 0x0;
                }


                // 11-當前巳付金額
                if (send_byte[3] == 0x11)
                {
                    // 放大100倍，如8要下發800
                    ushort temp_var = (ushort)(Convert.ToInt32(comboBox_money.Text) * 100);
                    send_byte[4] = (byte)((temp_var >> 8) & 0xFF);
                    send_byte[5] = (byte)(temp_var & 0xFF);
                }

                // 12-當前選擇的程式號
                if (cmd_byte == 0x12)
                {
                    // 0高溫，1中溫，2低溫
                    send_byte[5] = (byte)comboBox_option.SelectedIndex;
                }

                // 13-運行狀態
                if (cmd_byte == 0x13)
                {
                    com_var = comboBox_option.Text.Split('-');
                    value = Convert.ToInt32(com_var[0], 16);
                    send_byte[5] = Convert.ToByte(value);
                }

                // 14-運行剩餘時間(時)", "15-運行剩餘時間(分)", "16-運行剩餘時間(秒)
                if (cmd_byte == 0x14 || cmd_byte == 0x15 || cmd_byte == 0x16)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 17-HMI故障組
                if (cmd_byte == 0x17)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 18-故障組1
                if (cmd_byte == 0x18)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 19-故障組2
                if (cmd_byte == 0x19)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1A-報警
                if (cmd_byte == 0x1A)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1B-當前液位
                if (cmd_byte == 0x1B)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1C-當前溫度
                if (cmd_byte == 0x1C)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1D-開關量輸入
                if (cmd_byte == 0x1D)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1E-繼電器輸出
                if (cmd_byte == 0x1E)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1F-繼電器輸出2
                if (cmd_byte == 0x1F)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 20-運行次數
                if (cmd_byte == 0x20)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }


                // 21-投幣金額高16位
                if (cmd_byte == 0x21)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }


                // 22-投幣金額低16位
                if (cmd_byte == 0x22)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 23-外部支付總金額低16位
                if (cmd_byte == 0x23)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 24-外部支付總金額高16位
                if (cmd_byte == 0x24)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 25-當前錢箱幣數
                if (cmd_byte == 0x25)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

            }

            // 0-下洗上烘
            if (comboBox_devices.SelectedIndex == 2)
            {
                // 選擇程式號
                if (cmd_byte == 0x1 || cmd_byte == 0x33)
                {
                    // 0高溫，1中溫，2低溫
                    send_byte[5] = (byte)comboBox_option.SelectedIndex;
                }

                // 金額
                if (cmd_byte == 0x2 || cmd_byte == 0x34)
                {
                    // 放大100倍，如8要下發800
                    ushort temp_var = (ushort)(Convert.ToInt32(comboBox_money.Text) * 100);
                    send_byte[4] = (byte)((temp_var >> 8) & 0xFF);
                    send_byte[5] = (byte)(temp_var & 0xFF);
                }

                // 3-指令，上烘
                if (cmd_byte == 0x35)
                {

                }

                // 當前程式運行需付的最小金額
                if (cmd_byte == 0x10 || cmd_byte == 0x42)
                {
                    // 放大100倍，如8要下發800
                    ushort temp_var = (ushort)(Convert.ToInt32(comboBox_money.Text));
                    //send_byte[4] = (byte)((temp_var >> 8) & 0xFF);
                    send_byte[1] = 0x3;
                    send_byte[5] = (byte)(temp_var & 0xFF);
                }


                // 11-當前巳付金額
                if (send_byte[3] == 0x11 || cmd_byte == 0x43)
                {
                    // 放大100倍，如8要下發800
                    ushort temp_var = (ushort)(Convert.ToInt32(comboBox_money.Text) * 100);
                    send_byte[4] = (byte)((temp_var >> 8) & 0xFF);
                    send_byte[5] = (byte)(temp_var & 0xFF);
                }

                // 12-當前選擇的程式號
                if (cmd_byte == 0x12 || cmd_byte == 0x44)
                {
                    // 0高溫，1中溫，2低溫
                    send_byte[5] = (byte)comboBox_option.SelectedIndex;
                }

                // 13-運行狀態
                if (cmd_byte == 0x13 || cmd_byte == 0x45)
                {
                    com_var = comboBox_option.Text.Split('-');
                    value = Convert.ToInt32(com_var[0], 16);
                    send_byte[5] = Convert.ToByte(value);
                }

                // 运行剩余时间
                if (cmd_byte == 0x14 || cmd_byte == 0x15 || cmd_byte == 0x16 || cmd_byte == 0x46 || cmd_byte == 0x47 || cmd_byte == 0x48)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 17-HMI故障組
                if (cmd_byte == 0x17 || cmd_byte == 0x49)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 18-故障組1
                if (cmd_byte == 0x18 || cmd_byte == 0x4A)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 19-故障組2
                if (cmd_byte == 0x19 || cmd_byte == 0x4B)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1A-報警
                if (cmd_byte == 0x1A || cmd_byte == 0x4C)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1B-當前進風口溫度 4D当前进风口温度
                if (cmd_byte == 0x1B || cmd_byte == 0x4D)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1C-當前出風口溫度 4E当前出风口温度
                if (cmd_byte == 0x1C || cmd_byte == 0x4E)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1D-開關量輸入 4F-备用
                if (cmd_byte == 0x1D || cmd_byte == 0x4F)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1E-繼電器輸出 50-备用
                if (cmd_byte == 0x1E || cmd_byte == 0x50)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1C-當前出風口溫度
                if (cmd_byte == 0x1C || cmd_byte == 0x4E)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1F-备用
                if (cmd_byte == 0x1F)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 1F-烘乾總時間
                if ( cmd_byte == 0x51)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }


                // 20-投幣總金額低16位
                if (cmd_byte == 0x20 || cmd_byte == 0x52)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }


                // 21-投幣金額高16位
                if (cmd_byte == 0x21 || cmd_byte == 0x53)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }


                // 22-外部支付總金額低16位
                if (cmd_byte == 0x22 || cmd_byte == 0x54)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 23-外部支付總金額高16位
                if (cmd_byte == 0x23 || cmd_byte == 0x55)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 25-當前錢箱幣數
                if (cmd_byte == 0x25 || cmd_byte == 0x56)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

                // 57-烘干次数
                if (cmd_byte == 0x57)
                {
                    send_byte[4] = 0;
                    send_byte[5] = 0;
                }

            }


            GetCRC(send_byte, ref crc_byte);
            send_byte[6] = crc_byte[0];
            send_byte[7] = crc_byte[1];
            BitConverter.ToString(send_byte);

            try
            {
                if (serialPort1.IsOpen)
                {
                    serialPort1.Write(send_byte,0, send_byte.Length);

                    // 收到的報文
                    //System.Threading.Thread.Sleep(300);

                    //richTextBox_read.Text = recevice_string;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            richTextBox_write.Text = BitConverter.ToString(send_byte);

            string path = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/MyTest.txt";
            // This text is added only once to the file.
            if (!File.Exists(path))
            {
                // Create a file to write to.
                using (StreamWriter sw = File.CreateText(path))
                {
                    // comboBox_money
                    sw.WriteLine("device" + comboBox_devices.Text);
                    sw.WriteLine("  address:" + textBox_address.Text);
                    sw.WriteLine("  rw_mode:" + comboBox_mode.Text);
                    sw.WriteLine("  command:" + comboBox_cmd.Text);
                    sw.WriteLine("  option:" + comboBox_option.Text);
                    sw.WriteLine("  money:" + comboBox_money.Text);
                    sw.WriteLine("  send:" + richTextBox_write.Text);
                    sw.Close();
                }
            }
            else
            {
                // This text is always added, making the file longer over time
                // if it is not deleted.
                using (StreamWriter sw = File.AppendText(path))
                {
                    sw.WriteLine("device" + comboBox_devices.Text);
                    sw.WriteLine("  address:" + textBox_address.Text);
                    sw.WriteLine("  rw_mode:" + comboBox_mode.Text);
                    sw.WriteLine("  command:" + comboBox_cmd.Text);
                    sw.WriteLine("  option:" + comboBox_option.Text);
                    sw.WriteLine("  money:" + comboBox_money.Text);
                    sw.WriteLine("  send:" + richTextBox_write.Text);
                    sw.Close();
                }
            }


            
        }


        // Visual C# 2010 開發 Modbus CRC 演算
        // http://ezworker2010.blogspot.com/2011/10/visual-c-2010-modbus-crc.html
        private void GetCRC(byte[] message, ref byte[] CRC) // message : Modbus指令 ； CRC : 2 Byte Checksum
        {
            ushort CRCFull = 0xFFFF; // CRC 的初值設成 0xFFFF
            byte CRCHigh = 0xFF, CRCLow = 0xFF; // CRC 的 High byte 和 Low byte
            char CRCLSB; // CRC Least signficant bit

            for (int i = 0; i < (message.Length) - 2; i++)
            {
                CRCFull = (ushort)(CRCFull ^ message[i]); // exclusive or 

                for (int j = 0; j < 8; j++)
                {
                    CRCLSB = (char)(CRCFull & 0x0001); // 取得 Least signficant bit
                    CRCFull = (ushort)((CRCFull >> 1) & 0x7FFF); // 移去 Least signficant bit，前補0

                    if (CRCLSB == 1) // 如果 Least signficant bit 為 1
                        CRCFull = (ushort)(CRCFull ^ 0xA001);
                }
            }
            CRC[1] = CRCHigh = (byte)((CRCFull >> 8) & 0xFF); // CRC high byte 在 後
            CRC[0] = CRCLow = (byte)(CRCFull & 0xFF); // CRC low byte 在前
        }


        static ushort CRC16(byte[] pDataBytes)
        {
            ushort crc = 0xffff;
            ushort polynom = 0xA001;

            for (int i = 0; i < pDataBytes.Length; i++)
            {
                crc ^= pDataBytes[i];
                for (int j = 0; j < 8; j++)
                {
                    if ((crc & 0x01) == 0x01)
                    {
                        crc >>= 1;
                        crc ^= polynom;
                    }
                    else
                    {
                        crc >>= 1;
                    }
                }
            }
            return crc;
        }



        private void button_read_Click(object sender, EventArgs e)
        {
            // C# String To Byte Array
            // https://www.c-sharpcorner.com/article/c-sharp-string-to-byte-array/

            // byte[] to hex string [duplicate]
            // https://stackoverflow.com/questions/623104/byte-to-hex-string

            try
            {
                string rec_string = "";
                rec_string = serialPort1.ReadExisting();
                byte[] bytes = Encoding.ASCII.GetBytes(rec_string);
                richTextBox_read.Text = BitConverter.ToString(bytes);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Message", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void Form1_FormClosing(object sender, FormClosingEventArgs e)
        {
            if (serialPort1.IsOpen)
            {
                serialPort1.Close();
            }
        }

        private void comboBox_devices_SelectedIndexChanged(object sender, EventArgs e)
        {
            comboBox_cmd.Items.Clear();

            switch (comboBox_devices.SelectedIndex)
            {
                
                case 0:
                    string[] command_dry = new string[] { "1-A選擇程式號", "2-金額", "3-指令",  "10-當前程式需付的最小金額", "11-當前巳付金額", "12-當前選擇的程式號",
                    "13-運行狀態", "14-運行剩餘時間(時)", "15-運行剩餘時間(分)", "16-運行剩餘時間(秒)",
                    "17-HMI故障組","18-故障組1","19-故障組2","1A-報警","1B-當前進風口溫度","1C-當前出風口溫度","1D-開關量輸入","1E-繼電器輸出","1F-烘乾總時間",
                    "20-投幣總金額低16位", "21-投幣總金額高16位","22-外部支付總金額低16位","23-外部支付總金額高16位","24-當前錢箱幣數"};
                    comboBox_cmd.Items.AddRange(command_dry);

                    foreach (string i in command_dry)
                    {
                        string[] subs = i.Split('-');
                        int value = Convert.ToInt32(subs[0], 16);
                        value = value + 50;
                        byte BN = Convert.ToByte(value);
                        byte[] BU = new byte[1] { BN };
                        subs[0] = BitConverter.ToString(BU);
                        comboBox_cmd.Items.Add(subs[0] + "-" + subs[1]);
                    }
                    comboBox_cmd.Items.Add("61-程式價格");

                    break;
                case 1:
                    string[] command_wash = new string[] { "1-B選擇程式號", "2-金額", "3-指令", "6-機器類型", "10-當前程式需付總金額", "11-當前巳付金額", "12-當前程式號",
                    "13-運行狀態", "14-運行剩餘時間(時)", "15-運行剩餘時間(分)", "16-運行剩餘時間(秒)",
                    "17-HMI故障組","18-故障組1","19-故障組2","1A-報警","1B-當前液位","1C-當前溫度","1D-開關量輸入","1E-繼電器輸出1","1F-繼電器輸出2","20-運行次數",
                    "21-投幣金額低16位","22-投幣金額高16位","23-外部支付總金額低16位","24-外部支付總金額高16位","25-當前錢箱幣數"};
                    comboBox_cmd.Items.AddRange(command_wash);
                    break;
                case 2:
                    //Console.WriteLine("Case 2");
                    string[] command_wash_dry = new string[] { "1-c選擇程式號", "2-金額", "3-指令", "f-當前步驟類型", "10-當前程式需付金額", "11-當前巳付金額", "12 -當前程式號",
                    "13-運行狀態", "14-運行剩餘時間(時)", "15-運行剩餘時間(分)", "16-運行剩餘時間(秒)",
                    "17-HMI故障組","18-故障組1","19-故障組2","1A-報警","1B-當前液位","1C-當前溫度","1D-開關量輸入","1E-繼電器輸出1","1F-繼電器輸出2","20-運行次數",
                    "21-投幣金額低16位","22-投幣金額高16位","23-外部支付總金額低16位","24-外部支付總金額高16位","25-當前錢箱幣數",
                    "33-選擇程序號","34-金額","35-指令","42-當前程序運行需付的最小金額","43-當前已付的金額","44-當前選擇的程序號","45-運行狀態",
                    "46-運行剩餘時間（時）","47-運行剩餘時間（分）","48-運行剩餘時間（秒）","49-HMI故障組","4A-故障組",
                    "4B-故障組2","4C-報警","4D-當前進風口溫度","4E-當前出風口溫度","4F-備用","50-備用",
                    "51-烘乾總時間","52-投幣總金額（低16位）","53-投幣總金額（高16位）","54-外部支付總金額（低16位）" ,
                    "55-外部支付總金額（低16位）","56-當前錢箱幣數","57-烘乾次數" };

                    comboBox_cmd.Items.AddRange(command_wash_dry);
                    break;
                default:
                    //Console.WriteLine("Default case");
                    string[] command_dry_x = new string[] { "1-X選擇程式號", "2-金額", "3-指令",  "10-當前程式需付的最小金額", "11-當前巳付金額", "12-當前選擇的程式號",
                    "13-運行狀態", "14-運行剩餘時間(時)", "15-運行剩餘時間(分)", "16-運行剩餘時間(秒)",
                    "17-HMI故障組","18-故障組1","19-故障組2","1A-報警","1B-當前進風口溫度","1C-當前出風口溫度","1D-開關量輸入","1E-繼電器輸出","1F-烘乾總時間",
                    "20-投幣總金額低16位", "21-投幣總金額高16位","22-外部支付總金額低16位","23-外部支付總金額高16位","24-當前錢箱幣數"};
                    comboBox_cmd.Items.AddRange(command_dry_x);

                    break;
            }
            comboBox_cmd.SelectedIndex = 0;
        }

        private void comboBox_cmd_SelectedIndexChanged(object sender, EventArgs e)
        {
            label_cmd.Text = "資料地址：  " + comboBox_cmd.SelectedIndex.ToString();

            string[] com_var = comboBox_cmd.Text.Split('-');
            int value = Convert.ToInt32(com_var[0], 16);
            byte cmd_byte = Convert.ToByte(value);


            // 0-烘乾機
            if (comboBox_devices.SelectedIndex == 0)
            {

                // 1-c選擇程式號
                if (cmd_byte == 0x1 || cmd_byte == 0x33)
                {
                    comboBox_mode.SelectedIndex = 5; // 0x06
                    comboBox_option.Enabled = true;
                    comboBox_option.Items.Clear();
                    string[] option_var = { "0-高溫", "1-中溫", "2-低溫" };
                    comboBox_option.Items.AddRange(option_var);
                    comboBox_option.SelectedIndex = 0;
                    return;
                }

                // 2-金額
                if (cmd_byte == 0x2 || cmd_byte == 0x34)
                {
                    comboBox_mode.SelectedIndex = 5; // 0x06
                    comboBox_money.Enabled = true;
                    comboBox_option.Enabled = false;
                    return;
                }


                // 3-指令
                if (cmd_byte == 0x3 || cmd_byte == 0x35)
                {
                    comboBox_money.Enabled = false;
                    comboBox_option.Enabled = false;
                    return;
                }


                // 10-當前程式需付金額
                if (cmd_byte == 0x10 || cmd_byte == 0x42)
                {
                    comboBox_mode.SelectedIndex = 2; // 0x03
                    comboBox_money.Enabled = true;
                    comboBox_option.Enabled = false;
                    return;
                }

                // 11-當前巳付金額
                if (cmd_byte == 0x11 || cmd_byte == 0x43)
                {
                    comboBox_money.Enabled = true;
                    comboBox_option.Enabled = false;
                    return;
                }

                // 12-當前選擇的程式號
                if (cmd_byte == 0x12 || cmd_byte == 0x44)
                {
                    comboBox_option.Enabled = true;
                    comboBox_option.Items.Clear();
                    string[] option_var = { "0-高溫", "1-中溫", "2-低溫" };
                    comboBox_option.Items.AddRange(option_var);
                    comboBox_option.SelectedIndex = 0;
                }

                // 13-運行狀態
                if (cmd_byte == 0x13 || cmd_byte == 0x45)
                {
                    comboBox_option.Enabled = true;
                    comboBox_option.Items.Clear();
                    string[] option_var = { "1-空閒", "2-故障", "3-自動運行" };
                    comboBox_option.Items.AddRange(option_var);
                    comboBox_option.SelectedIndex = 0;
                    return;
                }

                // "14-運行剩餘時間(時)", "15-運行剩餘時間(分)", "16-運行剩餘時間(秒)"
                if (cmd_byte == 0x14 || cmd_byte == 0x15 || cmd_byte == 0x16 || cmd_byte == 0x46 || cmd_byte == 0x47 || cmd_byte == 0x48)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 17-HMI故障組
                if (cmd_byte == 0x17 || cmd_byte == 0x49)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }


                // 18-故障組1
                if (cmd_byte == 0x18 || cmd_byte == 0x4A)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 19-故障組2
                if (cmd_byte == 0x19 || cmd_byte == 0x4B)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }


                // 1A-報警
                if (cmd_byte == 0x1A || cmd_byte == 0x4C)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1B-當前進風口溫度
                if (cmd_byte == 0x1B || cmd_byte == 0x4D)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1C-當前出風口溫度
                if (cmd_byte == 0x1C || cmd_byte == 0x4E)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1D-開關量輸入
                if (cmd_byte == 0x1D || cmd_byte == 0x4F)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1E-繼電器輸出
                if (cmd_byte == 0x1E || cmd_byte == 0x50)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1F-烘乾總時間
                if (cmd_byte == 0x1F || cmd_byte == 0x51)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 20-投幣總金額低16位
                if (cmd_byte == 0x20 || cmd_byte == 0x52)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 21-投幣金額高16位
                if (cmd_byte == 0x21 || cmd_byte == 0x53)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 22-外部支付總金額低16位
                if (cmd_byte == 0x22 || cmd_byte == 0x54)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 23-外部支付總金額高16位
                if (cmd_byte == 0x23 || cmd_byte == 0x55)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 24-當前錢箱幣數
                if (cmd_byte == 0x24 || cmd_byte == 0x56)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

               
                // 61-程式價格
                if (cmd_byte == 0x61)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }
                
            }

            // 1-洗脫機
            if (comboBox_devices.SelectedIndex == 1)
            {
                // 1-c選擇程式號
                if (cmd_byte == 0x1)
                {
                    comboBox_mode.SelectedIndex = 5; // 0x06
                    comboBox_option.Enabled = true;
                    comboBox_option.Items.Clear();
                    string[] option_var = { "0-高溫", "1-中溫", "2-低溫" };
                    comboBox_option.Items.AddRange(option_var);
                    comboBox_option.SelectedIndex = 0;
                    return;
                }

                // 2-金額
                if (cmd_byte == 0x2)
                {
                    comboBox_money.Enabled = true;
                    comboBox_option.Enabled = false;
                    return;
                }

                // 3-指令
                if (cmd_byte == 0x3)
                {
                    comboBox_money.Enabled = false;
                    comboBox_option.Enabled = false;
                    return;
                }

                // 6-機器類型
                if (cmd_byte == 0x6)
                {
                    comboBox_money.Enabled = false;
                    comboBox_option.Enabled = false;
                    return;
                }

                // 10-當前程式需付金額
                if (cmd_byte == 0x10)
                {
                    comboBox_mode.SelectedIndex = 2; // 0x03
                    comboBox_money.Enabled = true;
                    comboBox_option.Enabled = false;
                    return;
                }

                // 11-當前巳付金額
                if (cmd_byte == 0x11)
                {
                    comboBox_money.Enabled = true;
                    comboBox_option.Enabled = false;
                    return;
                }

                // 12-當前選擇的程式號
                if (cmd_byte == 0x12)
                {
                    comboBox_option.Enabled = true;
                    comboBox_option.Items.Clear();
                    string[] option_var = { "0-高溫", "1-中溫", "2-低溫" };
                    comboBox_option.Items.AddRange(option_var);
                    comboBox_option.SelectedIndex = 0;
                    return;
                }

                // 13-運行狀態
                if (cmd_byte == 0x13)
                {
                    comboBox_option.Enabled = true;
                    comboBox_option.Items.Clear();
                    string[] option_var = { "0-無", "1-空閒", "2-故障", "3-自動運行" };
                    comboBox_option.Items.AddRange(option_var);
                    comboBox_option.SelectedIndex = 0;
                    return;
                }

                // "14-運行剩餘時間(時)", "15-運行剩餘時間(分)", "16-運行剩餘時間(秒)"
                if (cmd_byte == 0x14 || cmd_byte == 0x15 || cmd_byte == 0x16)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 17-HMI故障組
                if (cmd_byte == 0x17)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 18-故障組1
                if (cmd_byte == 0x18)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 19-故障組2
                if (cmd_byte == 0x19)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1A-報警
                if (cmd_byte == 0x1A)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1B-當前液位
                if (cmd_byte == 0x1B)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1C-當前溫度
                if (cmd_byte == 0x1C)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1D-開關量輸入
                if (cmd_byte == 0x1D )
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1E-繼電器輸出1
                if (cmd_byte == 0x1E)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1F-繼電器輸出2
                if (cmd_byte == 0x1F)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 20-運行次數
                if (cmd_byte == 0x20)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 21-投幣總金額低16位
                if (cmd_byte == 0x21)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 22-投幣金額高16位
                if (cmd_byte == 0x22)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 23-外部支付總金額低16位
                if (cmd_byte == 0x23)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 24-外部支付總金額高16位
                if (cmd_byte == 0x24)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 25-當前錢箱幣數
                if (cmd_byte == 0x25)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

            }

            // 3-下洗上烘機
            if (comboBox_devices.SelectedIndex == 2)
            {

                // 1-c選擇程式號
                if (cmd_byte == 0x1 || cmd_byte == 0x33)
                {
                    comboBox_mode.SelectedIndex = 5; // 0x06
                    comboBox_option.Enabled = true;
                    comboBox_option.Items.Clear();
                    string[] option_var = { "0-高溫", "1-中溫", "2-低溫" };
                    comboBox_option.Items.AddRange(option_var);
                    comboBox_option.SelectedIndex = 0;
                    return;
                }

                // 2-金額
                if (cmd_byte == 0x2 || cmd_byte == 0x34)
                {
                    comboBox_mode.SelectedIndex = 5; // 0x06
                    comboBox_money.Enabled = true;
                    comboBox_option.Enabled = false;
                    return;
                }

                // f-当前步骤类型
                if (cmd_byte == 0xf )
                {
                    comboBox_mode.SelectedIndex = 2; // 0x03
                    comboBox_money.Enabled = false;
                    comboBox_option.Enabled = false;
                    richTextBox_info.Text = "0 空 \n1 预洗\n2 主洗\n3 漂洗\n4 排水\n5 脱水\n6 松衣";
                    return;
                }

                // 10-當前程式需付金額
                if (cmd_byte == 0x10 || cmd_byte == 0x42)
                {
                    comboBox_mode.SelectedIndex = 2; // 0x03
                    comboBox_money.Enabled = true;
                    comboBox_option.Enabled = false;
                    return;
                }

                // 11-當前巳付金額
                if (cmd_byte == 0x11 || cmd_byte == 0x43)
                {
                    comboBox_money.Enabled = true;
                    comboBox_option.Enabled = false;
                    return;
                }

                // 12-當前選擇的程式號
                if (cmd_byte == 0x12 || cmd_byte == 0x44)
                {
                    comboBox_option.Enabled = true;
                    comboBox_option.Items.Clear();
                    string[] option_var = { "0-高溫", "1-中溫", "2-低溫" };
                    comboBox_option.Items.AddRange(option_var);
                    comboBox_option.SelectedIndex = 0;
                }

                // 13-運行狀態
                if (cmd_byte == 0x13)
                {
                    comboBox_option.Enabled = true;
                    comboBox_option.Items.Clear();
                    string[] option_var = { "1-空閒", "2-故障", "3-自動運行" };
                    comboBox_option.Items.AddRange(option_var);
                    comboBox_option.SelectedIndex = 0;
                    richTextBox_info.Text = "运行状态：只有在空闲时进行的选程序号及支付金额的操作才有效\n1:空闲\n2:故障\n3:自动运行\n4:预约\n5:暂停服务";
                    return;
                }


                // 45-運行狀態
                if ( cmd_byte == 0x45)
                {
                    comboBox_option.Enabled = true;
                    comboBox_option.Items.Clear();
                    string[] option_var = { "1-空閒", "2-故障", "3-自動運行", "4-预约", "5-暂停服务" };
                    comboBox_option.Items.AddRange(option_var);
                    comboBox_option.SelectedIndex = 0;
                    richTextBox_info.Text = "1:空闲\n2:故障\n3:自动运行\n4:预约\n5:暂停服务";
                    return;
                }


                // "14-運行剩餘時間(時)", "15-運行剩餘時間(分)", "16-運行剩餘時間(秒)"
                if (cmd_byte == 0x14 || cmd_byte == 0x15 || cmd_byte == 0x16 || cmd_byte == 0x46 || cmd_byte == 0x47 || cmd_byte == 0x48)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 17-HMI故障組
                if (cmd_byte == 0x17 || cmd_byte == 0x49)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 18-故障組1
                if (cmd_byte == 0x18 || cmd_byte == 0x4A)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                   // richTextBox_info.Text = "故障组(一个字包含16个故障, 按位标识, 如bit0为1时表示出现门状态异常故障)";

                    if (cmd_byte == 0x4A)
                    {
                        richTextBox_info.Text = "备用\n出风口温度探头故障\n进风口温度探头故障\n电机过载\n电过热\n出风口温度过高\n进风口温度过高";
                    }
                    return;
                }

                // 19-故障組2
                if (cmd_byte == 0x19 || cmd_byte == 0x4B)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    richTextBox_info.Text = "故障组(一个字包含16个故障, 按位标识, 如bit0为1时表示出现门状态异常故障)";
                    return;
                }

                // 1A-報警
                if (cmd_byte == 0x1A || cmd_byte == 0x4C)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 1B-当前液位
                if (cmd_byte == 0x1B || cmd_byte == 0x4D)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    if (cmd_byte == 0x4D)
                    {
                        richTextBox_info.Text = "当前进风口温度";
                    }
                    return;
                }

                // 1C-当前温度
                if (cmd_byte == 0x1C || cmd_byte == 0x4E)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    if (cmd_byte == 0x4E)
                    {
                        richTextBox_info.Text = "当前进风口温度";
                    }
                    return;
                }

                // 1D-開關量輸入
                if (cmd_byte == 0x1D || cmd_byte == 0x4F)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    if (cmd_byte == 0x1D)
                    {
                        richTextBox_info.Text = "紧急停止\n超震\n钱箱关\n门开关\n门销\n门开关（烘）\n温度过热（烘）";
                    }
                    
                    return;
                }

                // 1E-繼電器輸出
                if (cmd_byte == 0x1E || cmd_byte == 0x50)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    if (cmd_byte == 0x1E)
                    {
                        richTextBox_info.Text = "门锁开\n门锁关\n备用\n备用\n电机正转（烘）\n电机反转（烘）\n加热（烘）\n风机（烘）\n皂液1\n皂液2\n皂液3\n皂液4\n皂液5\n冷水\n热水\n排水";
                    }
                    
                    return;
                }

                // 1F-烘乾總時間
                if (cmd_byte == 0x1F || cmd_byte == 0x51)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    richTextBox_info.Text = "加热\n备用\n投币器电源\n投币器电源（烘）\n正转\n反转\nSS1\nSS2\nSS3\n2nd";
                    return;
                }

                // 20-投幣總金額低16位
                if (cmd_byte == 0x20 || cmd_byte == 0x52)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 21-投幣金額高16位
                if (cmd_byte == 0x21 || cmd_byte == 0x53)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 22-外部支付總金額低16位
                if (cmd_byte == 0x22 || cmd_byte == 0x54)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 23-外部支付總金額高16位
                if (cmd_byte == 0x23 || cmd_byte == 0x55)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 24-當前錢箱幣數
                if (cmd_byte == 0x24 || cmd_byte == 0x56)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 烘干次数
                if (cmd_byte == 0x57)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    richTextBox_info.Text = "V101版本增加";
                    return;
                }

                // 25-当前钱箱币数
                if (cmd_byte == 0x25)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    return;
                }

                // 35-指令
                if (cmd_byte == 0x35)
                {
                    comboBox_option.Enabled = false;
                    comboBox_option.Items.Clear();
                    comboBox_money.Enabled = false;
                    richTextBox_info.Text = "停机（bit0)\n设置预约状态（bit8)\n恢复正常状态（bit9)\n设置暂停服务状态（bit10)";
                    return;
                }

            }

        }



        private void button_folder_Click(object sender, EventArgs e)
        {
            string rootPath = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments);
            System.Diagnostics.Process.Start("explorer.exe", rootPath);

        }



        private void serialPort1_DataReceived(object sender, SerialDataReceivedEventArgs e)
        {
            byte[] read = new byte[serialPort1.BytesToRead];
            serialPort1.Read(read, 0, serialPort1.BytesToRead);
            recevice_string = BitConverter.ToString(read);
            richTextBox_read.Text = richTextBox_read.Text + recevice_string + "\r\n";

            string path = System.Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments) + "/MyTest.txt";
            using (StreamWriter sw = File.AppendText(path))
            {
                sw.WriteLine("  recevice:" + richTextBox_read.Text);
                sw.Close();
            }
        }


    }
}
