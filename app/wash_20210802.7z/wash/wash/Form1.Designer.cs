﻿namespace wash
{
    partial class Form1
    {
        /// <summary>
        /// 設計工具所需的變數。
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// 清除任何使用中的資源。
        /// </summary>
        /// <param name="disposing">如果應該處置受控資源則為 true，否則為 false。</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form 設計工具產生的程式碼

        /// <summary>
        /// 此為設計工具支援所需的方法 - 請勿使用程式碼編輯器修改
        /// 這個方法的內容。
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.comboBox_port = new System.Windows.Forms.ComboBox();
            this.button_open = new System.Windows.Forms.Button();
            this.button_close = new System.Windows.Forms.Button();
            this.label1 = new System.Windows.Forms.Label();
            this.richTextBox_write = new System.Windows.Forms.RichTextBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label3 = new System.Windows.Forms.Label();
            this.richTextBox_read = new System.Windows.Forms.RichTextBox();
            this.button_write = new System.Windows.Forms.Button();
            this.comboBox_cmd = new System.Windows.Forms.ComboBox();
            this.label_cmd = new System.Windows.Forms.Label();
            this.label5 = new System.Windows.Forms.Label();
            this.comboBox_devices = new System.Windows.Forms.ComboBox();
            this.comboBox_option = new System.Windows.Forms.ComboBox();
            this.label_option = new System.Windows.Forms.Label();
            this.comboBox_money = new System.Windows.Forms.ComboBox();
            this.label7 = new System.Windows.Forms.Label();
            this.button_folder = new System.Windows.Forms.Button();
            this.textBox_address = new System.Windows.Forms.TextBox();
            this.label4 = new System.Windows.Forms.Label();
            this.comboBox_BaudRate = new System.Windows.Forms.ComboBox();
            this.label6 = new System.Windows.Forms.Label();
            this.label8 = new System.Windows.Forms.Label();
            this.comboBox_Parity = new System.Windows.Forms.ComboBox();
            this.label9 = new System.Windows.Forms.Label();
            this.comboBox_StopBits = new System.Windows.Forms.ComboBox();
            this.label10 = new System.Windows.Forms.Label();
            this.comboBox_DataBits = new System.Windows.Forms.ComboBox();
            this.button_reflash = new System.Windows.Forms.Button();
            this.label11 = new System.Windows.Forms.Label();
            this.comboBox_mode = new System.Windows.Forms.ComboBox();
            this.richTextBox_info = new System.Windows.Forms.RichTextBox();
            this.label12 = new System.Windows.Forms.Label();
            this.serialPort1 = new System.IO.Ports.SerialPort(this.components);
            this.SuspendLayout();
            // 
            // comboBox_port
            // 
            this.comboBox_port.FormattingEnabled = true;
            this.comboBox_port.Location = new System.Drawing.Point(171, 22);
            this.comboBox_port.Name = "comboBox_port";
            this.comboBox_port.Size = new System.Drawing.Size(157, 20);
            this.comboBox_port.TabIndex = 0;
            // 
            // button_open
            // 
            this.button_open.Location = new System.Drawing.Point(369, 22);
            this.button_open.Name = "button_open";
            this.button_open.Size = new System.Drawing.Size(117, 27);
            this.button_open.TabIndex = 1;
            this.button_open.Text = "開啟 open";
            this.button_open.UseVisualStyleBackColor = true;
            this.button_open.Click += new System.EventHandler(this.button_open_Click);
            // 
            // button_close
            // 
            this.button_close.Location = new System.Drawing.Point(369, 63);
            this.button_close.Name = "button_close";
            this.button_close.Size = new System.Drawing.Size(117, 27);
            this.button_close.TabIndex = 2;
            this.button_close.Text = "關閉 close";
            this.button_close.UseVisualStyleBackColor = true;
            this.button_close.Click += new System.EventHandler(this.button_close_Click);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(13, 30);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(63, 12);
            this.label1.TabIndex = 3;
            this.label1.Text = "串口號 port";
            // 
            // richTextBox_write
            // 
            this.richTextBox_write.Location = new System.Drawing.Point(93, 251);
            this.richTextBox_write.Name = "richTextBox_write";
            this.richTextBox_write.Size = new System.Drawing.Size(393, 136);
            this.richTextBox_write.TabIndex = 4;
            this.richTextBox_write.Text = "";
            // 
            // label2
            // 
            this.label2.AutoSize = true;
            this.label2.Location = new System.Drawing.Point(13, 254);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(55, 12);
            this.label2.TabIndex = 5;
            this.label2.Text = "發送 Send";
            // 
            // label3
            // 
            this.label3.AutoSize = true;
            this.label3.Location = new System.Drawing.Point(13, 443);
            this.label3.Name = "label3";
            this.label3.Size = new System.Drawing.Size(74, 12);
            this.label3.TabIndex = 7;
            this.label3.Text = "接收 Recevice";
            // 
            // richTextBox_read
            // 
            this.richTextBox_read.Location = new System.Drawing.Point(93, 443);
            this.richTextBox_read.Name = "richTextBox_read";
            this.richTextBox_read.Size = new System.Drawing.Size(393, 136);
            this.richTextBox_read.TabIndex = 6;
            this.richTextBox_read.Text = "";
            // 
            // button_write
            // 
            this.button_write.Location = new System.Drawing.Point(387, 393);
            this.button_write.Name = "button_write";
            this.button_write.Size = new System.Drawing.Size(99, 27);
            this.button_write.TabIndex = 8;
            this.button_write.Text = "寫入 write";
            this.button_write.UseVisualStyleBackColor = true;
            this.button_write.Click += new System.EventHandler(this.button_write_Click);
            // 
            // comboBox_cmd
            // 
            this.comboBox_cmd.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_cmd.FormattingEnabled = true;
            this.comboBox_cmd.Location = new System.Drawing.Point(513, 218);
            this.comboBox_cmd.Name = "comboBox_cmd";
            this.comboBox_cmd.Size = new System.Drawing.Size(305, 24);
            this.comboBox_cmd.TabIndex = 10;
            this.comboBox_cmd.SelectedIndexChanged += new System.EventHandler(this.comboBox_cmd_SelectedIndexChanged);
            // 
            // label_cmd
            // 
            this.label_cmd.AutoSize = true;
            this.label_cmd.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label_cmd.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_cmd.Location = new System.Drawing.Point(513, 197);
            this.label_cmd.Name = "label_cmd";
            this.label_cmd.Size = new System.Drawing.Size(72, 16);
            this.label_cmd.TabIndex = 11;
            this.label_cmd.Text = "資料地址";
            // 
            // label5
            // 
            this.label5.AutoSize = true;
            this.label5.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label5.Location = new System.Drawing.Point(510, 30);
            this.label5.Name = "label5";
            this.label5.Size = new System.Drawing.Size(40, 16);
            this.label5.TabIndex = 13;
            this.label5.Text = "設備";
            // 
            // comboBox_devices
            // 
            this.comboBox_devices.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_devices.FormattingEnabled = true;
            this.comboBox_devices.Location = new System.Drawing.Point(510, 51);
            this.comboBox_devices.Name = "comboBox_devices";
            this.comboBox_devices.Size = new System.Drawing.Size(305, 24);
            this.comboBox_devices.TabIndex = 12;
            this.comboBox_devices.SelectedIndexChanged += new System.EventHandler(this.comboBox_devices_SelectedIndexChanged);
            // 
            // comboBox_option
            // 
            this.comboBox_option.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_option.FormattingEnabled = true;
            this.comboBox_option.Location = new System.Drawing.Point(513, 272);
            this.comboBox_option.Name = "comboBox_option";
            this.comboBox_option.Size = new System.Drawing.Size(305, 24);
            this.comboBox_option.TabIndex = 14;
            // 
            // label_option
            // 
            this.label_option.AutoSize = true;
            this.label_option.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label_option.Location = new System.Drawing.Point(513, 251);
            this.label_option.Name = "label_option";
            this.label_option.Size = new System.Drawing.Size(40, 16);
            this.label_option.TabIndex = 15;
            this.label_option.Text = "選項";
            // 
            // comboBox_money
            // 
            this.comboBox_money.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_money.FormattingEnabled = true;
            this.comboBox_money.Location = new System.Drawing.Point(515, 326);
            this.comboBox_money.Name = "comboBox_money";
            this.comboBox_money.Size = new System.Drawing.Size(305, 24);
            this.comboBox_money.TabIndex = 16;
            // 
            // label7
            // 
            this.label7.AutoSize = true;
            this.label7.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label7.Location = new System.Drawing.Point(513, 307);
            this.label7.Name = "label7";
            this.label7.Size = new System.Drawing.Size(72, 16);
            this.label7.TabIndex = 17;
            this.label7.Text = "投幣金額";
            // 
            // button_folder
            // 
            this.button_folder.Location = new System.Drawing.Point(513, 377);
            this.button_folder.Name = "button_folder";
            this.button_folder.Size = new System.Drawing.Size(146, 27);
            this.button_folder.TabIndex = 18;
            this.button_folder.Text = "打開目錄 open folder";
            this.button_folder.UseVisualStyleBackColor = true;
            this.button_folder.Click += new System.EventHandler(this.button_folder_Click);
            // 
            // textBox_address
            // 
            this.textBox_address.Location = new System.Drawing.Point(513, 114);
            this.textBox_address.Name = "textBox_address";
            this.textBox_address.Size = new System.Drawing.Size(44, 22);
            this.textBox_address.TabIndex = 19;
            this.textBox_address.Text = "1";
            // 
            // label4
            // 
            this.label4.AutoSize = true;
            this.label4.Location = new System.Drawing.Point(511, 99);
            this.label4.Name = "label4";
            this.label4.Size = new System.Drawing.Size(102, 12);
            this.label4.TabIndex = 20;
            this.label4.Text = "機台地址，Address";
            // 
            // comboBox_BaudRate
            // 
            this.comboBox_BaudRate.FormattingEnabled = true;
            this.comboBox_BaudRate.Items.AddRange(new object[] {
            "9600",
            "115200"});
            this.comboBox_BaudRate.Location = new System.Drawing.Point(171, 59);
            this.comboBox_BaudRate.Name = "comboBox_BaudRate";
            this.comboBox_BaudRate.Size = new System.Drawing.Size(157, 20);
            this.comboBox_BaudRate.TabIndex = 21;
            // 
            // label6
            // 
            this.label6.AutoSize = true;
            this.label6.Location = new System.Drawing.Point(12, 66);
            this.label6.Name = "label6";
            this.label6.Size = new System.Drawing.Size(90, 12);
            this.label6.TabIndex = 22;
            this.label6.Text = "波特率 BaudRate";
            // 
            // label8
            // 
            this.label8.AutoSize = true;
            this.label8.Location = new System.Drawing.Point(12, 138);
            this.label8.Name = "label8";
            this.label8.Size = new System.Drawing.Size(83, 12);
            this.label8.TabIndex = 24;
            this.label8.Text = "数据校验 Parity";
            // 
            // comboBox_Parity
            // 
            this.comboBox_Parity.FormattingEnabled = true;
            this.comboBox_Parity.Items.AddRange(new object[] {
            "None 無校驗",
            "Odd 奇數",
            "Even 偶数"});
            this.comboBox_Parity.Location = new System.Drawing.Point(171, 133);
            this.comboBox_Parity.Name = "comboBox_Parity";
            this.comboBox_Parity.Size = new System.Drawing.Size(157, 20);
            this.comboBox_Parity.TabIndex = 23;
            // 
            // label9
            // 
            this.label9.AutoSize = true;
            this.label9.Location = new System.Drawing.Point(12, 174);
            this.label9.Name = "label9";
            this.label9.Size = new System.Drawing.Size(83, 12);
            this.label9.TabIndex = 26;
            this.label9.Text = "停止位 StopBits";
            // 
            // comboBox_StopBits
            // 
            this.comboBox_StopBits.FormattingEnabled = true;
            this.comboBox_StopBits.Items.AddRange(new object[] {
            "0",
            "1",
            "2"});
            this.comboBox_StopBits.Location = new System.Drawing.Point(171, 170);
            this.comboBox_StopBits.Name = "comboBox_StopBits";
            this.comboBox_StopBits.Size = new System.Drawing.Size(157, 20);
            this.comboBox_StopBits.TabIndex = 25;
            // 
            // label10
            // 
            this.label10.AutoSize = true;
            this.label10.Location = new System.Drawing.Point(12, 102);
            this.label10.Name = "label10";
            this.label10.Size = new System.Drawing.Size(95, 12);
            this.label10.TabIndex = 28;
            this.label10.Text = "有效数据 DataBits";
            // 
            // comboBox_DataBits
            // 
            this.comboBox_DataBits.FormattingEnabled = true;
            this.comboBox_DataBits.Items.AddRange(new object[] {
            "5 位",
            "6 位",
            "7 位",
            "8 位"});
            this.comboBox_DataBits.Location = new System.Drawing.Point(171, 96);
            this.comboBox_DataBits.Name = "comboBox_DataBits";
            this.comboBox_DataBits.Size = new System.Drawing.Size(157, 20);
            this.comboBox_DataBits.TabIndex = 27;
            // 
            // button_reflash
            // 
            this.button_reflash.Location = new System.Drawing.Point(369, 104);
            this.button_reflash.Name = "button_reflash";
            this.button_reflash.Size = new System.Drawing.Size(117, 27);
            this.button_reflash.TabIndex = 29;
            this.button_reflash.Text = "重置 reset";
            this.button_reflash.UseVisualStyleBackColor = true;
            this.button_reflash.Click += new System.EventHandler(this.button_reflash_Click);
            // 
            // label11
            // 
            this.label11.AutoSize = true;
            this.label11.BackColor = System.Drawing.SystemColors.MenuHighlight;
            this.label11.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label11.Location = new System.Drawing.Point(510, 145);
            this.label11.Name = "label11";
            this.label11.Size = new System.Drawing.Size(72, 16);
            this.label11.TabIndex = 31;
            this.label11.Text = "讀寫模式";
            // 
            // comboBox_mode
            // 
            this.comboBox_mode.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.comboBox_mode.FormattingEnabled = true;
            this.comboBox_mode.Items.AddRange(new object[] {
            "01-讀線圈，位",
            "02-讀離散量輸，位",
            "03-讀保持寄存器，字",
            "04-讀輸入寄存器，字",
            "05-寫單個線圈，位",
            "06-寫單個寄存器，字",
            "15-寫多個線圈，多位",
            "16-寫多個寄存器，多字"});
            this.comboBox_mode.Location = new System.Drawing.Point(510, 166);
            this.comboBox_mode.Name = "comboBox_mode";
            this.comboBox_mode.Size = new System.Drawing.Size(305, 24);
            this.comboBox_mode.TabIndex = 30;
            // 
            // richTextBox_info
            // 
            this.richTextBox_info.Location = new System.Drawing.Point(516, 440);
            this.richTextBox_info.Name = "richTextBox_info";
            this.richTextBox_info.ReadOnly = true;
            this.richTextBox_info.Size = new System.Drawing.Size(275, 136);
            this.richTextBox_info.TabIndex = 32;
            this.richTextBox_info.Text = "";
            // 
            // label12
            // 
            this.label12.AutoSize = true;
            this.label12.Font = new System.Drawing.Font("新細明體", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(136)));
            this.label12.Location = new System.Drawing.Point(513, 421);
            this.label12.Name = "label12";
            this.label12.Size = new System.Drawing.Size(72, 16);
            this.label12.TabIndex = 33;
            this.label12.Text = "返回說明";
            // 
            // serialPort1
            // 
            this.serialPort1.DataReceived += new System.IO.Ports.SerialDataReceivedEventHandler(this.serialPort1_DataReceived);
            // 
            // Form1
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(827, 588);
            this.Controls.Add(this.label12);
            this.Controls.Add(this.richTextBox_info);
            this.Controls.Add(this.label11);
            this.Controls.Add(this.comboBox_mode);
            this.Controls.Add(this.button_reflash);
            this.Controls.Add(this.label10);
            this.Controls.Add(this.comboBox_DataBits);
            this.Controls.Add(this.label9);
            this.Controls.Add(this.comboBox_StopBits);
            this.Controls.Add(this.label8);
            this.Controls.Add(this.comboBox_Parity);
            this.Controls.Add(this.label6);
            this.Controls.Add(this.comboBox_BaudRate);
            this.Controls.Add(this.label4);
            this.Controls.Add(this.textBox_address);
            this.Controls.Add(this.button_folder);
            this.Controls.Add(this.label7);
            this.Controls.Add(this.comboBox_money);
            this.Controls.Add(this.label_option);
            this.Controls.Add(this.comboBox_option);
            this.Controls.Add(this.label5);
            this.Controls.Add(this.comboBox_devices);
            this.Controls.Add(this.label_cmd);
            this.Controls.Add(this.comboBox_cmd);
            this.Controls.Add(this.button_write);
            this.Controls.Add(this.label3);
            this.Controls.Add(this.richTextBox_read);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.richTextBox_write);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.button_close);
            this.Controls.Add(this.button_open);
            this.Controls.Add(this.comboBox_port);
            this.Name = "Form1";
            this.Text = "洗烘設備通信協議";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.Form1_FormClosing);
            this.Load += new System.EventHandler(this.Form1_Load);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.ComboBox comboBox_port;
        private System.Windows.Forms.Button button_open;
        private System.Windows.Forms.Button button_close;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.RichTextBox richTextBox_write;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label3;
        private System.Windows.Forms.RichTextBox richTextBox_read;
        private System.Windows.Forms.Button button_write;
        private System.Windows.Forms.ComboBox comboBox_cmd;
        private System.Windows.Forms.Label label_cmd;
        private System.Windows.Forms.Label label5;
        private System.Windows.Forms.ComboBox comboBox_devices;
        private System.Windows.Forms.ComboBox comboBox_option;
        private System.Windows.Forms.Label label_option;
        private System.Windows.Forms.ComboBox comboBox_money;
        private System.Windows.Forms.Label label7;
        private System.Windows.Forms.Button button_folder;
        private System.Windows.Forms.TextBox textBox_address;
        private System.Windows.Forms.Label label4;
        private System.Windows.Forms.ComboBox comboBox_BaudRate;
        private System.Windows.Forms.Label label6;
        private System.Windows.Forms.Label label8;
        private System.Windows.Forms.ComboBox comboBox_Parity;
        private System.Windows.Forms.Label label9;
        private System.Windows.Forms.ComboBox comboBox_StopBits;
        private System.Windows.Forms.Label label10;
        private System.Windows.Forms.ComboBox comboBox_DataBits;
        private System.Windows.Forms.Button button_reflash;
        private System.Windows.Forms.Label label11;
        private System.Windows.Forms.ComboBox comboBox_mode;
        private System.Windows.Forms.RichTextBox richTextBox_info;
        private System.Windows.Forms.Label label12;
        private System.IO.Ports.SerialPort serialPort1;
    }
}

